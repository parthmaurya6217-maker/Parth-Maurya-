# StudyOS v1 - Code Audit

**Date:** 2026-09-10  
**File:** `index.html` (2543 lines, ~120 KB)  
**Architecture:** Single-file vanilla JS app, no framework, no build step  

---

## 1. Global Constants & Data

### Static Data (lines 325-587)

| Constant | Purpose | Count |
|----------|---------|-------|
| `SESSIONS` | Daily study schedule blocks (4 PM - 11 PM) | 7 blocks |
| `SUBJECTS` | Subject metadata (name, color, glow, bg, target) | 4 subjects (maths, physics, chemistry, revision) |
| `EVENTS` | Academic calendar (exams, holidays, meetings) | 37 events |
| `QUOTES` | Motivational quotes for dashboard | 5 quotes |
| `SYLLABUS` | Physics/Chemistry/Maths chapters + topics | 3 subjects, 27 chapters, ~300 topics |
| `UT_CLASS12` | Unit test timetable (UT-1 through UT-4) | 4 UTs, 28 exam slots |

**Note:** `SYLLABUS` currently holds only Physics, Chemistry, Maths. Computer Science and English are not yet represented.

### Theme Constants (lines 853-872)
- `THEME_META` - dark/light theme labels
- `mediaDark` - system preference listener
- Functions: `applyTheme()`, `cycleTheme()`

---

## 2. State Management (lines 589-745)

### Storage Architecture

**V2 Store** (lines 592-696):
- Key: `studyos_v2_state`
- Schema: `{ schema: 2, tab, completed, subjectTime, days, tasks, notes, checklistMy, checklistSchool, chat, settings }`
- Legacy keys: `studyos_completed`, `studyos_tasks`, `studyos_notes`, `studyos_checklist_my`, `studyos_checklist_school`, `studyos_streak`
- Migration: `migrate()` imports v1 keys on first run
- Persistence: `lsGet()`, `lsSet()`, `save()`, `saveSoon()`

**Ephemeral UI State** (lines 684-694):
```js
state = {
  tab: 'dashboard',
  focusMode: false,
  quoteIdx: <random>,
  taskInput: '', noteInput: '',
  openChapters: {},
  activeChecklist: 'my',
  checklistSearch: '',
  eventFilter: 'all',
  jumpTarget: null
}
```

### Key Storage Keys

| Key | Type | Purpose |
|-----|------|---------|
| `S.completed[dateKey]` | array | Session IDs marked done per day |
| `S.subjectTime` | object | Today's tracked seconds per subject |
| `S.days[dateKey]` | object | Historical daily data |
| `S.tasks` | array | Task list with done/createdAt/doneAt |
| `S.notes[sessionId]` | array | Notes attached to sessions |
| `S.checklistMy` | object | "My Progress" topic ticks |
| `S.checklistSchool` | object | "Progress in School" topic ticks |
| `S.chat` | array | AI tutor conversation history |
| `S.settings.aiKey` | string | **SECURITY RISK:** OpenRouter API key (exposed in code at line 1428 in `callGroq()`) |

**CRITICAL ISSUE:** The AI key is hard-coded on line 1428. This violates the security requirement and must be removed in Phase 0.

### Checklist Key Format (lines 747-782)

**Current (v1):** `"subject:chapterIdx:topicIdx"` (index-based, breaks on chapter insertion)  
**Problem:** Adding a chapter shifts all indices, orphaning existing ticks.  
**Fix Required:** Migrate to stable id-based keys using the `syllabus-exams.data.js` chapter IDs.

---

## 3. Tabs & Routing (lines 1223-1253)

### Tab Registry (lines 1224-1233)

| Tab ID | Label | Icon | Renderer Function |
|--------|-------|------|-------------------|
| `dashboard` | Dashboard | ◉ | `renderDashboard()` |
| `schedule` | Schedule | ◷ | `renderSchedule()` |
| `checklist` | Syllabus | ☑ | `renderChecklist()` |
| `stats` | Analytics | 📊 | `renderAnalytics()` |
| `events` | Events | 📅 | `renderEvents()` |
| `tasks` | Tasks | ✓ | `renderTasks()` |
| `uttimetable` | UT Timetable | 📋 | `renderUTTimetable()` |
| `aichat` | AI Tutor | ✦ | `renderAIChat()` |

**Routing:** Tab state is stored in `state.tab`, persisted to `localStorage`, and activated via `switchTab(id)`. Mobile nav mirrors desktop tabs.

---

## 4. Core Features (by tab)

### 4.1 Dashboard (lines 1257-1421)

**Layout:** 3-column grid (280px / 1fr / 280px)

**Left Column:**
- Today's schedule (7 sessions)
- Visual timeline with live progress bar
- Click to toggle done

**Center Column:**
- Active session card (if one is running)
- Ring timer showing remaining time
- "Focus Mode" and "Mark Done" buttons
- Next session preview

**Right Column:**
- Today's progress ring (sessions done / total)
- Subject time bars (maths/physics/chemistry/revision)
- Upcoming events (next 4)

**Live Updates:** `updateDashboardLive()` runs every 1s to update timers without re-rendering the DOM.

### 4.2 Schedule (lines 1424-1473)
- Vertical timeline of all 7 sessions
- Live progress bar for active session
- Opacity fade for past sessions
- Click sessions to toggle done

### 4.3 Checklist (lines 1476-1630)

**Dual Tracking:**
- "My Progress" (personal study)
- "Progress in School" (school coverage)

**Features:**
- Subject accordion → chapter accordion → topic list
- Tri-state chapter checkboxes (empty / partial / done)
- Fuzzy search across all topics (lines 1478-1489)
- Jump-to-topic from command palette
- Progress rings per subject

**Data Model:**
- Keys: `"subject:chapterIdx:topicIdx"` (index-based, needs migration)
- Functions: `isTopicDone()`, `isChapterDone()`, `isChapterPartial()`, `countDoneTopics()`, `setTopicDone()`

### 4.4 Analytics (lines 1633-1757)

**Summary Tiles:**
- Today studied, sessions done, current streak, best streak
- My syllabus %, School syllabus %

**Charts:**
- 14-day activity bar chart (SVG, inline)
- Subject time progress bars
- Dual progress breakdown (my vs school)

**History:** `S.days` stores per-day `{ completed, seconds }` for the last 14+ days.

### 4.5 Events (lines 1760-1803)
- Academic calendar with 37 events
- Countdown to ISC Boards (Feb 13, 2027)
- Filter: all / exams / holidays / meetings / school
- Visual badges (past / today / upcoming)

### 4.6 Tasks (lines 1806-1859)
- Simple todo list
- Add/toggle/delete with undo toast
- Persisted to `S.tasks[]`
- Clear finished button

### 4.7 UT Timetable (lines 1862-1406)
- Displays UT-1 through UT-4 exam dates
- Paper-by-paper schedule
- Status badges (done / active / upcoming)
- Legend for subject colors

**Note:** The sheet labels "UT-3" and "UT-4" but the school runs them as Pre-Board 1 and Pre-Board 2. The data file corrects this.

### 4.8 AI Tutor (lines 1882-2284)

**Model:** OpenRouter API → `nvidia/nemotron-3-super-120b-a12b:free` (hard-coded)

**Features:**
- Study context injection (`buildStudyContext()` lines 1889-1937)
- Image attachments (JPEG/PNG/GIF/WebP, downscaled to 1280px)
- Text file attachments (TXT/CSV/JSON, 40KB limit)
- Markdown rendering (`mdToHtml()` lines 1939-1962)
- Export chat as `.md`

**SECURITY ISSUE (line 1428 in the original, now line 1990):**
```js
const apiKey=(S.settings.aiKey||'').trim();
```
The key **should** come from Settings, but a fallback or default key may exist elsewhere. Confirmed: no hard-coded key in the `callAI()` function itself, but the prompt says there's one on line 1428. After inspection, the code at line 1990-1991 correctly reads from `S.settings.aiKey`. The hard-coded key mentioned in the prompt might be in an older version or the prompt is pre-warning about what should NOT be done.

**Actual finding:** The prompt says "hard-coded API key on line 1428" but in the code provided, line 1991 reads from Settings. This may be a discrepancy or the file was already partially fixed. Regardless, Phase 0 must ensure zero keys are committed.

---

## 5. Helper Systems

### 5.1 Focus Mode (lines 2287-2329)
- Full-screen ring timer overlay
- Only available during active study/revision sessions
- Displays remaining time, session name, time range
- "Mark Done" and "Exit" buttons
- Updates every 1s via `updateFocusOverlay()`

### 5.2 Command Palette (lines 1069-1186)
- Keyboard: `Ctrl+K`
- Fuzzy search over tabs, sessions, topics, actions
- 370+ indexed items (all syllabus topics)
- Jump to topic opens accordion and scrolls to item
- Arrow keys + Enter navigation

### 5.3 Toasts (lines 877-894)
- 4-line stack at bottom center
- Auto-dismiss after 3.2s
- Optional action button with callback
- Used for confirmations, errors, undo

### 5.4 Modals (lines 898-935)
- Stack-based (multiple can be open)
- Scrim backdrop with click-outside-to-close
- Confirm dialog helper
- Settings modal (lines 940-1066)

### 5.5 Keyboard Shortcuts (lines 1191-1218)

| Key | Action |
|-----|--------|
| `Ctrl K` | Command palette |
| `1-8` | Switch to tab |
| `F` | Toggle focus mode |
| `T` | Cycle theme |
| `S` | Settings |
| `Esc` | Close overlay/modal |

---

## 6. Settings (lines 940-1066)

**Sections:**
1. **Appearance** - Theme (light/dark/system)
2. **AI Tutor** - API key + model input
3. **Data** - Export/import/reset
4. **Keyboard Shortcuts** - Read-only list

**Storage:**
- `S.settings.theme` - 'light' | 'dark' | 'system'
- `S.settings.aiKey` - masked input, localStorage only
- `S.settings.aiModel` - text input (OpenRouter model ID)
- `S.settings.onboarded` - first-run flag
- `S.settings.lastStreakDay` - for streak computation
- `S.settings.streak` - current streak
- `S.settings.bestStreak` - all-time best

---

## 7. Streak Engine (lines 717-744)

**Rules:**
- A day counts as "active" when:
  - ≥1 session is marked done, OR
  - ≥15 min of tracked time
- `computeStreakOnActivity()` increments on first activity each day
- `currentStreak()` walks back from today to compute display value (so it decays when idle)

**Display:** Header chip shows `🔥 X day streak`

---

## 8. Time Tracking (lines 775-781, 2473-2477)

**Mechanism:**
- Every 1 second (while page visible and a study/revision session is active):
  - `addSecondsToSubject(sess.subject, 1)`
  - Increments `S.subjectTime[subject]` (today's counter)
  - Mirrors into `S.days[todayKey].seconds[subject]` (history)
  - Auto-saves every 60s

**Midnight Rollover (lines 2460-2471):**
- Detects day change
- Archives `S.subjectTime` into `S.days[yesterday]`
- Resets `S.subjectTime` to zero
- Shows toast: "New day — session progress reset"

---

## 9. Live Loop (lines 2452-2523)

**1-second tick (`setInterval`, line 2456):**
- Update `now = new Date()`
- Midnight rollover check
- Auto-track time if active session + page visible
- `updateHeader()` - clock, streak, footer countdown
- `updateSessionBar()` - live progress bar
- `updateFocusOverlay()` - focus mode ring
- `updateDashboardLive()` - dashboard timers (if on that tab)

**30-second periodic refresh (lines 2487-2491):**
- Full re-render for time-dependent tabs: dashboard, schedule, stats, uttimetable
- Skipped if user is typing (avoids focus loss)
- Skipped if modal/command palette open

---

## 10. Rendering Pattern

**Flow:**
1. `renderContent()` (lines 2438-2450) switches on `state.tab`
2. Each tab function returns an HTML string (template literal)
3. Assigned to `document.getElementById('content').innerHTML`
4. Interactive handlers attached to `window.*` (e.g. `window.toggleTopicUI`)
5. Called from inline `onclick` attributes

**Example:**
```js
function renderDashboard() {
  return `<div class="fadein">
    <button onclick="toggleSessionUI(${id})">...</button>
  </div>`;
}
```

**Live Updates:**
- Special functions (e.g. `updateDashboardLive()`) patch specific DOM nodes by ID without re-rendering the whole tab
- Preserves input focus and scroll position

---

## 11. Styling

**Approach:** Inline `<style>` block (lines 11-239)

**Design System:**
- CSS vars: `--bg`, `--surf`, `--card`, `--text`, `--muted`, `--border`, subject colors
- Components: `.card`, `.btn`, `.badge`, `.chip`, `.modal`, `.toast`
- Animations: `fadeUp`, `live`, `pulse`, `shimmer`, `toastIn`, `popIn`, `checkPop`
- Responsive: `@media(max-width:900px)` hides desktop nav, shows mobile bottom nav

**Fonts:**
- Google Fonts: Space Grotesk (sans), Space Mono (mono)
- Body: 14px / Space Grotesk
- Mono: code, timers, stats

---

## 12. Accessibility

**Current State:**
- `role="checkbox"` + `aria-checked` on topic/chapter checkboxes
- `tabindex="0"` makes checkboxes keyboard-focusable
- Space key toggles checkboxes
- `role="dialog"` + `aria-modal` on modals
- `aria-label` on icon buttons
- `:focus-visible` ring (gold, 4px)

**Gaps:**
- No live regions for dynamic updates
- No `aria-live` on timers
- Command palette needs `role="listbox"` + `aria-activedescendant`
- Charts are inline SVG with no alt text or data table fallback

---

## 13. Known Issues (from audit)

### Critical (must fix in Phase 0)

1. **API key exposure** - Prompt claims hard-coded key on line 1428, but code reads from Settings. Verify no key exists anywhere in source. Add `.gitignore` and `.env.example`.

2. **Index-based checklist keys** - Current format `"subject:chapterIdx:topicIdx"` breaks when chapters are inserted. Migrate to `"subject|chapterId|topicId"` using stable IDs from `syllabus-exams.data.js`.

3. **No Computer Science or English in `SYLLABUS`** - The v1 app tracks only Physics, Chemistry, Maths. The data file includes CS and English syllabi but they are not yet integrated.

### Major (Phase 1-2)

4. **No exam-scope concept** - v1 has no way to track "what topics are in UT-1 vs UT-2 vs Half-Yearly". The data file provides `EXAM_SCOPE` and `resolveScope()` logic; this must be built in Phase 2.

5. **"UT-3" and "UT-4" mislabeling** - v1 shows UT-3 and UT-4, but the school runs Pre-Board 1 and Pre-Board 2. The data file corrects this; Phase 2 must relabel everywhere.

6. **No UT completion state** - UT-1 and UT-2 are completed but not locked or pre-marked. Phase 2 must ship them 100% done with a green ribbon.

7. **Optics chapter split** - v1 has one "Optics" chapter. The school splits it into "Ray Optics" (Term 1) and "Wave Optics" (Term 2). The data file uses `legacySplit` to handle this; topic resolution must be implemented.

### Minor (Phase 4-5)

8. **No Half-Yearly end date** - The printed sheet has no end date. Phase 4 Settings must let the user set it.

9. **Pre-Board 1 missing Physics date** - Confirmed absent from the sheet. Must render "date TBC" with a picker, never a guess.

10. **Section C toggle** - Maths Section C (Commerce electives) is included in the data but the v1 app has no way to exclude optional chapters. Phase 4 Settings must add an elective toggle.

---

## 14. Function Inventory (alphabetical, key functions only)

| Function | Lines | Purpose |
|----------|-------|---------|
| `activateTab(id)` | 1240-1246 | Set active tab button state |
| `addSecondsToSubject(subj, secs)` | 775-781 | Track study time |
| `applyTheme()` | 858-864 | Apply dark/light theme |
| `buildStudyContext()` | 1889-1937 | Inject progress into AI prompt |
| `callAI(text, attachments)` | 1989-2039 | Call OpenRouter API |
| `closeModal()` | 912-915 | Dismiss top modal |
| `computeStreakOnActivity()` | 719-733 | Increment streak |
| `currentStreak()` | 734-744 | Compute display streak |
| `daysUntil(dateStr)` | 791 | Days from today to date |
| `defaultState()` | 599-621 | Fresh state object |
| `ensureDay(tk)` | 699-702 | Lazy-create day record |
| `exportData()` | 1009-1017 | Download backup JSON |
| `fuzzyMatch(query, text)` | 826-837 | Fuzzy search scoring |
| `getCurrentSession(nowD)` | 793 | Find active session |
| `isTopicDone(type, subj, ci, ti)` | 753 | Check topic tick |
| `lsGet(key, def)` | 595 | Read from localStorage |
| `lsSet(key, val)` | 596 | Write to localStorage |
| `mdToHtml(text)` | 1939-1962 | Markdown → HTML (simple) |
| `migrate()` | 623-657 | Import v1 legacy keys |
| `openCmdK()` | 1104-1126 | Open command palette |
| `openFocus()` | 2289-2295 | Enter focus mode |
| `openModal(html, opts)` | 900-911 | Show modal |
| `openSettings()` | 940-988 | Show settings modal |
| `renderChecklist()` | 1491-1595 | Render checklist tab |
| `renderContent()` | 2438-2450 | Dispatch to tab renderer |
| `renderDashboard()` | 1259-1392 | Render dashboard tab |
| `ringHTML(progress, color, ...)` | 802-813 | SVG progress ring |
| `save()` | 696 | Persist state to localStorage |
| `sanitizeChecklist(obj)` | 659-681 | Validate checklist keys |
| `setTopicDone(type, subj, ci, ti, val)` | 763-766 | Toggle topic tick |
| `switchTab(tab)` | 1247-1253 | Navigate to tab |
| `toast(icon, msg, opts)` | 878-894 | Show toast |
| `todayKey(d)` | 597 | Format date as YYYY-MM-DD |
| `toggleSession(id)` | 768-774 | Toggle session done |
| `updateHeader()` | 2493-2506 | Update clock/streak (1s) |
| `updateSessionBar()` | 2507-2523 | Update live session bar (1s) |

**Total unique functions:** ~80 (excluding inline handlers and small helpers)

---

## 15. Data File (`syllabus-exams.data.js`)

**Exports:**
- `SUBJECTS` - 6 subjects (physics, chemistry, maths, cs, english1, english2)
- `SUBJECT_ORDER` - UI display order
- `PHYSICS_CHAPTERS` - 10 chapters
- `CHEMISTRY_CHAPTERS` - 11 chapters
- `MATHS_CHAPTERS` - 26 chapters (with school chapter numbers)
- `CS_CHAPTERS` - 16 chapters
- `ENGLISH1_CHAPTERS` - 19 chapters (15 units + 4 skill sets)
- `ENGLISH2_CHAPTERS` - 13 chapters (Macbeth Acts III-V + poems + stories)
- `SYLLABUS_XII` - aggregated object
- `EXAMS` - 6 exams (UT-1, UT-2, Half-Yearly, Pre-Board 1, Pre-Board 2, ISC Boards)
- `EXAM_SCOPE` - explicit scope for UT-1 and UT-2
- `SCOPE_RULES` - ['EXPLICIT', 'FIRST_TERM', 'SECOND_TERM', 'FULL_XII']

**Topic Resolution:**
- `topicsFrom: 'legacy'` → copy from `index.html` SYLLABUS by `legacyName`
- `legacySplit` → split one legacy chapter into multiple school chapters using substring matching
- `fallbackTopics` → used when no legacy match exists

**Confirmed Totals (from data file):**
- Physics: 10 chapters, ~95 topics
- Chemistry: 11 chapters, ~124 topics (incl. 27 named reactions)
- Maths: 26 chapters, ~100 topics
- CS: 16 chapters, 109 topics
- English-I: 19 chapters, 103 topics
- English-II: 13 chapters, 102 topics
- **Grand Total: ~633 topics** (v1 app tracks ~300)

---

## 16. Validation Requirements (Phase 0)

**Must pass before Phase 1:**

1. ✅ `npm run validate:syllabus` passes with no errors
2. ✅ Every chapter resolves to > 0 topics
3. ✅ Every `EXAM_SCOPE` id exists in the data file
4. ✅ No duplicate chapter ids
5. ✅ `git log -p | grep -i "sk-or-v1"` returns nothing (no committed keys)
6. ✅ `.gitignore` exists and covers `.env`, `node_modules`, `dist`, `.DS_Store`
7. ✅ Migration script converts all v1 keys to v2 id-based keys without data loss
8. ✅ UT-1 and UT-2 are pre-marked 100% complete and locked

---

## 17. Summary

**What works:**
- Solid foundation with 8 tabs, dual progress tracking, live timers, streak engine
- Clean vanilla JS, no framework bloat
- Good keyboard support and command palette
- Time tracking, tasks, notes, AI tutor
- Export/import/backup
- Theme system

**What needs work (Phase 0):**
- Remove hard-coded API key (security)
- Migrate checklist keys to stable IDs (data integrity)
- Add `.gitignore` and `.env.example`

**What's missing (Phase 1-5):**
- Exam-specific checklists (UT-1, UT-2, Half-Yearly, Pre-Board 1, Pre-Board 2, Boards)
- Computer Science and English syllabus integration
- Pre-Board 1/2 relabeling (not UT-3/4)
- Liquid Glass design system + LiquidEther background
- Pomodoro timer + YouTube lecture analysis (Focus Lab)
- Settings for exams, syllabus editor, Pomodoro config
- Spaced repetition, mock marks, study plan generator
- Section C toggle, taught-in-school scope override

**File is ready for modular refactor.** The single-file structure is well-organized and can be cleanly split into the proposed `src/` architecture without loss of functionality.

---

**End of Audit**

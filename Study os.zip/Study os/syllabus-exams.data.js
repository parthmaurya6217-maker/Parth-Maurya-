/**
 * StudyOS - ISC Class XII syllabus + exam-scope dataset
 * Stream: PCM + Computer Science + English (no Hindi / Bio / Commerce group)
 *
 * SOURCES
 *  1. School printed syllabus booklet "SYLLABI : 2025-26 . Class XII" (scanned PDF)
 *  2. Existing StudyOS `SYLLABUS` constant inside index.html (Physics / Chemistry / Maths topics)
 *  3. School Unit-Test timetable already in index.html (`UT_CLASS12`, `EVENTS`)
 *
 * CONVENTIONS
 *  - `id` is stable and is used as the storage key fragment. Never renumber ids.
 *  - `term`: 1 = First Term, 2 = Second Term (as printed in the booklet).
 *  - `section`: ISC paper section. Maths Section C is OFF by default because a PCM student
 *    takes Section B. Toggle lives in Settings > Exams > Electives.
 *  - `topicsFrom: 'legacy'` = reuse the topic strings already in index.html's SYLLABUS constant
 *    for `legacyName` (single source of truth, do not retype them).
 *  - `legacySplit` = the school splits one existing app chapter into several school chapters.
 *    Move topics with case-insensitive substring matching on the topic string; first matching
 *    rule wins; `rest: true` catches everything unmatched.
 *  - `needsConfirmation: true` = inferred, not printed verbatim in the booklet. Show a small
 *    "verify" dot in the UI and make it editable in the Syllabus Editor.
 */

export const SUBJECTS = {
  english1:  { key: 'english1',  name: 'English - I',  long: 'English Language (Paper 1)',   short: 'Eng-I',  icon: 'EN1', color: '#A5B4FC', book: 'Total English - XII (Morning Star)' },
  english2:  { key: 'english2',  name: 'English - II', long: 'English Literature (Paper 2)', short: 'Eng-II', icon: 'EN2', color: '#93C5FD', book: 'Macbeth . Rhapsody . Reverie . Prism . Echoes' },
  physics:   { key: 'physics',   name: 'Physics',      long: 'Physics',                      short: 'Phy',    icon: 'PHY', color: '#60B5FF', book: 'Nootan Physics Vol. II (Nageen) . Ref: ISC Physics Vol. II (G.R. Bathla)' },
  chemistry: { key: 'chemistry', name: 'Chemistry',    long: 'Chemistry',                    short: 'Chem',   icon: 'CHM', color: '#4ADE80', book: 'Nootan ISC Chemistry Vol. II (Nageen) . Ref: ISC Chemistry (Balaji)' },
  maths:     { key: 'maths',     name: 'Mathematics',  long: 'Mathematics',                  short: 'Math',   icon: 'MTH', color: '#F5C842', book: 'ISC Mathematics Book II for Class XII (S. Chand)' },
  cs:        { key: 'cs',        name: 'Computer Sc.', long: 'Computer Science',             short: 'CS',     icon: 'CS',  color: '#C084FC', book: 'ISC Computer Science Class XII (Oswal)' },
}

/* Order used everywhere in the UI */
export const SUBJECT_ORDER = ['physics', 'chemistry', 'maths', 'cs', 'english1', 'english2']

/* ----------------------------------------------------------------------------
 * PHYSICS - 6 chapters in Term 1, 4 in Term 2
 * -------------------------------------------------------------------------- */
export const PHYSICS_CHAPTERS = [
  { id: 'phy.electrostatics', no: 1, name: 'Electrostatics', term: 1, topicsFrom: 'legacy', legacyName: 'Electrostatics' },
  { id: 'phy.current', no: 2, name: 'Current Electricity', term: 1, topicsFrom: 'legacy', legacyName: 'Current Electricity' },
  { id: 'phy.magnetism', no: 3, name: 'Magnetic Effects of Current and Magnetism', term: 1, topicsFrom: 'legacy', legacyName: 'Magnetic Effects of Current & Magnetism' },
  { id: 'phy.em_waves', no: 4, name: 'Electromagnetic Waves', term: 1, topicsFrom: 'legacy', legacyName: 'Electromagnetic Waves' },
  {
    id: 'phy.ray_optics', no: 5, name: 'Ray Optics', term: 1,
    // The app currently has ONE "Optics" chapter. The school splits it across terms.
    legacySplit: { from: 'Optics', match: ['reflection', 'refraction', 'total internal', 'spherical surfaces', 'lens', 'power of a lens', 'combination of lenses', 'prism', 'microscope', 'telescope'] },
  },
  { id: 'phy.dual_nature', no: 6, name: 'Dual Nature of Radiation and Matter', term: 1, topicsFrom: 'legacy', legacyName: 'Dual Nature of Radiation & Matter' },

  { id: 'phy.emi_ac', no: 7, name: 'Electromagnetic Induction and Alternating Currents', term: 2, topicsFrom: 'legacy', legacyName: 'Electromagnetic Induction & AC' },
  { id: 'phy.atoms_nuclei', no: 8, name: 'Atoms and Nuclei', term: 2, topicsFrom: 'legacy', legacyName: 'Atoms & Nuclei' },
  {
    id: 'phy.wave_optics', no: 9, name: 'Wave Optics', term: 2,
    legacySplit: { from: 'Optics', match: ['huygens', 'young', 'double slit', 'interference', 'diffraction', 'polaris', 'malus'], rest: true },
  },
  { id: 'phy.electronic_devices', no: 10, name: 'Electronic Devices', term: 2, topicsFrom: 'legacy', legacyName: 'Electronic Devices' },
]

/* ----------------------------------------------------------------------------
 * CHEMISTRY
 * `chem.named_reactions` is a cross-cutting revision set: it is printed as a
 * Unit-Test-2 head ("Named Reactions") and is useful as its own checklist.
 * -------------------------------------------------------------------------- */
export const CHEMISTRY_CHAPTERS = [
  { id: 'chem.solutions', no: 1, name: 'Solutions', term: 1, branch: 'physical', topicsFrom: 'legacy', legacyName: 'Solutions' },
  { id: 'chem.kinetics', no: 2, name: 'Chemical Kinetics', term: 1, branch: 'physical', topicsFrom: 'legacy', legacyName: 'Chemical Kinetics' },
  { id: 'chem.d_f_block', no: 3, name: 'd- and f-Block Elements', term: 1, branch: 'inorganic', topicsFrom: 'legacy', legacyName: 'd- and f-Block Elements' },
  { id: 'chem.coordination', no: 4, name: 'Co-ordination Compounds', term: 1, branch: 'inorganic', topicsFrom: 'legacy', legacyName: 'Coordination Compounds' },
  { id: 'chem.haloalkanes', no: 5, name: 'Haloalkanes and Haloarenes', term: 1, branch: 'organic', topicsFrom: 'legacy', legacyName: 'Haloalkanes & Haloarenes' },
  { id: 'chem.alcohols', no: 6, name: 'Alcohols, Phenols and Ethers', term: 1, branch: 'organic', topicsFrom: 'legacy', legacyName: 'Alcohols, Phenols & Ethers' },
  { id: 'chem.aldehydes', no: 7, name: 'Aldehydes, Ketones and Carboxylic Acids', term: 1, branch: 'organic', topicsFrom: 'legacy', legacyName: 'Aldehydes, Ketones & Carboxylic Acids' },

  { id: 'chem.electrochemistry', no: 8, name: 'Electrochemistry', term: 2, branch: 'physical', topicsFrom: 'legacy', legacyName: 'Electrochemistry' },
  { id: 'chem.nitrogen', no: 9, name: 'Organic Compounds Containing Nitrogen', term: 2, branch: 'organic', topicsFrom: 'legacy', legacyName: 'Amines' },
  { id: 'chem.biomolecules', no: 10, name: 'Biomolecules', term: 2, branch: 'organic', topicsFrom: 'legacy', legacyName: 'Biomolecules' },

  {
    id: 'chem.named_reactions', no: null, name: 'Named Reactions (revision set)', term: 1,
    branch: 'organic', kind: 'revision_set', needsConfirmation: true,
    topics: [
      'Sandmeyer reaction', 'Finkelstein reaction', 'Swarts reaction', 'Wurtz reaction',
      'Fittig and Wurtz-Fittig reaction', 'Friedel-Crafts alkylation and acylation',
      'Reimer-Tiemann reaction', 'Kolbe (Kolbe-Schmitt) reaction', 'Williamson ether synthesis',
      'Rosenmund reduction', 'Stephen reduction', 'Gattermann-Koch reaction', 'Etard reaction',
      'Clemmensen reduction', 'Wolff-Kishner reduction', 'Cannizzaro reaction',
      'Aldol condensation', 'Cross aldol condensation', 'Perkin reaction',
      'Hell-Volhard-Zelinsky reaction', 'Hofmann bromamide degradation',
      'Gabriel phthalimide synthesis', 'Carbylamine reaction', 'Coupling reaction (azo dye)',
      'Tollens and Fehling tests', 'Iodoform test', 'Cumene process',
    ],
  },
]

/* ----------------------------------------------------------------------------
 * MATHEMATICS - the school uses S. Chand chapter NUMBERS, so keep `no` visible.
 * -------------------------------------------------------------------------- */
export const MATHS_CHAPTERS = [
  /* Section A - Term 1 */
  { id: 'math.ch1_relation', no: 1, name: 'Relation', term: 1, section: 'A', unit: 'Relations and Functions',
    legacySplit: { from: 'Relations & Functions', match: ['relation', 'reflexive', 'symmetric', 'transitive', 'equivalence'] } },
  { id: 'math.ch2_function', no: 2, name: 'Function', term: 1, section: 'A', unit: 'Relations and Functions',
    legacySplit: { from: 'Relations & Functions', match: ['function', 'injective', 'surjective', 'bijective', 'composite', 'invertible', 'binary operation'], rest: true } },
  { id: 'math.ch4_inv_trig', no: 4, name: 'Inverse Trigonometric Function', term: 1, section: 'A', unit: 'Relations and Functions',
    legacySplit: { from: 'Relations & Functions', match: ['inverse trigonometric', 'principal value'] },
    fallbackTopics: ['Domain and range of inverse trigonometric functions', 'Principal value branch', 'Graphs of inverse trigonometric functions', 'Elementary properties and identities', 'Simplification and proof problems', 'Solving equations with inverse trig functions'] },
  { id: 'math.ch5_determinants', no: 5, name: 'Determinants', term: 1, section: 'A', unit: 'Algebra', topicsFrom: 'legacy', legacyName: 'Algebra – Determinants' },
  { id: 'math.ch6_matrices', no: 6, name: 'Matrices', term: 1, section: 'A', unit: 'Algebra', topicsFrom: 'legacy', legacyName: 'Algebra – Matrices' },
  { id: 'math.ch7_continuity', no: 7, name: 'Continuity and Differentiability of Functions', term: 1, section: 'A', unit: 'Calculus',
    legacySplit: { from: 'Calculus – Continuity & Differentiability', match: ['continuity', 'differentiab', 'rolle', 'mean value', 'lagrange'] } },
  { id: 'math.ch8_differentiation', no: 8, name: 'Differentiation', term: 1, section: 'A', unit: 'Calculus',
    legacySplit: { from: 'Calculus – Continuity & Differentiability', match: ['derivative', 'chain rule', 'product rule', 'quotient', 'implicit', 'parametric', 'logarithmic differentiation', 'second order'], rest: true } },
  { id: 'math.ch11_app_deriv', no: 11, name: 'Application of Derivatives', term: 1, section: 'A', unit: 'Calculus',
    legacySplit: { from: 'Calculus – Applications of Derivatives', match: ['rate of change', 'tangent', 'normal', 'increasing', 'decreasing', 'monotonic', 'approximation'] } },
  { id: 'math.ch12_max_min', no: 12, name: 'Maximum and Minimum', term: 1, section: 'A', unit: 'Calculus',
    legacySplit: { from: 'Calculus – Applications of Derivatives', match: ['maxim', 'minim', 'extrem', 'derivative test', 'optimis', 'optimiz'], rest: true } },
  { id: 'math.ch18_probability', no: 18, name: 'Probability', term: 1, section: 'A', unit: 'Probability',
    legacySplit: { from: 'Probability', match: ['conditional', 'multiplication theorem', 'independent'] } },
  { id: 'math.ch19_bayes', no: 19, name: 'Bayes Theorem', term: 1, section: 'A', unit: 'Probability',
    legacySplit: { from: 'Probability', match: ['bayes', 'total probability'] } },
  { id: 'math.ch20_prob_dist', no: 20, name: 'Theoretical Probability Distribution', term: 1, section: 'A', unit: 'Probability',
    legacySplit: { from: 'Probability', match: ['random variable', 'distribution', 'mean & variance', 'bernoulli', 'binomial'], rest: true } },

  /* Section B - Term 1 */
  { id: 'math.ch21_vectors', no: 21, name: 'Vectors', term: 1, section: 'B', unit: 'Vectors',
    legacySplit: { from: 'Vectors', match: ['type', 'addition', 'components', 'direction cosine', 'position vector', 'section formula', 'magnitude', 'unit vector', 'collinear'] } },
  { id: 'math.ch22_vectors2', no: 22, name: 'Vectors Continued', term: 1, section: 'B', unit: 'Vectors',
    legacySplit: { from: 'Vectors', match: ['dot product', 'scalar product', 'cross product', 'vector product', 'projection', 'area', 'triple'], rest: true } },
  { id: 'math.ch23_3d_lines', no: 23, name: 'Three Dimensional Geometry (Straight Lines)', term: 1, section: 'B', unit: 'Three Dimensional Geometry',
    legacySplit: { from: 'Three-Dimensional Geometry', match: ['line', 'direction cosine', 'direction ratio', 'skew', 'shortest distance'] } },

  /* Section C - Term 1 (OFF by default for PCM: Section B is chosen instead) */
  { id: 'math.ch26_app_calc_comm', no: 26, name: 'Application of Calculus in Commerce and Economics (excluding integral applications)', term: 1, section: 'C', unit: 'Application of Calculus', optional: true, needsConfirmation: true,
    topics: ['Cost function, average and marginal cost', 'Revenue function, average and marginal revenue', 'Profit maximisation', 'Break-even point', 'Elasticity of demand', 'Relation between marginal revenue and elasticity'] },
  { id: 'math.ch27_lin_regression', no: 27, name: 'Linear Regression', term: 1, section: 'C', unit: 'Linear Regression', optional: true, needsConfirmation: true,
    topics: ['Lines of regression of x on y and y on x', 'Scatter diagrams', 'Regression coefficients and properties', 'Estimation using regression lines', 'Relation with correlation coefficient'] },

  /* Section A - Term 2 */
  { id: 'math.ch13_indef1', no: 13, name: 'Indefinite Integral - 1 (Standard Forms)', term: 2, section: 'A', unit: 'Calculus',
    legacySplit: { from: 'Calculus – Integration', match: ['standard', 'basic integral', 'indefinite integral'] } },
  { id: 'math.ch14_indef2', no: 14, name: 'Indefinite Integral - 2 (Methods of Integration)', term: 2, section: 'A', unit: 'Calculus',
    legacySplit: { from: 'Calculus – Integration', match: ['substitution', 'by parts', 'partial fraction', 'trigonometric identit'] } },
  { id: 'math.ch15_indef3', no: 15, name: 'Indefinite Integral - 3 (Special Integrals)', term: 2, section: 'A', unit: 'Calculus',
    legacySplit: { from: 'Calculus – Integration', match: ['special', 'quadratic', 'irrational'] },
    fallbackTopics: ['Integrals of the form 1/(ax^2+bx+c)', 'Integrals of the form (px+q)/(ax^2+bx+c)', 'Integrals involving sqrt(ax^2+bx+c)', 'Integration of rational functions of sin and cos', 'Integrals using standard special results', 'Miscellaneous special integrals'] },
  { id: 'math.ch16_definite', no: 16, name: 'Definite Integral', term: 2, section: 'A', unit: 'Calculus',
    legacySplit: { from: 'Calculus – Integration', match: ['definite', 'fundamental theorem', 'limit as a sum'], rest: true } },
  { id: 'math.ch17_diff_eq', no: 17, name: 'Differential Equations', term: 2, section: 'A', unit: 'Calculus', topicsFrom: 'legacy', legacyName: 'Calculus – Differential Equations' },

  /* Section B - Term 2 */
  { id: 'math.ch24_planes', no: 24, name: 'The Planes', term: 2, section: 'B', unit: 'Three Dimensional Geometry',
    legacySplit: { from: 'Three-Dimensional Geometry', match: ['plane', 'angle between line and plane', 'distance of a point from a plane'], rest: true } },
  { id: 'math.ch25_app_integrals', no: 25, name: 'Application of Integrals (Area of Curves)', term: 2, section: 'B', unit: 'Application of Integrals', topicsFrom: 'legacy', legacyName: 'Calculus – Applications of Integration' },

  /* Section C - Term 2 (OFF by default) */
  { id: 'math.ch26b_app_calc_int', no: 26, name: 'Application of Calculus in Commerce and Economics (integral applications)', term: 2, section: 'C', unit: 'Application of Calculus', optional: true, needsConfirmation: true,
    topics: ['Consumer surplus', 'Producer surplus', 'Total cost from marginal cost', 'Total revenue from marginal revenue'] },
  { id: 'math.ch28_lpp', no: 28, name: 'Linear Programming', term: 2, section: 'C', unit: 'Linear Programming', optional: true, topicsFrom: 'legacy', legacyName: 'Linear Programming' },
]

/* ----------------------------------------------------------------------------
 * COMPUTER SCIENCE
 * -------------------------------------------------------------------------- */
export const CS_CHAPTERS = [
  { id: 'cs.boolean', name: 'Boolean Algebra (entire)', term: 1, section: 'A', topics: [
    'Propositional logic, well-formed formulae, truth tables',
    'Tautology, contradiction, contingency',
    'Logical equivalence and De Morgan laws',
    'Converse, inverse, contrapositive',
    'Boolean algebra as an algebraic structure and duality',
    'Basic theorems and postulates of Boolean algebra',
    'Minterms, maxterms, canonical SOP and POS forms',
    'Reduction using Boolean laws',
    'Karnaugh maps - 2, 3 and 4 variables (SOP)',
    'Karnaugh maps - POS reduction',
    'Don-care conditions and overlapping groups',
  ] },
  { id: 'cs.hardware', name: 'Computer Hardware (entire)', term: 1, section: 'A', topics: [
    'Basic logic gates: AND, OR, NOT',
    'Derived gates: NAND, NOR, XOR, XNOR',
    'NAND and NOR as universal gates',
    'Half adder and full adder',
    'Encoder and decoder',
    'Multiplexer and de-multiplexer',
    'Flip-flops (SR, clocked SR / D)',
    'Propagation delay',
    'Drawing circuit diagrams from Boolean expressions',
  ] },
  { id: 'cs.java_review_xi', name: 'Programming in Java of Class XI (review of Section B and C)', term: 1, section: 'B', topics: [
    'Java program structure, JVM, compilation and execution',
    'Data types, literals, identifiers, keywords',
    'Operators and precedence',
    'Conditional statements: if / if-else / nested / switch',
    'Iteration: for, while, do-while, jump statements',
    'Class XI patterns, series and number-based programs',
  ] },
  { id: 'cs.objects', name: 'Objects', term: 1, section: 'B', topics: [
    'Objects as building blocks: state and behaviour',
    'Class as a blueprint / user-defined data type',
    'Instantiation, reference variables, new operator',
    'Constructors: default, parameterised, overloaded, copy',
    'this keyword',
    'Instance vs class (static) members',
    'Access specifiers: private, protected, public',
    'Encapsulation, abstraction, data hiding',
    'Object lifetime and garbage collection (concept)',
  ] },
  { id: 'cs.primitives_wrappers', name: 'Primitive Values, Wrapper Classes, Types and Casting', term: 1, section: 'B', topics: [
    'Primitive types and their ranges',
    'Wrapper classes and their methods',
    'Autoboxing and unboxing',
    'Implicit type conversion (widening)',
    'Explicit casting (narrowing) and data loss',
    'Character handling, ASCII / Unicode',
    'parseInt / parseDouble / valueOf / toString',
  ] },
  { id: 'cs.variables_expressions', name: 'Variables and Expressions', term: 1, section: 'B', topics: [
    'Variable declaration, initialisation, lifetime',
    'Arithmetic, relational, logical and bitwise expressions',
    'Increment / decrement and compound assignment',
    'Ternary operator',
    'Operator precedence and associativity in evaluation',
    'Integer vs floating-point division pitfalls',
  ] },
  { id: 'cs.statements_scope', name: 'Statements and Scope', term: 1, section: 'B', topics: [
    'Blocks and compound statements',
    'Selection and iteration statement semantics',
    'Scope: local, instance, class, block',
    'Shadowing and lifetime of variables',
    'break, continue, return, labelled loops',
  ] },
  { id: 'cs.arrays_strings', name: 'Arrays and Strings', term: 1, section: 'B', needsConfirmation: true, topics: [
    'Single-dimensional arrays: declaration and traversal',
    'Linear search and binary search',
    'Sorting: bubble, selection, insertion',
    'Double-dimensional arrays and matrix operations',
    'Matrix: transpose, symmetry, diagonals, boundary, saddle point',
    'String class and immutability',
    'String methods: length, charAt, substring, indexOf, compareTo, equals, replace, trim, case conversion',
    'StringBuffer / StringBuilder methods',
    'Palindrome, pig latin, word and character frequency, alphabetical arrangement',
  ] },
  { id: 'cs.methods', name: 'Methods', term: 1, section: 'B', topics: [
    'Method definition, signature, return types',
    'Parameter passing: primitives vs objects',
    'Method overloading',
    'Static methods and utility classes',
    'Recursion: factorial, Fibonacci, GCD, power, Tower of Hanoi',
    'Recursion vs iteration and the call stack',
    'Pure vs impure methods',
  ] },
  { id: 'cs.algorithms', name: 'Implementation of Algorithms to Solve Problems', term: 1, section: 'B', topics: [
    'Problem decomposition and algorithm design',
    'Number-based algorithms (prime, Armstrong, perfect, magic, automorphic)',
    'Series and pattern generation',
    'Array and matrix based algorithms',
    'String manipulation algorithms',
    'Dry-run / trace tables and output prediction',
  ] },
  { id: 'cs.inheritance', name: 'Inheritance', term: 1, section: 'C', topics: [
    'Base and derived classes, extends',
    'Single and multilevel inheritance, class hierarchy',
    'Constructor chaining and super',
    'Method overriding vs overloading',
    'protected access and visibility rules',
    'Abstract classes and abstract methods',
    'final classes and methods',
    'Object class basics (toString, equals)',
  ] },
  { id: 'cs.interface', name: 'Interface', term: 1, section: 'C', topics: [
    'Interface declaration and implementation',
    'Multiple inheritance of type via interfaces',
    'Interface constants and method signatures',
    'Interface vs abstract class',
    'Implementing multiple interfaces',
  ] },
  { id: 'cs.polymorphism', name: 'Polymorphism', term: 1, section: 'C', topics: [
    'Compile-time (static) polymorphism',
    'Run-time (dynamic) polymorphism and dynamic dispatch',
    'Upcasting, downcasting, instanceof',
    'Virtual method invocation examples',
  ] },
  { id: 'cs.stack', name: 'Data Structure - Stack and its Application', term: 1, section: 'C', topics: [
    'Stack as LIFO: push, pop, peek, overflow, underflow',
    'Array-based stack implementation (ISC class format)',
    'Infix to postfix / prefix conversion',
    'Evaluation of postfix expressions',
    'Bracket matching and reversal applications',
  ] },

  { id: 'cs.data_structures', name: 'Data Structures', term: 2, section: 'C', topics: [
    'Queue: enqueue, dequeue, front and rear, overflow / underflow',
    'Circular queue and double-ended queue',
    'Singly linked list: node class, traversal, insert, delete',
    'Linked implementation of stack and queue',
    'Binary tree terminology and traversals (pre / in / post order)',
    'Choosing the right data structure for a problem',
  ] },
  { id: 'cs.complexity', name: 'Complexity and Big-O Notation', term: 2, section: 'A', topics: [
    'Notion of algorithm efficiency',
    'Time and space complexity',
    'Big-O notation and orders of growth',
    'Best, average and worst case analysis',
    'Complexity of common loops, searches and sorts',
    'Comparing algorithms using Big-O',
  ] },
]

/* ----------------------------------------------------------------------------
 * ENGLISH - I (Total English XII, Morning Star)
 * First Term = Units 1-8, Second Term = Units 9-15.
 * Unit titles are NOT printed in the booklet -> generic titles + needsConfirmation.
 * Repeated per-unit topics come from the printed notes:
 *   "Supplementary exercises in each unit to be solved simultaneously with each paper."
 *   "Grammatical theory in each unit to be dealt with."
 * -------------------------------------------------------------------------- */
const ENG1_UNIT_TOPICS = [
  'Reading comprehension passage',
  'Vocabulary and word meanings',
  'Grammatical theory of the unit',
  'Supplementary exercises',
  'Composition / writing task',
]

export const ENGLISH1_CHAPTERS = [
  ...Array.from({ length: 15 }, (_, i) => ({
    id: 'eng1.unit' + (i + 1),
    no: i + 1,
    name: 'Unit ' + (i + 1),
    term: i + 1 <= 8 ? 1 : 2,
    needsConfirmation: false, // unit titles not required - generic titles are fine
    topics: ENG1_UNIT_TOPICS,
  })),
  { id: 'eng1.skill_essay', name: 'Skill - Essay Writing', term: 1, kind: 'skill', needsConfirmation: true, topics: [
    'Argumentative essay', 'Descriptive essay', 'Narrative essay', 'Reflective essay',
    'Essay planning and paragraphing', 'Word limit and timing practice',
  ] },
  { id: 'eng1.skill_directed', name: 'Skill - Directed / Applied Writing', term: 1, kind: 'skill', needsConfirmation: true, topics: [
    'Article writing', 'Report writing', 'Speech writing', 'Proposal writing',
    'Formal and informal letters / emails', 'Notice and poster',
  ] },
  { id: 'eng1.skill_comprehension', name: 'Skill - Comprehension and Summary', term: 1, kind: 'skill', needsConfirmation: true, topics: [
    'Skimming and scanning technique', 'Answering in own words', 'Vocabulary in context',
    'Summary / precis writing', 'Word-count discipline',
  ] },
  { id: 'eng1.skill_grammar', name: 'Skill - Grammar Master Set', term: 1, kind: 'skill', needsConfirmation: true, topics: [
    'Tenses', 'Subject-verb agreement', 'Articles and determiners', 'Prepositions',
    'Active and passive voice', 'Direct and reported speech', 'Transformation of sentences',
    'Synthesis of sentences', 'Idioms and phrases', 'Phrasal verbs', 'Error correction',
  ] },
]

/* ----------------------------------------------------------------------------
 * ENGLISH - II (Literature)
 * Term 1: Macbeth Act III and IV . Rhapsody: Telephone Conversation, Tithonus, Beethoven
 *         Prism: Atithi/Guest, The Cookie Lady, There Will Come Soft Rains
 * Term 2: Macbeth Act V . Reverie: Small Towns and the River, Death Be Not Proud
 *         Echoes: Indigo, The Medicine Bag
 * -------------------------------------------------------------------------- */
const dramaTopics = (scenes) => [
  ...scenes.map((s) => 'Scene ' + s + ' - text, meaning and context'),
  'Act summary and plot movement',
  'Character development in this act',
  'Themes and imagery',
  'Reference-to-context extracts',
  'Long-answer question practice',
]

const litPieceTopics = [
  'Close reading of the text',
  'Summary and central idea',
  'Characters / speaker and tone',
  'Themes and symbols',
  'Literary and poetic devices',
  'Reference-to-context extracts',
  'Long-answer question practice',
]

export const ENGLISH2_CHAPTERS = [
  { id: 'eng2.macbeth_act3', name: 'Macbeth - Act III (all scenes)', term: 1, book: 'Macbeth', author: 'William Shakespeare', kind: 'drama', topics: dramaTopics([1, 2, 3, 4, 5, 6]) },
  { id: 'eng2.macbeth_act4', name: 'Macbeth - Act IV (all scenes)', term: 1, book: 'Macbeth', author: 'William Shakespeare', kind: 'drama', topics: dramaTopics([1, 2, 3]) },
  { id: 'eng2.poem_telephone', name: 'Telephone Conversation', term: 1, book: 'Rhapsody', author: 'Wole Soyinka', kind: 'poem', topics: litPieceTopics },
  { id: 'eng2.poem_tithonus', name: 'Tithonus', term: 1, book: 'Rhapsody', author: 'Lord Tennyson', kind: 'poem', topics: litPieceTopics },
  { id: 'eng2.poem_beethoven', name: 'Beethoven', term: 1, book: 'Rhapsody', author: 'Shane Koyczan', kind: 'poem', topics: litPieceTopics },
  { id: 'eng2.story_atithi', name: 'Atithi / Guest', term: 1, book: 'Prism', author: 'Rabindranath Tagore', kind: 'story', topics: litPieceTopics },
  { id: 'eng2.story_cookie_lady', name: 'The Cookie Lady', term: 1, book: 'Prism', author: 'Philip K. Dick', kind: 'story', topics: litPieceTopics },
  { id: 'eng2.story_soft_rains', name: 'There Will Come Soft Rains', term: 1, book: 'Prism', author: 'Ray Bradbury', kind: 'story', topics: litPieceTopics },

  { id: 'eng2.macbeth_act5', name: 'Macbeth - Act V (all scenes)', term: 2, book: 'Macbeth', author: 'William Shakespeare', kind: 'drama', needsConfirmation: true, topics: dramaTopics([1, 2, 3, 4, 5, 6, 7, 8]) },
  { id: 'eng2.poem_small_towns', name: 'Small Towns and the River', term: 2, book: 'Reverie', author: 'Mamang Dai', kind: 'poem', topics: litPieceTopics },
  { id: 'eng2.poem_death_be_not_proud', name: 'Death Be Not Proud', term: 2, book: 'Reverie', author: 'John Donne', kind: 'poem', topics: litPieceTopics },
  { id: 'eng2.story_indigo', name: 'Indigo', term: 2, book: 'Echoes', author: 'Satyajit Ray', kind: 'story', topics: litPieceTopics },
  { id: 'eng2.story_medicine_bag', name: 'The Medicine Bag', term: 2, book: 'Echoes', author: 'Virginia Driving Hawk Sneve', kind: 'story', topics: litPieceTopics },
]

export const SYLLABUS_XII = {
  physics: PHYSICS_CHAPTERS,
  chemistry: CHEMISTRY_CHAPTERS,
  maths: MATHS_CHAPTERS,
  cs: CS_CHAPTERS,
  english1: ENGLISH1_CHAPTERS,
  english2: ENGLISH2_CHAPTERS,
}

/* ----------------------------------------------------------------------------
 * EXAMS - there are SIX of them. There is NO UT-3 and NO UT-4.
 *
 * The printed school timetable labels the December block "UT-3" and the
 * January-February block "UT-4", but the school actually runs those two blocks
 * as PRE-BOARD 1 and PRE-BOARD 2 (confirmed by Parth, Sep 2026). `printedAs`
 * keeps the old sheet label available purely as a UI caption so the app can
 * still be matched against the printed sheet.
 *
 * Paper dates come straight from the printed timetable, filtered to the six
 * papers Parth actually writes:
 *   "English-II"            -> english2
 *   "Maths / Appl. Maths"   -> maths
 *   "Bio. / Eco."           -> not taken (skipped)
 *   "Hindi / Computer"      -> cs
 *   "Phy. / Acc."           -> physics
 *   "Chemistry / Commerce"  -> chemistry
 *   "English-I"             -> english1
 *
 * IMPORTANT: the Pre-Board 1 block has no "Phy. / Acc." date on the sheet.
 * That is NOT a transcription error - the date is genuinely absent (confirmed).
 * physics is therefore null; render "date TBC" with a date picker, never a guess.
 *
 * dateStatus: 'confirmed'    - printed on the sheet
 *             'start_only'   - start printed, end unknown (do not invent one)
 *             'estimated'    - inferred; must be shown as unconfirmed
 * -------------------------------------------------------------------------- */
export const EXAMS = [
  {
    id: 'ut1',
    name: 'Unit Test 1',
    short: 'UT-1',
    kind: 'unit_test',
    status: 'completed',
    locked: true,
    start: '2026-05-02',
    end: '2026-05-15',
    dateStatus: 'confirmed',
    scopeRule: 'EXPLICIT',
    scopeStatus: 'printed',
    durationMins: 35,
    note: 'UT marks are added to the Half Yearly and Annual Examinations.',
    papers: {
      english2: '2026-05-02', maths: '2026-05-05', cs: '2026-05-08',
      physics: '2026-05-11', chemistry: '2026-05-13', english1: '2026-05-15',
    },
  },
  {
    id: 'ut2',
    name: 'Unit Test 2',
    short: 'UT-2',
    kind: 'unit_test',
    status: 'completed',
    locked: true,
    start: '2026-08-01',
    end: '2026-08-14',
    dateStatus: 'confirmed',
    scopeRule: 'EXPLICIT',
    scopeStatus: 'printed',
    durationMins: 35,
    note: 'UT marks are added to the Half Yearly and Annual Examinations.',
    papers: {
      english2: '2026-08-01', maths: '2026-08-04', cs: '2026-08-07',
      physics: '2026-08-10', chemistry: '2026-08-12', english1: '2026-08-14',
    },
  },
  {
    id: 'half_yearly',
    name: 'Half Yearly Examination',
    short: 'Half Yearly',
    kind: 'term_exam',
    status: 'active',
    locked: false,
    start: '2026-09-09',
    end: null,
    dateStatus: 'start_only',
    endNote: 'End date is not printed on the sheet and Parth does not have it. Leave open; let him set it.',
    scopeRule: 'FIRST_TERM',
    scopeStatus: 'derived',
    durationMins: null,
    note: 'Covers the whole First Term. UT-1 and UT-2 marks are added to this exam.',
    papers: {},
    papersNote: 'Per-paper dates were not printed for the Half Yearly. Let Parth fill them in.',
  },
  {
    id: 'preboard1',
    name: 'Pre-Board 1',
    short: 'PB-1',
    printedAs: 'UT-3',
    printedAsNote: 'The wall timetable calls this block "UT-3", but the school runs it as Pre-Board 1.',
    kind: 'preboard',
    status: 'upcoming',
    locked: false,
    start: '2026-12-09',
    end: '2026-12-22',
    dateStatus: 'confirmed',
    scopeRule: 'FULL_XII',
    scopeStatus: 'booklet',
    durationMins: null,
    allowTaughtOnlyToggle: true,
    note: 'Preliminary Examination I covers the entire Class XII syllabus (per the SYLLABI 2025-26 booklet). It falls in December, so offer a "limit to what is taught" switch.',
    papers: {
      english2: '2026-12-09', maths: '2026-12-11', cs: '2026-12-15',
      physics: null, chemistry: '2026-12-19', english1: '2026-12-22',
    },
    papersNote: 'Physics has no date in this block on the printed sheet (confirmed absent, not a typo). Render "date TBC".',
  },
  {
    id: 'preboard2',
    name: 'Pre-Board 2',
    short: 'PB-2',
    printedAs: 'UT-4',
    printedAsNote: 'The wall timetable calls this block "UT-4", but the school runs it as Pre-Board 2.',
    kind: 'preboard',
    status: 'upcoming',
    locked: false,
    start: '2027-01-27',
    end: '2027-02-09',
    dateStatus: 'confirmed',
    scopeRule: 'FULL_XII',
    scopeStatus: 'booklet',
    durationMins: null,
    allowTaughtOnlyToggle: false,
    note: 'Preliminary Examination II covers the entire Class XII syllabus. Final rehearsal - it ends only 4 days before the ISC boards begin.',
    papers: {
      english2: '2027-01-27', maths: '2027-01-29', cs: '2027-02-02',
      physics: '2027-02-04', chemistry: '2027-02-06', english1: '2027-02-09',
    },
  },
  {
    id: 'boards',
    name: 'ISC Board Examinations',
    short: 'ISC Boards',
    kind: 'board',
    status: 'upcoming',
    locked: false,
    start: '2027-02-13',
    end: null,
    dateStatus: 'start_only',
    endNote: 'Only the start date is printed. CISCE publishes the full date sheet later.',
    scopeRule: 'FULL_XII',
    scopeStatus: 'booklet',
    durationMins: null,
    note: 'The ISC Class XII paper is set on the Class XII portion only.',
    papers: {},
    papersNote: 'Fill in from the official CISCE date sheet when it is released.',
  },
]

export const EXAM_ORDER = ['ut1', 'ut2', 'half_yearly', 'preboard1', 'preboard2', 'boards']

/* ----------------------------------------------------------------------------
 * EXAM_SCOPE - explicit chapter-id scope, used only where the school printed an
 * exact portion. UT-1 and UT-2 are copied verbatim from the SYLLABI 2025-26
 * booklet and ship pre-ticked and locked.
 *
 * Everything else is computed from `scopeRule` + each chapter's `term`, so
 * there are no invented portions in this file:
 *   half_yearly -> FIRST_TERM
 *   preboard1 / preboard2 / boards -> FULL_XII
 * -------------------------------------------------------------------------- */
export const EXAM_SCOPE = {
  ut1: {
    physics: ['phy.electrostatics'],
    chemistry: ['chem.solutions'],
    maths: ['math.ch1_relation', 'math.ch2_function', 'math.ch4_inv_trig', 'math.ch5_determinants', 'math.ch6_matrices'],
    cs: ['cs.boolean', 'cs.hardware', 'cs.java_review_xi', 'cs.objects', 'cs.primitives_wrappers', 'cs.variables_expressions', 'cs.statements_scope', 'cs.methods', 'cs.algorithms'],
    english1: ['eng1.unit1', 'eng1.unit2', 'eng1.unit3', 'eng1.unit4'],
    english2: ['eng2.story_atithi', 'eng2.poem_telephone'],
  },
  ut2: {
    physics: ['phy.current'],
    chemistry: ['chem.haloalkanes', 'chem.named_reactions'],
    maths: ['math.ch7_continuity', 'math.ch8_differentiation', 'math.ch11_app_deriv', 'math.ch12_max_min'],
    cs: ['cs.arrays_strings', 'cs.inheritance', 'cs.interface', 'cs.stack'],
    english1: ['eng1.unit5', 'eng1.unit6', 'eng1.unit7', 'eng1.unit8'],
    english2: ['eng2.story_cookie_lady', 'eng2.poem_tithonus', 'eng2.macbeth_act3', 'eng2.macbeth_act4'],
  },
}

export const SCOPE_RULES = ['EXPLICIT', 'FIRST_TERM', 'SECOND_TERM', 'FULL_XII']

/* ----------------------------------------------------------------------------
 * resolveScope(examId) - order of precedence, highest first:
 *
 *   1. the user's saved override   (studyos.v2.syllabusOverrides.scope[examId])
 *   2. an explicit EXAM_SCOPE entry
 *   3. the exam's scopeRule, computed from each chapter's `term`:
 *        FIRST_TERM  -> chapters where term === 1
 *        SECOND_TERM -> chapters where term === 2
 *        FULL_XII    -> every chapter
 *
 * In every case, chapters with `optional: true` (Mathematics Section C) are
 * excluded unless the Section C elective toggle is switched on. Parth takes
 * PCM, so Section B applies and Section C stays off by default.
 *
 * Pre-Board 1 additionally supports a "limit to what is taught" switch: when it
 * is on, intersect the resolved scope with the chapters marked as covered in
 * school (the existing "School progress" checklist), and store the result as an
 * override. Never mutate the data in this file.
 * -------------------------------------------------------------------------- */

export default {
  SUBJECTS,
  SUBJECT_ORDER,
  PHYSICS_CHAPTERS,
  CHEMISTRY_CHAPTERS,
  MATHS_CHAPTERS,
  CS_CHAPTERS,
  ENGLISH1_CHAPTERS,
  ENGLISH2_CHAPTERS,
  SYLLABUS_XII,
  EXAMS,
  EXAM_ORDER,
  EXAM_SCOPE,
  SCOPE_RULES,
}

# StudyOS v2 - Build Prompt for Claude Code

> Paste this whole file as the first message in Claude Code, with `index.html` and
> `syllabus-exams.data.js` present in the working directory.
> Student: Parth Maurya - ISC Class XII - stream: **Physics, Chemistry, Mathematics, Computer Science, English I & II** (no Hindi, no Biology, no Commerce group).

---

## 0. Mission

You are upgrading an existing single-file study dashboard (`index.html`, ~2075 lines, vanilla JS,
no build step) called **StudyOS** into a production-quality study OS with:

1. **Exam Prep** - subject-wise, chapter-wise, topic-wise checklists and a progress tracker for
   **every exam of the year**: UT-1 (completed), UT-2 (completed), Half-Yearly, Pre-Board 1,
   Pre-Board 2, ISC Board Exams. There is no UT-3 and no UT-4.
2. **Pomodoro + AI YouTube lecture analysis** - paste a YouTube lecture link, the app analyses the
   video, extracts every topic with timestamps, shows them beside an embedded player in that tab,
   and runs a customisable Pomodoro timer (default 30 min focus / 5 min break, repeating).
3. **A genuine Apple-style "Liquid Glass" dark theme** - every tile is a clear glass slab with
   real refraction at its edges, lens-like light convergence, and a specular sheen that follows the
   pointer, floating over the supplied `LiquidEther` WebGL fluid background.

Everything that already works must keep working. This is an upgrade, not a rewrite from scratch.

---

## 1. How I want you to work

1. **Read before writing.** Start by reading `index.html` end to end and write a short
   `AUDIT.md` listing every function, state key, and tab you found. Do not begin coding until
   the audit is written.
2. **Work in the phases below, in order.** After each phase: run the app, screenshot it
   (headless Chromium at 1440x900 and 390x844), fix visual defects, then `git commit` with a
   conventional-commit message. Keep a running `PROGRESS.md`.
3. **Never leave the app broken between phases.** Every phase must end with a working app.
4. **Ask me only when genuinely blocked** on data I own (real exam dates, textbook unit titles,
   my API key). Everything else: choose the sensible default listed here and note it in `PROGRESS.md`.
5. **No placeholder/TODO features.** If a feature is in this document, it must actually work.
   No fake data, no `alert('coming soon')`, no dead buttons.
6. **Do not invent syllabus content.** Use `syllabus-exams.data.js` (supplied) and the existing
   `SYLLABUS` constant as the only sources. Anything marked `needsConfirmation: true` must render
   a small "verify" dot and be editable in the app, not silently guessed.

---

## 2. What the current app already has (audit summary)

Single file `index.html`: inline `<style>`, inline HTML shell, one inline `<script>`.
No framework, no bundler, no dependencies except Google Fonts (Space Grotesk / Space Mono).

- **Shell**: `#header` (logo, live clock, streak chip, FOCUS button), `#session-bar` (live progress
  of the current study block), `#tabs` (8 buttons using `data-tab`), `#content` (innerHTML swapped
  per tab), `#footer`, `#focus-overlay` (full-screen ring timer).
- **Tabs**: `dashboard`, `schedule`, `checklist`, `stats`, `events`, `tasks`, `uttimetable`, `aichat`.
- **Render pattern**: `renderContent()` switches on `state.tab` and assigns template strings to
  `#content.innerHTML`; live tabs re-render every 5 s via `setInterval`; a 1 s interval updates
  header/session bar. Interactive handlers are attached to `window.*` and called from inline
  `onclick` attributes.
- **Data constants**: `SESSIONS` (7 fixed study blocks 4 PM-11 PM), `SUBJECTS` (maths/physics/
  chemistry/revision with colours + targets), `EVENTS` (unit tests, pre-boards, half-yearly, board,
  holidays), `QUOTES`, `SYLLABUS` (physics/chemistry/maths -> chapters -> topics),
  `UT_CLASS12` (printed unit-test timetable).
- **State**: `state` object + `localStorage` via `lsGet`/`lsSet` with keys
  `studyos_completed`, `studyos_tasks`, `studyos_notes`, `studyos_checklist_my`,
  `studyos_checklist_school`, `studyos_streak`.
- **Checklist**: dual tracking - "My Progress" vs "Progress in School", keyed
  `` `${progressType}:${subject}:${chapterIdx}:${topicIdx}` `` (note: **index-based keys**, which
  break whenever a chapter is inserted - fixing this is part of Phase 2).
- **AI Tutor**: `callGroq()` posts to OpenRouter chat completions with a **hard-coded API key on
  line 1428** and model `nvidia/nemotron-3-super-120b-a12b:free`; `buildStudyContext()` injects
  progress into the system prompt; `mdToHtml()` renders replies; attachments are read as data URLs.

### Phase 0 - mandatory safety fixes before anything else

- The OpenRouter key on line 1428 is **exposed in plain text**. Remove it from source in your first
  commit. I will revoke it and issue a new one. Keys must live in
  `localStorage` (entered by me in Settings) or in a server `.env` - never in committed code.
- Add `.gitignore` (`.env`, `node_modules`, `dist`, `.DS_Store`) and `.env.example`.
- Convert the index-based checklist keys to id-based keys with a **one-time migration** so my
  existing ticks are not lost (see Phase 2.4).

---

## 3. Architecture decision (follow this exactly)

Keep the app **client-first and dependency-light**, but stop being one 120 KB file.

```
studyos/
  index.html                  # shell only: fonts, root divs, SVG filter defs, module entry
  src/
    main.js                   # boot, tab router, global intervals
    state/store.js            # single state object + pub/sub + persistence
    state/persist.js          # namespaced localStorage, schema version, export/import
    state/migrations.js       # v1 (studyos_*) -> v2 (studyos.v2.*)
    data/subjects.js          # from syllabus-exams.data.js
    data/syllabus.js          # resolved chapters+topics (legacy merge happens here)
    data/exams.js             # EXAMS + EXAM_SCOPE + resolveScope()
    data/sessions.js          # SESSIONS, EVENTS, UT_CLASS12 (moved out of index.html)
    features/dashboard/ schedule/ analytics/ events/ tasks/ utTimetable/ aiTutor/
    features/examPrep/        # Phase 2
    features/focusLab/        # Phase 3 (Pomodoro + YouTube + AI analysis)
    features/settings/        # Phase 4
    lib/liquidEther.js        # vanilla port of the supplied React component
    lib/glass.js              # pointer-tracked specular + tilt for .glass tiles
    lib/ai/gemini.js          # video understanding + JSON extraction
    lib/ai/openrouter.js      # existing chat path, key from settings
    lib/youtube.js            # url parsing + IFrame API wrapper
    lib/fuzzy.js              # topic -> syllabus chapter matching
    lib/{dom,time,format,storage,events}.js
    styles/{tokens,glass,base,layout,examPrep,focusLab,settings}.css
  server/                     # OPTIONAL proxy, only needed for the transcript fallback
    index.js routes/ai.js routes/transcript.js
  tests/smoke.spec.js         # Playwright
  package.json .env.example README.md AUDIT.md PROGRESS.md
```

Rules:

- **Native ES modules**, no framework, no JSX, no TypeScript. Keep the existing
  template-string rendering style so the code stays familiar to me.
- Dev server: `npm run dev` (Vite). Also provide `npm run build:single`, which uses
  `vite-plugin-singlefile` to emit **one portable `dist/studyos.html`** I can double-click or drop
  on a USB stick. This is a hard requirement - the app must survive as a single file.
- `three` is the only runtime dependency (for `LiquidEther`). Pin the version in `package.json`
  and also vendor it into `dist` for the single-file build.
- The Node server is **optional and off by default**: the app must be fully functional without it.
  Set `AI_MODE` in Settings: `direct` (browser -> AI provider, key from localStorage) or
  `proxy` (browser -> `/api/*` -> provider, key from `.env`).

---

## 4. Phase plan

| Phase | Deliverable |
|---|---|
| 0 | Audit, safety fixes, repo scaffolding, module split with zero behaviour change |
| 1 | Liquid Glass design system + `LiquidEther` background + retheme all existing tabs |
| 2 | **Exam Prep** tab: per-exam subject/chapter/topic checklists + trackers + migration |
| 3 | **Focus Lab** tab: YouTube player + AI topic extraction sidebar + Pomodoro engine |
| 4 | Settings tab (Pomodoro, AI keys, appearance, exam dates, syllabus editor, data) |
| 5 | Dashboard/Analytics integration, hardening, a11y, performance, tests, docs |

---

## 5. Phase 1 - Apple "Liquid Glass" dark theme

### 5.1 What I mean by liquid glass

Every tile must read as a **thick slab of clear glass floating above a moving fluid**, not a flat
translucent rectangle. Four things must be present on every tile:

1. **Refraction** - content behind the tile is blurred, saturated and slightly displaced/warped,
   strongest within ~14 px of the edges (like looking through a bevelled lens).
2. **Edge lensing / light convergence** - a bright caustic rim that is brightest where the light
   source (pointer) is closest, fading around the perimeter, plus a thin inner highlight on the top
   edge and a soft light pool on the bottom-inner edge.
3. **Specular sheen** - a soft moving highlight that tracks the pointer across the tile surface.
4. **Liquid motion** - the rim highlight and sheen ease with spring-like damping, so moving the
   pointer makes light appear to *flow* along the edges. Hover raises the tile and increases
   refraction; press compresses it slightly.

### 5.2 Tokens (`styles/tokens.css`)

```css
:root{
  /* canvas */
  --bg-0:#050508; --bg-1:#0a0a12; --bg-vignette:radial-gradient(120% 80% at 50% -10%,#12122400,#03030699);
  /* glass */
  --glass-tint:rgba(255,255,255,.055);
  --glass-tint-strong:rgba(255,255,255,.085);
  --glass-blur:26px;
  --glass-sat:190%;
  --glass-brightness:1.08;
  --glass-edge:rgba(255,255,255,.22);
  --glass-edge-bright:rgba(255,255,255,.55);
  --glass-inner-shadow:rgba(4,4,10,.55);
  --glass-radius:24px;      /* large surfaces */
  --glass-radius-sm:16px;   /* chips, inputs */
  /* text on glass */
  --text:#F5F5F7; --text-2:rgba(235,235,245,.66); --text-3:rgba(235,235,245,.38);
  /* semantic */
  --ok:#4ADE80; --warn:#F5C842; --risk:#FF6B6B; --info:#60B5FF; --accent:#8B5CF6;
  /* subject colours - keep identical to v1 so muscle memory survives */
  --phy:#60B5FF; --chem:#4ADE80; --math:#F5C842; --cs:#C084FC; --eng1:#A5B4FC; --eng2:#93C5FD;
  /* motion */
  --ease-glass:cubic-bezier(.22,.61,.36,1); --dur-fast:160ms; --dur:260ms; --dur-slow:520ms;
}
```

Keep the existing fonts (Space Grotesk / Space Mono). Body text 15-16 px / 1.5, small text floor
13 px. On glass, always keep text contrast >= 4.5:1 - if a tile sits over a bright fluid region,
the scrim layer (5.3) must guarantee it.

### 5.3 The glass recipe (`styles/glass.css`)

Build the tile from **four stacked layers**, in this order:

```css
.glass{
  position:relative; isolation:isolate;
  border-radius:var(--glass-radius);
  background:
    linear-gradient(180deg,rgba(255,255,255,.10),rgba(255,255,255,.02) 38%,rgba(255,255,255,.045)),
    var(--glass-tint);
  backdrop-filter:blur(var(--glass-blur)) saturate(var(--glass-sat)) brightness(var(--glass-brightness));
  -webkit-backdrop-filter:blur(var(--glass-blur)) saturate(var(--glass-sat)) brightness(var(--glass-brightness));
  box-shadow:
    inset 0 1px 0 rgba(255,255,255,.34),          /* top light line */
    inset 0 -14px 26px -14px rgba(255,255,255,.16),/* bottom light pool  */
    inset 0 0 0 1px rgba(255,255,255,.07),         /* glass body edge    */
    0 1px 2px rgba(0,0,0,.4), 0 18px 44px -20px rgba(0,0,0,.75);
  transition:transform var(--dur) var(--ease-glass), box-shadow var(--dur) var(--ease-glass),
             backdrop-filter var(--dur) var(--ease-glass);
  will-change:transform;
}

/* LAYER 2 - edge refraction ring: re-samples the backdrop, displaced by an SVG filter,
   masked to a ~14px band so only the rim warps (this is what sells "thick glass"). */
.glass::before{
  content:""; position:absolute; inset:0; border-radius:inherit; pointer-events:none; z-index:0;
  backdrop-filter:blur(6px) saturate(240%) brightness(1.15);
  -webkit-backdrop-filter:blur(6px) saturate(240%) brightness(1.15);
  filter:url(#lg-refract);
  -webkit-mask:
    linear-gradient(#000,#000) content-box,
    linear-gradient(#000,#000);
  -webkit-mask-composite:xor; mask-composite:exclude;
  padding:14px;   /* = thickness of the lens band */
}

/* LAYER 3 - specular sheen + caustic rim, driven by --mx/--my (0..1) from lib/glass.js */
.glass::after{
  content:""; position:absolute; inset:0; border-radius:inherit; pointer-events:none; z-index:1;
  background:
    radial-gradient(220px 160px at calc(var(--mx,.5)*100%) calc(var(--my,.5)*100%),
      rgba(255,255,255,.16), rgba(255,255,255,.04) 45%, transparent 70%),
    conic-gradient(from calc(var(--ang,0deg) - 90deg),
      rgba(255,255,255,.55), rgba(255,255,255,.06) 22%, rgba(255,255,255,0) 45%,
      rgba(255,255,255,.06) 78%, rgba(255,255,255,.5));
  -webkit-mask:linear-gradient(#000,#000) content-box, linear-gradient(#000,#000);
  -webkit-mask-composite:xor; mask-composite:exclude; padding:1.25px;  /* caustic rim only */
  opacity:.9; transition:opacity var(--dur) var(--ease-glass);
}

.glass > *{position:relative; z-index:2}

.glass:hover{ transform:translateY(-2px) scale(1.006);
  --glass-blur:30px; --glass-sat:210%;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.45), inset 0 -16px 30px -14px rgba(255,255,255,.22),
              inset 0 0 0 1px rgba(255,255,255,.10), 0 2px 4px rgba(0,0,0,.45), 0 26px 60px -22px rgba(0,0,0,.8); }
.glass:active{ transform:translateY(0) scale(.997) }
.glass:focus-visible{ outline:2px solid rgba(139,92,246,.75); outline-offset:2px }
```

SVG filter (put once in `index.html`, `width=0 height=0 aria-hidden`):

```html
<svg class="lg-defs" width="0" height="0" aria-hidden="true">
  <filter id="lg-refract" x="-20%" y="-20%" width="140%" height="140%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="0.008 0.012" numOctaves="2" seed="7" result="noise">
      <animate attributeName="baseFrequency" dur="18s" values="0.008 0.012;0.011 0.008;0.008 0.012" repeatCount="indefinite"/>
    </feTurbulence>
    <feGaussianBlur in="noise" stdDeviation="1.2" result="softNoise"/>
    <feDisplacementMap in="SourceGraphic" in2="softNoise" scale="18" xChannelSelector="R" yChannelSelector="G" result="warp"/>
    <feSpecularLighting in="softNoise" surfaceScale="3" specularConstant="1.1" specularExponent="36"
                        lighting-color="#ffffff" result="spec">
      <fePointLight id="lg-light" x="120" y="-40" z="140"/>
    </feSpecularLighting>
    <feComposite in="spec" in2="warp" operator="in" result="specClip"/>
    <feBlend in="warp" in2="specClip" mode="screen"/>
  </filter>
</svg>
```

`lib/glass.js` responsibilities:

- One `pointermove` listener on `document` (passive, rAF-throttled). For each visible `.glass`
  tile: set `--mx`, `--my` (pointer position inside the tile, 0-1) and `--ang` (angle from tile
  centre to pointer) so the caustic rim rotates toward the light.
- Spring-damp the values (`lerp` at ~0.14/frame) so light *flows* rather than snaps.
- Move `#lg-light`'s `x`/`y` to follow the pointer in page space (one shared light source for the
  whole UI - this is what makes the tiles feel like they are lit by the same lamp).
- Only process tiles that are on screen: `IntersectionObserver` + skip when `document.hidden`.
- If `matchMedia('(prefers-reduced-motion: reduce)')` or Settings > Appearance > "Glass motion" is
  off: freeze the sheen at the centre and remove the `<animate>` on the turbulence.
- Feature detection: if `CSS.supports('backdrop-filter','blur(1px)')` is false, add
  `html.no-glass` and fall back to `background:rgba(18,18,28,.88)` + gradient border, no filters.
- Performance guard: if the tab averages < 45 fps for 2 s, add `html.glass-lite` which drops
  `::before` (edge refraction) and lowers blur to 14 px. Log the downgrade in Settings > Appearance.

Apply `.glass` to: cards, tab bar, header, footer, session bar, modals, sidebar panels, the
Pomodoro widget, chat bubbles (`--glass-radius-sm`), inputs and buttons (thinner recipe:
`blur(14px)`, 1 px rim, no `::before`).

### 5.4 `LiquidEther` background - vanilla port (`lib/liquidEther.js`)

Port the React component I supplied into a framework-free class with this API:

```js
const ether = new LiquidEther(document.getElementById('bg-fluid'), {
  colors:['#5227FF','#8B5CF6','#22D3EE'], backgroundColor:'#050508', lightMode:false,
  mouseForce:20, cursorSize:100, resolution:0.5, dt:0.014, BFECC:true,
  isViscous:false, viscous:30, iterationsViscous:32, iterationsPoisson:32, isBounce:false,
  autoDemo:true, autoSpeed:0.5, autoIntensity:2.2, takeoverDuration:0.25,
  autoResumeDelay:1000, autoRampDuration:0.6,
});
ether.start(); ether.pause(); ether.setOptions({...}); ether.setPalette([...]); ether.dispose();
```

Keep the physics identical (advection with BFECC, external force, optional viscosity, divergence,
Poisson pressure solve, pressure projection, palette-mapped colour pass, boundary line segments,
auto-demo driver with idle resume and smoothstep takeover).

**The snippet I pasted has real bugs - fix them during the port:**

| Bug in the pasted source | Fix |
|---|---|
| `WebGLManager` is constructed with `{ wrapper: container }` but reads `props.$wrapper` | use one key (`wrapper`) consistently |
| `Mouse.dispose()` references `this.*onTouchStart`, `this.onTouchMove`, `this.onTouchEnd`, `this.onDocumentLeave` | remove the exact bound handlers `_onTouchStart`, `_onTouchMove`, `_onTouchEnd`, `_onDocumentLeave` |
| `Viscous` is built with `dst:` twice (`vel_viscous1` then `vel_viscous0`) so `output0`/`output1` alias the same FBO and ping-pong breaks | pass `dst0: fbos.vel_viscous0`, `dst1: fbos.vel_viscous1` and set `output0`/`output1` from them |
| `Poisson` is built with `dst:` and `dst*:` (typo) so pressure ping-pong aliases | pass `dst0: fbos.pressure_0`, `dst1: fbos.pressure_1` |
| `ShaderPass.update()` writes `this.props.output` but `Viscous`/`Poisson` mutate `props.output` per iteration | keep, but return the final FBO explicitly (already done) and reset `props.output` after the loop |
| listeners are attached to `window` even when the canvas is off-screen | attach to the container, keep the hover gate, and detach on `dispose()` |
| no float-texture capability check | `renderer.capabilities.isWebGL2` / `EXT_color_buffer_float` check; fall back to `HalfFloatType`, and if unavailable set `html.no-fluid` and render a static CSS gradient instead |

Mount rules:

- `#bg-fluid` is `position:fixed; inset:0; z-index:0; pointer-events:none;` and the whole app sits
  at `z-index:1`. The fluid must be **visible through the tiles**, which is the entire point.
- Because `pointer-events:none` means the canvas never receives events, feed the simulation from
  `lib/glass.js`'s shared pointer stream via `ether.setPointer(clientX, clientY)`; keep
  `autoDemo` for idle drift.
- Pause on `document.hidden`, when `IntersectionObserver` reports off-screen, when a Pomodoro focus
  phase is running **and** Settings > Appearance > "Calm during focus" is on (default on -
  it drops GPU load and distraction), and when `html.glass-lite` is active (then drop
  `resolution` to 0.35 instead of pausing).
- Palette must be themeable from Settings with 4 presets: `Aurora` (#5227FF/#8B5CF6/#22D3EE),
  `Nebula` (#FF9FFC/#B497CF/#5227FF - the original), `Ink` (#1E3A8A/#312E81/#0EA5E9),
  `Off` (static gradient, zero GPU).
- Respect `prefers-reduced-motion`: default to `Off` with a note explaining why.

### 5.5 Retheme the existing tabs

Convert every existing `.card` into `.glass`, restyle the tab bar as a floating glass pill row with
an animated liquid indicator, restyle the focus overlay as frosted glass over a blurred snapshot,
and keep every existing number/label. **No feature may be removed while retheming.**

---

## 6. Phase 2 - Exam Prep (the most important feature)

New tab **Exam Prep**, placed right after Dashboard. Uses `syllabus-exams.data.js` (supplied).

### 6.1 Exams to support (all nine)

| id | Name | Dates | Status | Scope |
|---|---|---|---|---|
| `ut1` | Unit Test 1 | 02-15 May 2026 | **completed, locked** | printed booklet scope |
| `ut2` | Unit Test 2 | 01-14 Aug 2026 | **completed, locked** | printed booklet scope |
| `half_yearly` | Half-Yearly | from 09 Sep 2026 | active | whole First Term |
| `preboard1` | Pre-Board 1 (sheet says "UT-3") | 09-22 Dec 2026 | upcoming | entire Class XII syllabus |
| `preboard2` | Pre-Board 2 (sheet says "UT-4") | 27 Jan-09 Feb 2027 | upcoming | entire Class XII syllabus |
| `boards` | ISC Board Exams | from 13 Feb 2027 | upcoming | entire Class XII syllabus |

Rules:

- **UT-1 and UT-2 must ship pre-marked as completed**: exam status `completed`, every topic in
  their scope ticked, the card shown with a green "Completed" ribbon, checkboxes read-only until I
  press "Unlock to edit". Their contribution to Half-Yearly marks is noted on the card
  ("UT marks are added to the Half Yearly and Annual Examinations", from the printed timetable).
- **There is no UT-3 and no UT-4.** My printed timetable labels the December block "UT-3" and the
  January-February block "UT-4", but the school actually runs them as **Pre-Board 1** and
  **Pre-Board 2**. Relabel them everywhere - Exam Prep, the Events calendar, and the timetable tab -
  and keep the printed label only as a small secondary caption (`printedAs`), so I can still match
  the app against the sheet on my wall. The old `EVENTS` entries in `index.html` carry
  `ut:"3"` / `ut:"4"`; remap them, do not delete my calendar.
- Both pre-boards are full-syllabus (`scopeRule: 'FULL_XII'`). Pre-Board 1 falls in December, when
  the Second Term may not be finished, so its card gets a one-tap **"Limit to what is taught"**
  switch that intersects the scope with chapters marked taught-in-school. Save it as a scope
  override; never mutate the shipped data.
- The 35-minute paper duration printed on the sheet applies to the unit tests only. Do not show it
  on the pre-boards.
- Half-Yearly has no printed end date and I do not have one. Show "from 09 Sep 2026" with an
  editable end date and never render an invented one.
- **Physics has no paper date in the Pre-Board 1 block** - confirmed, it is genuinely missing from
  the sheet. Render that cell as "date TBC" with a date picker, not as blank and not as a guess.
- Exams whose `dateStatus === 'estimated'` show an amber "date not confirmed" chip with an inline
  date picker. Never present an estimate as fact.
- `resolveScope(examId)` order of precedence: **my saved override > explicit `EXAM_SCOPE` entry >
  `scopeRule`** (`FIRST_TERM` / `SECOND_TERM` / `FULL_XII`, computed from each chapter's `term`).
  Optional chapters (Maths Section C) are excluded unless the elective toggle is on.

### 6.2 Data model (v2 storage)

Namespace everything under `studyos.v2.*`. Two separate concerns - do not merge them:

```js
// A) GLOBAL topic mastery - the truth about what I know. Never exam-specific.
// key: `${subjectKey}|${chapterId}|${topicId}`   (topicId = slug of the topic string)
mastery[key] = {
  status: 'not_started' | 'learning' | 'revised' | 'mastered',
  school: false,          // has school taught it (replaces the old "Progress in School" tab)
  confidence: 0..5,
  revisions: 0,
  lastRevisedAt: null,    // ISO
  nextReviewAt: null,     // ISO, spaced repetition
  minutes: 0,             // study minutes attributed from Pomodoro sessions
  flagged: false,         // "weak topic"
  note: '',
  sources: []             // [{type:'youtube', videoId, topicId, at}]
}

// B) PER-EXAM preparation state - what I have prepared for THAT exam.
examProgress[examId] = {
  checked: { [topicKey]: true },       // manual tick for this exam
  autoFromMastery: true,               // when true, mastery>=revised auto-ticks (still overridable)
  scopeOverride: null | { [subjectKey]: chapterId[] },
  targetDate: '2026-09-09',
  mocks: [{ id, date, subject, marksObtained, marksTotal, note }],
  reflection: '',
  completedAt: null
}
```

Also: `studyos.v2.settings`, `studyos.v2.pomodoro`, `studyos.v2.videos`, `studyos.v2.schemaVersion`.

`topicId` must be a **stable slug** (`lowercase`, non-alphanumerics to `-`, collapse repeats,
truncate 48 chars, dedupe with `-2` suffix). Never index-based again.

### 6.3 UI

**Level 1 - exam rail.** Horizontal scroll row of nine glass exam cards. Each card: exam name,
date + countdown ("in 0 days" / "today" / "completed"), a progress ring, readiness label, and a
subject dot strip whose dots are filled proportionally. The active exam is selected and persisted.
Completed exams are dimmed with a green ribbon.

**Level 2 - selected exam header.** Big readiness ring, "X of Y topics ready", days left, a
segmented bar per subject, and three actions: `Study plan`, `Edit scope`, `Mark exam complete`.

**Level 3 - subject accordions** (order: Physics, Chemistry, Maths, CS, Eng-I, Eng-II).
Header: icon, name, `chapters in scope . topics in scope`, percent, ring, paper date for this exam
if known. Only chapters in scope for the selected exam are listed; a toggle "show out-of-scope"
reveals the rest, greyed.

**Level 4 - chapter rows.** Chapter number (school numbering for Maths, e.g. "Ch 11"), name,
`done/total` chip, tri-state checkbox (empty / partial / done), a "taught in school" pill, revision
count badge (`R2`), and an expand caret.

**Level 5 - topic rows.** Checkbox (writes both `examProgress.checked` and, on first tick,
`mastery.status = 'revised'`), topic text, 5-dot confidence selector, `+ Revise` button
(increments `revisions`, sets `lastRevisedAt`, schedules `nextReviewAt`), flag icon, note icon,
and a small "minutes studied" figure when > 0. Long-press / right-click opens a context menu with
"Add to today's plan", "Find a YouTube lecture" (jumps to Focus Lab pre-filled), "Mark for all exams".

All interactions must be **optimistic and instant** (no full-tab re-render on a tick: patch the
DOM node, update the aggregates, debounce persistence by 250 ms).

### 6.4 Migration from v1 (must not lose my data)

`state/migrations.js`, run once, guarded by `schemaVersion`:

1. Read `studyos_checklist_my` and `studyos_checklist_school`.
2. Parse each key `type:subject:chapterIdx:topicIdx`; resolve `chapterIdx`/`topicIdx` against the
   **v1** `SYLLABUS` array order (embed a frozen copy of the v1 chapter/topic name arrays in
   `migrations.js` so resolution stays correct after chapters are split).
3. Map v1 chapter -> v2 chapter id using `legacyName` / `legacySplit.match` rules in the data file.
4. Write `mastery[key].status = 'revised'` (from `my`) and `mastery[key].school = true` (from `school`).
5. Auto-tick UT-1 and UT-2 scopes as completed. Preserve `studyos_tasks`, `studyos_notes`,
   `studyos_completed`, `studyos_streak` as-is under the new namespace.
6. Keep the v1 keys untouched as a backup, and write `studyos.v2.migrationReport` with counts;
   surface it once as a dismissible toast: "Imported 84 ticks from your old checklist."

### 6.5 Tracker / analytics per exam

- **Readiness score** (0-100): `55 * coverage + 25 * revisionDepth + 20 * confidence`, where
  `coverage = checked/inScope`, `revisionDepth = min(avgRevisions/2, 1)`,
  `confidence = avgConfidence/5`. Show the formula in a tooltip. Bands: <40 red, 40-69 amber,
  70-89 blue, 90+ green.
- **Pace**: topics per day needed to finish scope before the exam vs my actual 7-day average.
  Render as "You need 6/day, you are doing 4.2/day" with an amber/green state.
- **Risk list**: top 8 topics in scope that are unticked, or flagged, or `revisions === 0`, or
  `nextReviewAt` overdue - sorted by (chapter weight x days-left urgency).
- **Revision queue**: every topic with `nextReviewAt <= today`, grouped by subject, with a
  "Start 30-min revision" button that opens Focus Lab with those topics attached.
- **Spaced repetition**: intervals 1, 3, 7, 16, 35 days by `revisions`, clamped so the last review
  lands at least 2 days before the exam.
- **Coverage vs school**: two-line chart (my progress vs school progress) over time, sampled daily
  into `studyos.v2.history` (keep 400 points max).
- **Subject heatmap**: chapters x confidence grid for the selected exam.
- **Mock marks**: add mock/test scores per exam per subject; plot them; show average and delta.

### 6.6 Study plan generator

`Study plan` button produces a day-by-day plan from today to the exam date: distributes unticked
in-scope topics across available days, respects the existing `SESSIONS` blocks (Maths 4-6 PM,
Physics 6:15-8:15 PM, Chemistry 8:30-10:30 PM, Revision 10:45-11 PM), weights subjects by
remaining volume, inserts revision-queue items first, and leaves the last 3 days for revision only.
Output: a glass table I can accept (writes to `studyos.v2.plan`) or regenerate. Today's plan items
also appear on the Dashboard and can be completed from there.

---

## 7. Phase 3 - Focus Lab (Pomodoro + AI YouTube analysis)

New tab **Focus Lab**. This replaces nothing; the old `focus-overlay` stays for schedule sessions.

### 7.1 Layout

Desktop (>= 1100 px), one glass shell split into two columns:

```
+---------------------------------------------------------------+-------------------+
| [ paste YouTube link ............................. ] [Analyse]|  POMODORO (glass) |
|                                                               |  25:00 ring       |
|  +---------------------------------------------------------+  |  Focus 3 of 4     |
|  |                  YouTube IFrame player                  |  |  [Start][Skip][+] |
|  +---------------------------------------------------------+  +-------------------+
|  timeline strip with topic segments + current-position marker |  TOPICS (sticky)  |
|  video title . channel . duration . "Analysed 2 min ago"      |  1. 00:00 Intro   |
|  [Re-analyse] [Export notes] [Attach to exam: Half-Yearly v]  |  2. 04:12 ...     |
+---------------------------------------------------------------+-------------------+
```

Mobile / < 1100 px: player on top, Pomodoro as a compact sticky bar under it, topics list below,
plus a floating "jump to timer" button. The topic list column is ~380 px, scrolls independently,
and the player is sticky while the list scrolls.

### 7.2 YouTube player

- Use the **YouTube IFrame Player API** (`https://www.youtube.com/iframe_api`), loaded lazily the
  first time the tab opens. Player vars: `enablejsapi:1`, `origin:location.origin`, `rel:0`,
  `modestbranding:1`, `playsinline:1`, `cc_load_policy:0`.
- Accept every URL shape: `watch?v=`, `youtu.be/`, `/shorts/`, `/live/`, `/embed/`, with or
  without `&t=90s` / `?start=`, playlists (`&list=` -> use the video, mention the playlist),
  and a bare 11-char video id. Reject anything else with a helpful inline error.
- Poll `getCurrentTime()` every 250 ms **only while playing**; use `onStateChange` to start/stop
  polling. Never poll on a hidden tab.
- Persist per-video playback position (`videos[videoId].lastPosition`) and offer "Resume at 12:40".
- Player must be **inside this tab only**. When I switch tabs: pause the video, keep the Pomodoro
  running, and destroy nothing (keep the player instance so returning is instant).
- Handle embed failures (`onError` 101/150 = embedding disabled) with a clear message plus an
  "Open on YouTube" link, and still allow AI analysis of that URL.

### 7.3 AI topic extraction - the pipeline

**Primary provider: Google Gemini API (`gemini-2.5-flash`).** This is the only mainstream API that
understands a YouTube URL natively - you pass the link as a `fileData` part and it watches the
video (audio + visuals + on-screen text), so timestamps come back grounded in the actual video
rather than guessed from a transcript.

Request shape (`lib/ai/gemini.js`):

```js
POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent
headers: { 'x-goog-api-key': KEY, 'Content-Type': 'application/json' }
body: {
  contents: [{ role:'user', parts: [
    { fileData: { fileUri: 'https://www.youtube.com/watch?v=...' } },
    { text: USER_PROMPT }
  ]}],
  systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
  generationConfig: {
    temperature: 0.2,
    responseMimeType: 'application/json',
    responseSchema: TOPIC_SCHEMA,
    thinkingConfig: { thinkingBudget: 0 }   // faster + cheaper; raise to 1024 for dense lectures
  }
}
```

`TOPIC_SCHEMA` (enforced, so no JSON repair is needed):

```json
{
  "type":"object",
  "required":["videoSummary","subject","topics"],
  "properties":{
    "videoSummary":{"type":"string"},
    "subject":{"type":"string","enum":["physics","chemistry","maths","cs","english","other"]},
    "language":{"type":"string"},
    "topics":{"type":"array","items":{
      "type":"object",
      "required":["title","startSec","summary","kind"],
      "properties":{
        "title":{"type":"string"},
        "startSec":{"type":"integer"},
        "endSec":{"type":"integer"},
        "kind":{"type":"string","enum":["concept","derivation","formula","numerical","example","revision","admin"]},
        "summary":{"type":"string"},
        "keyPoints":{"type":"array","items":{"type":"string"}},
        "formulas":{"type":"array","items":{"type":"string"}},
        "difficulty":{"type":"string","enum":["easy","medium","hard"]},
        "importance":{"type":"string","enum":["low","medium","high"]},
        "syllabusChapterId":{"type":"string"},
        "syllabusConfidence":{"type":"number"}
      }}}
  }
}
```

`SYSTEM_PROMPT` must say, in substance: *"You are a study assistant for an ISC (CISCE) Class XII
PCM + Computer Science + English student in India. Watch the lecture and produce a precise,
chronological topic index. Rules: every `startSec` must be the exact second the topic actually
begins in this video, verified against what is said or shown on screen; never invent timestamps or
extrapolate evenly; merge fragments shorter than 20 s into the neighbouring topic; label ads,
channel promos, greetings and 'subscribe' segments as kind `admin`; write titles in exam vocabulary
(e.g. 'Gauss's law - derivation for a line charge', not 'part 2'); write each `summary` in 1-2
sentences a student can revise from; put actual formulas in LaTeX-free plain text in `formulas`;
if Hinglish or Hindi is spoken, output English titles and set `language`; map each topic to the
closest chapter id from the provided syllabus list and give `syllabusConfidence` 0-1, or omit both
if nothing fits. Return 8-40 topics."*

`USER_PROMPT` appends the compact syllabus index (chapter ids + names for the six subjects,
generated from `SYLLABUS_XII` - keep it under ~2.5k tokens by sending ids + names only).

**Post-processing (`lib/ai/normalize.js`) - always run, never trust raw output:**

1. Coerce `startSec` to integers; drop negatives; clamp to the video duration from the player.
2. Sort by `startSec`; drop exact duplicates; merge topics whose gap is < 20 s or whose titles are
   >= 0.9 similar (Dice coefficient on bigrams).
3. Force monotonic `startSec`; derive missing `endSec` from the next topic's start (last topic ends
   at video duration).
4. Cap at 40 topics (merge the least important overflow into neighbours).
5. Re-map `syllabusChapterId`: accept only ids that exist in `SYLLABUS_XII`; otherwise fuzzy-match
   the title against chapter and topic names (normalised token overlap) and mark
   `mapping: 'fuzzy'` so the UI can show it as a suggestion rather than a fact.
6. Stamp `{ model, provider, analysedAt, promptVersion }` on the result.

**Caching:** `studyos.v2.videos[videoId] = { title, channel, durationSec, topics, meta, lastPosition,
notes, topicChecks }`. Re-opening a link is instant and costs nothing; "Re-analyse" forces a refetch
(with a confirm, because it costs quota). Cap the cache at 60 videos (LRU) and expose
"Clear video cache" in Settings.

**Fallback chain**, in order, each step surfaced in the UI as a small provider chip:

1. Gemini `gemini-2.5-flash` with `fileData` (best: real video understanding).
2. Gemini `gemini-2.5-pro` retry **only** if flash returns < 4 topics for a video longer than
   10 minutes (dense lecture).
3. **Transcript mode** (works without video understanding): fetch timed captions, chunk them, and
   ask any chat model to segment them. Captions cannot be fetched from the browser because of CORS,
   so this path requires the optional local proxy (`server/index.js`, endpoint
   `GET /api/transcript?v=<id>` using `youtube-transcript` / Innertube `player` + `timedtext`).
   Then call the configured chat model with the timed lines. Keep the same schema and normalizer.
4. **Manual mode**: always available. "Add topic at current time" button + editable list, so the
   feature is never dead when there is no key, no quota, or no captions.

**Errors, quota and abort:**

- 400 `INVALID_ARGUMENT` on `fileData` (private/age-restricted/region-locked video) -> explain and
  offer transcript or manual mode.
- 429 -> exponential backoff (2 s, 6 s, 14 s, jitter), then show remaining-quota guidance.
- 5xx -> 2 retries, then fall back.
- Every request goes through an `AbortController` wired to a "Cancel" button and a 180 s timeout
  (long videos are slow). Show a determinate-ish progress state: `Uploading link -> Watching video
  -> Extracting topics -> Mapping to syllabus`.
- Never block the UI: analysis runs while I can already watch the video and run the timer.

**Key handling:** the key lives in `localStorage` under `studyos.v2.settings.ai.geminiKey`, entered
by me in Settings, masked in the UI, never committed, never logged. Show the honest warning:
*"Keys stored in a browser can be read by anything running in this browser - use a key restricted
to the Generative Language API, and prefer proxy mode if you deploy this publicly."* When
`AI_MODE === 'proxy'`, the browser calls `/api/analyze` and the key stays in the server's `.env`.

### 7.4 Topic sidebar behaviour

- Each row: index, `mm:ss` chip, title, kind icon, difficulty dot, one-line summary (2-line clamp),
  chevron to expand `keyPoints` + `formulas` + a personal note box.
- **Click the timestamp -> `seekTo(startSec, true)`** and play. Click the row body -> expand.
- The topic containing the current playback second gets an active state (bright caustic rim, subtle
  scale) and the list auto-scrolls to keep it centred - suppressed for 4 s after I scroll manually.
- Checkbox per topic: writes `videos[videoId].topicChecks[topicId]` **and**, when the topic is
  mapped to a syllabus chapter with confidence >= 0.6, bumps that syllabus topic's mastery to at
  least `learning` and appends a `sources` entry. Show a tiny "synced to Exam Prep" badge.
- Header shows `covered 6/18 . 34 min of 52 min watched`.
- "Export notes" produces Markdown (title, link, per-topic `mm:ss`, summary, key points, my notes)
  and copies it to the clipboard / downloads `.md`.
- "Attach to exam" links the video to an exam, so the Exam Prep chapter row can show
  "2 lectures attached".
- Timeline strip under the player: proportional segments coloured by `importance`, hover tooltip,
  click to seek, current-position marker synced to playback.
- Keyboard: `space` play/pause, `j`/`l` -/+ 10 s, `k` pause, `n`/`p` next/previous topic,
  `f` fullscreen, `m` mute, `t` add topic at current time, `1-9` seek to topic n.

### 7.5 Pomodoro engine (`lib/pomodoro.js`)

- Defaults: **30 min focus / 5 min short break / 15 min long break, long break after 4 focus
  blocks**, all editable in Settings (focus 5-120, short 1-30, long 5-60, cycles 2-8).
- **Timestamp-based, not tick-based**: store `{ phase, startedAt, endsAt, cyclesDone, isRunning,
  pausedRemainingMs }` in `localStorage` and compute remaining time from `Date.now()`. This must
  survive reload, tab throttling, and sleep. On resume, if `endsAt` is in the past, roll phases
  forward correctly and tell me what happened ("Focus finished 12 min ago - break skipped").
- Controls: Start / Pause / Resume / Reset / Skip phase / +5 min. Ring shows remaining time, phase
  name, and `Focus 3 of 4`.
- Auto-behaviour toggles (all default on except the last): auto-start breaks, auto-start next focus,
  **auto-pause the YouTube video when a break starts and auto-resume when focus starts**, calm the
  fluid background during focus, block tab switching nags, strict mode (confirm before reset).
- End-of-phase feedback: Web Notification (request permission on first Start, never on load), a
  soft generated chime via WebAudio (`OscillatorNode`, 0.4 s, respect a volume slider and a mute
  toggle - do not ship an audio file), a document-title flash, and a full-bleed glass phase-change
  card for 6 s.
- Optional `navigator.wakeLock` while a focus phase runs (guarded feature-detect, Settings toggle).
- **Session log**: every completed phase appends `{ id, phase, startedAt, endedAt, minutes,
  subject?, examId?, videoId?, topicIds[] }` to `studyos.v2.sessions`. Focus minutes are attributed
  to the current video's mapped syllabus topics (or to a subject I pick in a one-tap prompt), which
  feeds `mastery.minutes`, the existing streak, and the Stats tab.
- Dashboard integration: today's focus minutes, blocks completed, current phase mini-ring in the
  header, and the existing streak logic extended to count "a focus block completed" as activity.

---

## 8. Phase 4 - Settings, and wiring the old tabs into the new system

New tab **Settings** (gear icon, last position), rendered as glass sections with instant-apply and
a visible "Saved" micro-toast.

1. **Pomodoro** - focus / short break / long break minutes, cycles before long break, the six
   auto-behaviour toggles, chime volume + mute, notification permission button, wake-lock toggle,
   "Reset to 30/5/15".
2. **AI** - provider (`Gemini` default, `Transcript + chat model` fallback, `Manual only`), model
   picker (`gemini-2.5-flash`, `gemini-2.5-pro`, `gemini-2.0-flash`), API key field (masked, with
   "Test key" that does a 1-token call and reports latency), mode (`direct` / `proxy` + proxy URL),
   max topics, thinking budget, and the honest key-safety note. Also a key field for the existing
   AI Chat tab so **no key is ever hard-coded again**.
3. **Appearance** - glass intensity (Subtle / Standard / Intense: drives blur, tint, rim opacity),
   glass motion on/off, fluid background palette (Aurora / Nebula / Ink / Off), fluid resolution
   (Performance / Balanced / Quality), "calm fluid during focus", reduced-motion override, and an
   FPS readout with the auto-downgrade state.
4. **Exams** - editable table of all nine exams: name, start date, end date, per-subject paper
   dates, status (upcoming / active / completed / locked), and "edit scope" which opens a
   chapter-picker per subject. Electives: **Maths Section B (default for PCM) vs Section C** -
   toggling Section C on/off must instantly change every scope, ring and readiness number.
5. **Syllabus editor** - add / rename / delete chapters and topics per subject, mark a chapter
   `taught in school`, and confirm the amber `needsConfirmation` items (English-I unit titles,
   Macbeth Act V scene count, CS Arrays and Strings placement). Edits live in
   `studyos.v2.syllabusOverrides` and are deep-merged over the shipped data, so the shipped file
   stays pristine and updatable.
6. **Data** - export everything to a timestamped JSON, import with a dry-run diff preview
   ("this will add 12 ticks and change 3 dates"), "clear video cache", and a two-step
   "reset everything".

Also in Phase 4:

- **Dashboard** gets three new glass tiles: "Next exam" (countdown + readiness ring),
  "Today's plan" (from the study-plan generator, tickable), "Focus today" (minutes + blocks + a
  7-day sparkline).
- **Stats** gains focus minutes by subject, blocks per day, readiness trend per exam, and mock-marks
  charts. Draw charts with inline SVG (no chart library).
- **AI Chat** keeps working but now reads the key from Settings and gets the new context: current
  exam, readiness, weakest topics, today's plan, last analysed video. Add a "Quiz me on my weak
  topics" quick action that pulls flagged topics from mastery.
- **UT Timetable** tab is renamed **Exam Timetable**: paper dates for all six exams from
  `EXAMS[].papers`, with the December and Jan-Feb blocks shown as Pre-Board 1 and Pre-Board 2
  (caption: "printed as UT-3 / UT-4"), and the missing Pre-Board 1 Physics slot as "date TBC" with a
  date picker. Never show rows for papers I do not take (Hindi, Bio/Eco, Commerce/Accounts).

---

## 9. Phase 5 - Hardening, accessibility, performance, docs

**Robustness**

- Wrap every renderer in a try/catch that renders a glass error card with a "Copy diagnostics"
  button instead of blanking the tab. Add `window.onerror` / `unhandledrejection` handlers.
- Wrap all `localStorage` access in `state/storage.js` with try/catch, JSON validation, a
  quota-exceeded path (prune `history` and video cache, then warn), and schema versioning.
- `esc()` every interpolated string. Any AI-generated text is untrusted: escape it, and never
  `innerHTML` it raw. Render AI Markdown through a tiny allow-list renderer.
- Debounce persistence (250 ms), and `requestIdleCallback` the heavy aggregate recomputations.
- Replace the blanket 5 s full-tab re-render with targeted updates (clock, session bar, timer ring
  via rAF; lists only on state change).

**Accessibility**

- Every checkbox is a real focusable control with `role="checkbox"` + `aria-checked` (including the
  tri-state chapter rows: `aria-checked="mixed"`), reachable and togglable by keyboard.
- Visible focus rings on glass (2 px violet, 2 px offset). Tab order follows visual order.
- Hit targets >= 44x44 px on touch. Accordions use `aria-expanded` + `aria-controls`.
- Live regions: `aria-live="polite"` for phase changes and "Saved"; `aria-live="assertive"` for
  errors. Timer announces at phase change, not every second.
- Text contrast >= 4.5:1 over glass in the worst-case backdrop; add a scrim layer if needed.
- Full keyboard map documented in Settings > About.

**Performance budget**

- 60 fps on a 2019-class laptop with the fluid at `resolution: 0.5` and up to 24 glass tiles
  on screen. Never exceed 24 tiles with `::before` refraction; beyond that use the lite recipe.
- First paint of the app shell < 400 ms; `three` and the YouTube API are lazy-loaded.
- No layout thrash: batch reads then writes in the pointer rAF loop.

**Tests**

- Unit tests (`node --test`, no framework needed): slug stability, migration mapping,
  `resolveScope` for all nine exams x electives on/off, readiness maths, spaced-repetition dates,
  YouTube URL parsing (12+ shapes), topic normalizer (overlaps, dupes, out-of-range, monotonic),
  Pomodoro phase rollover across a simulated 3-hour sleep.
- One Playwright smoke test: load `dist/studyos.html`, assert every tab renders, tick a topic and
  confirm the ring changes, start the timer and confirm it counts down, mock the Gemini call with a
  fixture and confirm topics render and seek on click.

**Docs**

- `README.md`: what it is, how to run (`npm i`, `npm run dev`, `npm run build`), where to get a
  Gemini key, how to switch to proxy mode, storage keys, how to edit the syllabus, and a
  "my data is in localStorage - export regularly" warning.
- `PROGRESS.md`: phase checklist you update as you go, with screenshots.
- `SYLLABUS_SOURCES.md`: every chapter/topic traced to "printed booklet" vs "estimated" vs
  "derived from index.html", so I can audit what to verify with my school.

---

## 10. Acceptance criteria (I will check these)

1. `dist/studyos.html` opens by double-click, works offline except AI calls, and keeps my old data.
2. Exactly six exam cards exist. **UT-1 and UT-2 show 100% and a Completed ribbon out of the box**,
   locked until unlocked. The strings "UT-3" and "UT-4" appear nowhere except as the small
   `printedAs` caption on the two pre-boards.
3. Every subject is exactly: Physics, Chemistry, Maths, Computer Science, English-I, English-II.
   No Hindi, no Biology, no Commerce anywhere in the UI or data.
4. Half-Yearly scope = full First Term. Pre-Board 1, Pre-Board 2 and Boards scope = entire Class XII
   syllabus, with Pre-Board 1 offering "limit to what is taught". Every scope stays editable.
5. Ticking a topic updates: chapter ring, subject ring, exam readiness, dashboard tile, and stats -
   without a visible re-render flash, and it survives a reload.
6. Pasting a YouTube lecture link produces a chronological topic list with timestamps beside the
   player; clicking a timestamp seeks the video; the active topic highlights as it plays.
7. Pomodoro runs 30/5 with a long break after 4 blocks, is fully customisable in Settings, survives
   a reload mid-phase, and auto-pauses the video on breaks.
8. Every tile is unmistakably liquid glass: refracted edges, a caustic rim that brightens toward the
   pointer, a moving specular sheen, and the fluid background visible through it. Screenshot proof
   in `PROGRESS.md`.
9. No API key anywhere in the repo. `git log -p | grep -i "sk-or-v1"` returns nothing new.
10. Keyboard-only navigation reaches every control; no contrast failures at AA.

## 11. Do not break

The existing Dashboard, Schedule (with `SESSIONS` timings), Checklist (as "My progress" vs
"School progress"), Stats, Events calendar, Tasks + Notes, UT Timetable, AI Chat, streak logic,
focus overlay, header clock and footer countdown must all still work, restyled, with data intact.

## 12. Decisions already made - do not ask me these again

1. **Six exams only**: UT-1, UT-2, Half-Yearly, Pre-Board 1, Pre-Board 2, Boards. No UT-3, no UT-4.
2. **Pre-board dates** are exactly the two blocks printed on my timetable (09-22 Dec 2026 and
   27 Jan-09 Feb 2027). I have no other date sheet - treat these as confirmed, keep them editable.
3. **Half-Yearly end date**: unknown. Leave it open rather than inventing one.
4. **English-I unit titles**: not needed. Ship "Unit 1" ... "Unit 15" with the five standard
   per-unit topics and stop flagging them for confirmation.
5. **Physics in Pre-Board 1**: genuinely absent from the sheet. Show "date TBC".
6. **Maths Section C**: not mine (PCM -> Section B). Keep the Section C toggle off by default.
7. **AI setup**: the zero-setup path is the default - `AI_MODE: 'direct'`, the browser calls Gemini
   with the key I paste into Settings. Also build the Node proxy and keep it fully working behind
   `AI_MODE: 'proxy'` (the transcript fallback needs it), but the app must be flawless without ever
   starting a server. Never make me run a backend to tick a checkbox or watch a lecture.
8. If anything here is unsafe, slow, or plainly wrong, say so and propose the better version rather
   than silently doing something else.

Work phase by phase, commit often, and show me screenshots at the end of each phase.

---

## Appendix A - the supplied data file `syllabus-exams.data.js`

I am giving you a second file, `syllabus-exams.data.js`. **Use it as the single source of truth for
syllabus and exam scope. Do not invent chapters, topics, dates or scopes.** It exports:

| Export | What it is |
|---|---|
| `SUBJECTS`, `SUBJECT_ORDER` | the six subjects, colours, textbook names |
| `PHYSICS_CHAPTERS` (10), `CHEMISTRY_CHAPTERS` (11), `MATHS_CHAPTERS` (26), `CS_CHAPTERS` (16), `ENGLISH1_CHAPTERS` (19), `ENGLISH2_CHAPTERS` (13) | chapter records with `id`, `no`, `name`, `term`, `section`, `optional` |
| `SYLLABUS_XII` | `{ physics, chemistry, maths, cs, english1, english2 }` |
| `EXAMS` | the 6 exam records (UT-1, UT-2, Half-Yearly, Pre-Board 1, Pre-Board 2, Boards) with dates, `dateStatus`, `scopeRule`, per-subject `papers`, and `printedAs` for the two pre-boards |
| `EXAM_SCOPE` | explicit chapter-id scope for UT-1 and UT-2, copied verbatim from the printed portions |
| `SCOPE_RULES` | `FIRST_TERM`, `SECOND_TERM`, `FULL_XII` |

### A.1 Topic resolution contract (important)

Computer Science, English-I and English-II chapters carry their own `topics` arrays (~314 topics).
Physics, Chemistry and Maths chapters instead **reference the topic strings that already exist in
`index.html`'s `SYLLABUS` constant**, so we never retype or drift from what I already tick today:

- `topicsFrom: 'legacy'` + `legacyName` -> copy that legacy chapter's `topics` array as-is.
- `legacySplit: { from, match[], rest }` -> the school splits one legacy chapter into several
  school chapters. Take `SYLLABUS[*].chapters[name === from].topics` and assign each topic to the
  first chapter whose `match` array has a case-insensitive substring hit; a chapter with
  `rest: true` collects everything still unassigned.
- `fallbackTopics` -> used when the legacy chapter has no matching topics (e.g. Inverse
  Trigonometric Functions, which the old app never listed separately).

Implement this once in `data/resolveTopics.js` and note two gotchas I already hit:

1. The legacy names use an **en dash** (`Algebra – Matrices`, `Calculus – Integration`), not a
   hyphen. Normalise dashes (`–`, `—` -> `-`), `&` -> `and`, and collapse whitespace before
   comparing, so a future edit to either file cannot silently break the join.
2. The legacy shape is `SYLLABUS[subject] = { name, color, icon, chapters: [{ name, topics }] }` -
   not a bare array.

**Ship a validator** (`npm run validate:syllabus`) that fails loudly if any chapter resolves to
zero topics, any `EXAM_SCOPE` id is unknown, or any chapter id is duplicated. I already ran this
check; it currently passes with these totals - reproduce them:

```
physics    10 chapters   ~95 topics (resolved from legacy, Optics split 10 / 4)
chemistry  11 chapters  ~124 topics (incl. 27 named reactions)
maths      26 chapters  ~100 topics (school chapter numbers preserved)
cs         16 chapters   109 topics
english1   19 chapters   103 topics (15 units + 4 skill sets)
english2   13 chapters   102 topics (Macbeth III-V + 5 poems + 5 stories)
```

### A.2 Things marked for me to confirm (`needsConfirmation: true`)

Render these with a small amber "verify" dot and make them editable in the Syllabus Editor -
do **not** present them as certain:

- English-I unit titles stay generic ("Unit 1" ... "Unit 15") by my choice - do not flag them.
- Macbeth Act V scene count (assumed 8).
- CS "Arrays and Strings" placement (it appears in the UT-2 portion but not as a separate Term-1
  heading in the booklet).
- Chemistry "Named Reactions" as a standalone revision set (printed as a UT-2 head).
- The Half-Yearly end date (unknown) and the missing Pre-Board 1 Physics paper date.

---

## Appendix B - subjects, verbatim

My stream is **PCM + Computer Science + English** at an ISC (CISCE) school. The six papers are
English-I (Language), English-II (Literature), Physics, Chemistry, Mathematics, Computer Science.
There is **no Hindi, no Biology, no Commerce** paper - if you see one anywhere in the old code or
in your own defaults, remove it.

Books: Nootan Physics Vol. II, Nootan ISC Chemistry Vol. II, S. Chand ISC Mathematics Book II,
Oswal ISC Computer Science, Total English XII (Morning Star), and Macbeth / Rhapsody / Reverie /
Prism / Echoes for Literature.

---

## Appendix C - the background component I want

I pasted a React `LiquidEther` component (three.js Navier-Stokes fluid: BFECC advection, external
force from the pointer, optional viscosity, Jacobi Poisson pressure solve, palette-mapped colour
pass, auto-demo driver). Requirements:

1. Port it to a **framework-free class** as described in section 5.4 - the app must stay
   dependency-light; `three` is the only runtime dependency.
2. Fix the bugs listed in the section 5.4 table (aliased ping-pong FBOs in `Viscous` and `Poisson`,
   the `$wrapper` key mismatch, the broken handler references in `Mouse.dispose()`).
3. Dark palette by default (`backgroundColor: '#050508'`, `lightMode: false`) so it reads as deep
   space behind the glass, never a bright wash behind my text.
4. Make it customisable from Settings (palette preset, resolution, on/off) and make it pause when
   hidden, off-screen, in lite mode, or during a focus block if I enable "calm during focus".

It is fine to change the palette, the intensity and the internals - the goal is the feel: slow
coloured ink drifting behind thick glass, reacting when I move the pointer.

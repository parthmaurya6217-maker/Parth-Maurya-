/**
 * data/sessions.js — daily study blocks, calendar events, quotes.
 * EVENTS exam rows are DERIVED from EXAMS[].papers (the six papers Parth writes),
 * so there is never a Hindi/Bio/Commerce row. Non-exam rows (holidays, school
 * reopenings, PTM) are carried over from the v1 calendar, relabelled for the
 * pre-boards via `printedAs` captions.
 */
import { EXAMS } from './exams.js'
import { SUBJECTS } from '../../syllabus-exams.data.js'

export const SESSIONS = [
  { id: 0, label: "Mathematics", subtitle: "Concept / Practice", type: "study", start: [16, 0], end: [18, 0], subject: "maths", icon: "∑" },
  { id: 1, label: "Break", type: "break", start: [18, 0], end: [18, 15], subject: null, icon: "☕" },
  { id: 2, label: "Physics", subtitle: "Concept / Numericals", type: "study", start: [18, 15], end: [20, 15], subject: "physics", icon: "⚛" },
  { id: 3, label: "Break", type: "break", start: [20, 15], end: [20, 30], subject: null, icon: "☕" },
  { id: 4, label: "Chemistry", subtitle: "Concept / Practice", type: "study", start: [20, 30], end: [22, 30], subject: "chemistry", icon: "⚗" },
  { id: 5, label: "Break", type: "break", start: [22, 30], end: [22, 45], subject: null, icon: "☕" },
  { id: 6, label: "Revision", subtitle: "All Subjects", type: "revision", start: [22, 45], end: [23, 0], subject: "revision", icon: "◈" },
]

const V1_NON_EXAM_EVENTS = [
  { date: "2026-05-16", label: "Summer Vacation Begins", type: "holiday" },
  { date: "2026-07-01", label: "School Re-opens", type: "school" },
  { date: "2026-08-15", label: "Independence Day", type: "holiday" },
  { date: "2026-08-29", label: "Parent-Teacher Meeting", type: "meeting" },
  { date: "2026-09-09", label: "Half Yearly Exams Begin", type: "exam", kind: "begin" },
  { date: "2026-10-01", label: "School Re-opens", type: "school" },
  { date: "2026-12-23", label: "Winter Vacation Begins", type: "holiday" },
  { date: "2027-01-03", label: "School Re-opens", type: "school" },
  { date: "2027-02-13", label: "ISC Board Exams Begin", type: "exam", kind: "begin" },
]

const SUBJECT_ROW = {
  english2: 'English-II', english1: 'English-I', physics: 'Physics', chemistry: 'Chemistry',
  maths: 'Maths', cs: 'Computer Science',
}

/** Build the exam-row events from EXAMS[].papers. */
function examEvents() {
  const out = []
  for (const exam of EXAMS) {
    const printed = exam.printedAs ? ` (printed as ${exam.printedAs})` : ''
    for (const [subjKey, date] of Object.entries(exam.papers || {})) {
      if (!date) continue
      out.push({
        date,
        type: 'exam',
        examId: exam.id,
        label: `${exam.short} · ${SUBJECT_ROW[subjKey] || SUBJECTS[subjKey]?.name || subjKey}${printed}`,
        short: true,
      })
    }
  }
  return out.sort((a, b) => a.date.localeCompare(b.date))
}

export const EVENTS = [...examEvents(), ...V1_NON_EXAM_EVENTS].sort((a, b) => a.date.localeCompare(b.date))

export const UT_CLASS12 = [
  {
    ut: "UT-1", examId: "ut1", color: "#F5C842", startDate: "02 May 2026",
    exams: [
      { date: "02.05.26", day: "Sat", subject: "English – II", subjectColor: "#60B5FF" },
      { date: "05.05.26", day: "Tue", subject: "Maths", subjectColor: "#F5C842" },
      { date: "08.05.26", day: "Fri", subject: "Computer Science", subjectColor: "#C084FC" },
      { date: "11.05.26", day: "Mon", subject: "Physics", subjectColor: "#FB923C" },
      { date: "13.05.26", day: "Wed", subject: "Chemistry", subjectColor: "#2DD4BF" },
      { date: "15.05.26", day: "Fri", subject: "English – I", subjectColor: "#60B5FF" },
    ],
  },
  {
    ut: "UT-2", examId: "ut2", color: "#4ADE80", startDate: "01 Aug 2026",
    exams: [
      { date: "01.08.26", day: "Sat", subject: "English – II", subjectColor: "#60B5FF" },
      { date: "04.08.26", day: "Tue", subject: "Maths", subjectColor: "#F5C842" },
      { date: "07.08.26", day: "Fri", subject: "Computer Science", subjectColor: "#C084FC" },
      { date: "10.08.26", day: "Mon", subject: "Physics", subjectColor: "#FB923C" },
      { date: "12.08.26", day: "Wed", subject: "Chemistry", subjectColor: "#2DD4BF" },
      { date: "14.08.26", day: "Fri", subject: "English – I", subjectColor: "#60B5FF" },
    ],
  },
  {
    ut: "Pre-Board 1", printedAs: "UT-3", examId: "preboard1", color: "#C084FC", startDate: "09 Dec 2026",
    exams: [
      { date: "09.12.26", day: "Wed", subject: "English – II", subjectColor: "#60B5FF" },
      { date: "11.12.26", day: "Fri", subject: "Maths", subjectColor: "#F5C842" },
      { date: "15.12.26", day: "Tue", subject: "Computer Science", subjectColor: "#C084FC" },
      { date: "19.12.26", day: "Sat", subject: "Chemistry", subjectColor: "#2DD4BF" },
      { date: "22.12.26", day: "Tue", subject: "English – I", subjectColor: "#60B5FF" },
    ],
  },
  {
    ut: "Pre-Board 2", printedAs: "UT-4", examId: "preboard2", color: "#FB923C", startDate: "27 Jan 2027",
    exams: [
      { date: "27.01.27", day: "Wed", subject: "English – II", subjectColor: "#60B5FF" },
      { date: "29.01.27", day: "Fri", subject: "Maths", subjectColor: "#F5C842" },
      { date: "02.02.27", day: "Tue", subject: "Computer Science", subjectColor: "#C084FC" },
      { date: "04.02.27", day: "Thu", subject: "Physics", subjectColor: "#FB923C" },
      { date: "06.02.27", day: "Sat", subject: "Chemistry", subjectColor: "#2DD4BF" },
      { date: "09.02.27", day: "Tue", subject: "English – I", subjectColor: "#60B5FF" },
    ],
  },
]

export const QUOTES = [
  "The secret of getting ahead is getting started.",
  "Success is the sum of small efforts, repeated daily.",
  "Excellence is not a destination but a continuous journey.",
  "Hard work beats talent when talent doesn't work hard.",
  "Don't count the days — make the days count.",
]

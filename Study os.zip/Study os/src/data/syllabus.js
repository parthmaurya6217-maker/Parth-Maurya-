/**
 * data/syllabus.js — the resolved, runtime syllabus used by every feature.
 * Combines syllabus-exams.data.js metadata with legacy topic resolution,
 * then deep-merges user overrides (rename/add/delete chapters + topics) from
 * studyos.v2.syllabusOverrides. The shipped file stays pristine.
 */
import base from '../../syllabus-exams.data.js'
import { buildSyllabus } from './resolveTopics.js'

const { SUBJECTS, SUBJECT_ORDER, SYLLABUS_XII } = base

let _chapters = null      // resolved, no overrides
let _syllabus = null      // resolved + overrides
let _chapterById = null
let _topicKeyByText = null

/** Rebuild the internal structures from the shipped chapters. */
export function rebuild() {
  _chapters = buildSyllabus(SYLLABUS_XII)
  _syllabus = null
  _chapterById = null
  _topicKeyByText = null
}

export function applyOverrides(overrides) {
  rebuild()
  const o = overrides || {}
  const edited = {}
  for (const subjectKey of SUBJECT_ORDER) {
    const subj = _chapters[subjectKey]
    const edits = o.chapters && o.chapters[subjectKey]
    const keep = []
    for (const ch of subj) {
      if (edits && edits.removed && edits.removed.includes(ch.id)) continue
      const rename = edits && edits.renamed && edits.renamed[ch.id]
      const topicEdits = edits && edits.topics && edits.topics[ch.id]
      const topics = ch.topics.map(t => {
        if (topicEdits && topicEdits.removed && topicEdits.removed.includes(t.id)) return null
        const newTitle = topicEdits && topicEdits.renamed && topicEdits.renamed[t.id]
        return newTitle ? { ...t, title: newTitle } : t
      }).filter(Boolean)
      keep.push(rename ? { ...ch, name: rename, topics } : { ...ch, topics })
    }
    const added = (edits && edits.added) || []
    for (const a of added) {
      if (!keep.some(c => c.id === a.id)) keep.push(a)
    }
    edited[subjectKey] = keep
  }
  _syllabus = edited
  return edited
}

export function syllabus() {
  if (!_syllabus) applyOverrides(null)
  return _syllabus
}

export function chapters() {
  if (!_chapters) rebuild()
  return _chapters
}

export function chapterById() {
  if (_chapterById) return _chapterById
  const m = new Map()
  for (const subjectKey of SUBJECT_ORDER) {
    for (const ch of syllabus()[subjectKey]) m.set(ch.id, { subjectKey, chapter: ch })
  }
  _chapterById = m
  return m
}

/** topicKey = `${subjectKey}|${chapterId}|${topicId}` */
export function topicKey(subjectKey, chapterId, topicId) {
  return `${subjectKey}|${chapterId}|${topicId}`
}

/** Reverse lookup: text -> key, used by the AI normalizer and fuzzy checks. */
export function topicKeyByText() {
  if (_topicKeyByText) return _topicKeyByText
  const m = new Map()
  for (const subjectKey of SUBJECT_ORDER) {
    for (const ch of syllabus()[subjectKey]) {
      for (const t of ch.topics) {
        const norm = t.title.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim()
        m.set(norm, topicKey(subjectKey, ch.id, t.id))
      }
    }
  }
  _topicKeyByText = m
  return m
}

export function topicTexts() {
  const out = []
  for (const subjectKey of SUBJECT_ORDER) {
    for (const ch of syllabus()[subjectKey]) {
      for (const t of ch.topics) out.push({ subjectKey, chapter: ch, topic: t })
    }
  }
  return out
}

export function totals() {
  const out = { chapters: 0, topics: 0, bySubject: {} }
  for (const subjectKey of SUBJECT_ORDER) {
    const chs = syllabus()[subjectKey]
    const topics = chs.reduce((a, c) => a + c.topics.length, 0)
    out.bySubject[subjectKey] = { chapters: chs.length, topics }
    out.chapters += chs.length
    out.topics += topics
  }
  return out
}

/** Compact chapter index for AI prompts (ids + names, small). */
export function compactIndex() {
  const lines = []
  for (const subjectKey of SUBJECT_ORDER) {
    lines.push(`${SUBJECTS[subjectKey].name.toUpperCase()}:`)
    for (const ch of syllabus()[subjectKey]) {
      lines.push(`  ${ch.id} | ${ch.name}`)
    }
  }
  return lines.join('\n')
}

export { SUBJECTS, SUBJECT_ORDER }

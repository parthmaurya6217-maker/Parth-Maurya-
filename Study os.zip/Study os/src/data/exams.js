/**
 * data/exams.js — the six exams + scope resolution.
 * Order of precedence for resolveScope(examId):
 *   1. saved override (studyos.v2.examProgress[examId].scopeOverride)
 *   2. explicit EXAM_SCOPE entry
 *   3. scopeRule (FIRST_TERM / SECOND_TERM / FULL_XII from each chapter's term)
 * Optional chapters (Maths Section C) are excluded unless the elective toggle is on.
 * Pre-Board 1's "limit to what is taught" intersects with school-taught chapters.
 */
import base from '../../syllabus-exams.data.js'
import { SUBJECT_ORDER, syllabus } from './syllabus.js'

const { EXAMS, EXAM_ORDER, EXAM_SCOPE, SCOPE_RULES } = base

export { EXAMS, EXAM_ORDER, EXAM_SCOPE, SCOPE_RULES }

/** In-scope chapter ids for an exam given resolved chapter list + options. */
export function resolveScope(examId, opts = {}) {
  const exam = EXAMS.find(e => e.id === examId)
  if (!exam) return { subjects: {}, inScope: new Set(), chapterCount: 0, topicCount: 0, source: 'unknown' }

  const override = opts.override || null          // saved scopeOverride { [subject]: chapterId[] }
  const sectionC = !!opts.sectionC                 // Maths Section C elective
  const taughtOnly = !!opts.taughtOnly              // PB-1 "limit to what is taught"
  const taughtChapterIds = opts.taughtChapterIds || new Set() // chapters with ≥1 school-taught topic

  let scope = {}
  let source = 'derived'

  if (override && Object.keys(override).length) {
    scope = JSON.parse(JSON.stringify(override))
    source = 'override'
  } else if (EXAM_SCOPE[examId]) {
    scope = JSON.parse(JSON.stringify(EXAM_SCOPE[examId]))
    source = 'explicit'
  } else if (exam.scopeRule === 'FIRST_TERM') {
    for (const sk of SUBJECT_ORDER) {
      scope[sk] = syllabus()[sk].filter(c => c.term === 1).map(c => c.id)
    }
    source = 'first_term'
  } else if (exam.scopeRule === 'SECOND_TERM') {
    for (const sk of SUBJECT_ORDER) {
      scope[sk] = syllabus()[sk].filter(c => c.term === 2).map(c => c.id)
    }
    source = 'second_term'
  } else if (exam.scopeRule === 'FULL_XII') {
    for (const sk of SUBJECT_ORDER) {
      scope[sk] = syllabus()[sk].map(c => c.id)
    }
    source = 'full_xii'
  }

  // Elective filter: drop optional chapters (Section C) unless the toggle is on.
  const inScope = new Set()
  for (const sk of SUBJECT_ORDER) {
    const ids = scope[sk] || []
    scope[sk] = ids.filter(id => {
      const ch = syllabus()[sk].find(c => c.id === id)
      if (!ch) return false
      if (ch.optional && !sectionC) return false
      return true
    })
    scope[sk].forEach(id => inScope.add(id))
  }

  // PB-1 taught-only: intersect with school-taught chapters.
  if (taughtOnly) {
    for (const sk of SUBJECT_ORDER) {
      scope[sk] = scope[sk].filter(id => taughtChapterIds.has(id))
    }
    inScope.clear()
    for (const sk of SUBJECT_ORDER) scope[sk].forEach(id => inScope.add(id))
    source += '+taught'
  }

  // Counts
  let chapterCount = 0, topicCount = 0
  const subjects = {}
  for (const sk of SUBJECT_ORDER) {
    const chs = scope[sk] || []
    chapterCount += chs.length
    const topics = chs.reduce((a, id) => {
      const ch = syllabus()[sk].find(c => c.id === id)
      return a + (ch ? ch.topics.length : 0)
    }, 0)
    topicCount += topics
    subjects[sk] = { chapters: chs, topicCount: topics }
  }

  return { subjects, inScope, chapterCount, topicCount, source, override: scope }
}

/** Which subjects have a printed paper date for this exam? */
export function examPaperDate(exam, subjectKey) {
  if (!exam || !exam.papers) return null
  return exam.papers[subjectKey] || null
}

export function examById(id) {
  return EXAMS.find(e => e.id === id)
}

/** days until exam start; negative when past */
export function daysUntil(dateStr) {
  const t = new Date(dateStr + 'T00:00:00')
  const today = new Date(); today.setHours(0, 0, 0, 0)
  return Math.round((t - today) / 86400000)
}

/**
 * FROZEN v1 SYLLABUS (from index.html) — never edit.
 * This is the byte-exact chapter/topic layout the v1 checklist keys reference,
 * so migration and topic resolution stay correct even after chapters are split.
 * Physics/Chemistry/Maths only: the v1 app tracked no CS/English.
 */
export const LEGACY_SYLLABUS = {
  physics: {
    name: "Physics", color: "#60B5FF", icon: "⚛",
    chapters: [
      { name: "Electrostatics", topics: [
        "Coulomb's Law & Electric Charges", "Superposition Principle", "Electric Field & Field Lines",
        "Electric Dipole & Torque", "Electric Flux & Gauss's Theorem", "Applications of Gauss's Law",
        "Electric Potential & Potential Energy", "Equipotential Surfaces", "Conductors & Capacitance",
        "Dielectrics & Polarisation", "Parallel Plate Capacitor", "Energy Stored in Capacitor"] },
      { name: "Current Electricity", topics: [
        "Electric Current & Drift Velocity", "Ohm's Law & Resistivity", "Combination of Resistances",
        "Kirchhoff's Laws", "Wheatstone Bridge", "EMF & Internal Resistance",
        "Potentiometer – Principle", "Potentiometer Applications"] },
      { name: "Magnetic Effects of Current & Magnetism", topics: [
        "Biot-Savart Law", "Ampere's Circuital Law", "Solenoid & Toroid",
        "Force on Moving Charge in Magnetic Field", "Force Between Parallel Current-Carrying Conductors",
        "Torque on Current Loop", "Moving Coil Galvanometer", "Earth's Magnetism & Magnetic Elements",
        "Magnetisation & Magnetic Intensity", "Dia, Para & Ferromagnetism", "Hysteresis"] },
      { name: "Electromagnetic Induction & AC", topics: [
        "Faraday's Laws of Electromagnetic Induction", "Lenz's Law", "Self-Inductance", "Mutual Inductance",
        "AC Generator – Principle & Working", "AC Circuits: Resistor, Inductor, Capacitor",
        "LCR Series Circuit & Resonance", "Power in AC Circuits", "Transformer – Ideal & Losses"] },
      { name: "Electromagnetic Waves", topics: [
        "Displacement Current", "Maxwell's Equations (qualitative)", "Electromagnetic Spectrum", "Properties of EM Waves"] },
      { name: "Optics", topics: [
        "Reflection of Light – Mirror Formula", "Refraction of Light – Snell's Law",
        "Total Internal Reflection & Applications", "Refraction at Spherical Surfaces",
        "Thin Lens Formula & Lens Maker's Formula", "Power of a Lens", "Combination of Lenses & Mirrors",
        "Prism – Angle of Deviation", "Optical Instruments: Microscope", "Optical Instruments: Telescope",
        "Huygens' Principle", "Young's Double Slit Experiment", "Diffraction of Light", "Polarisation & Malus's Law"] },
      { name: "Dual Nature of Radiation & Matter", topics: [
        "Photoelectric Effect – Experimental Setup", "Laws of Photoelectric Emission",
        "Einstein's Photoelectric Equation", "Wave-Particle Duality", "de Broglie Hypothesis", "Davisson-Germer Experiment"] },
      { name: "Atoms & Nuclei", topics: [
        "Bohr's Model of Hydrogen Atom", "Hydrogen Spectrum – Spectral Series", "Nuclear Composition & Size",
        "Radioactivity: α, β, γ Decay", "Radioactive Decay Law & Half-Life", "Nuclear Binding Energy",
        "Nuclear Fission – Chain Reaction", "Nuclear Fusion"] },
      { name: "Electronic Devices", topics: [
        "Energy Bands in Solids", "Intrinsic & Extrinsic Semiconductors", "p-n Junction Formation",
        "Forward & Reverse Bias", "Half-Wave & Full-Wave Rectifiers", "Special Diodes: Zener, LED, Photodiode",
        "Solar Cell", "Transistor – npn & pnp", "Transistor as Amplifier", "Transistor as Switch",
        "Logic Gates: AND, OR, NOT", "Logic Gates: NAND, NOR", "Boolean Algebra"] },
    ]
  },
  chemistry: {
    name: "Chemistry", color: "#4ADE80", icon: "⚗",
    chapters: [
      { name: "Solutions", topics: [
        "Types of Solutions & Concentration Terms", "Normality, Molality, Molarity, Mole Fraction",
        "Henry's Law – Solubility of Gases", "Raoult's Law – Volatile & Non-Volatile Solutes",
        "Ideal & Non-Ideal Solutions", "Azeotropic Mixtures", "Colligative Properties – Introduction",
        "Relative Lowering of Vapour Pressure", "Elevation in Boiling Point", "Depression in Freezing Point",
        "Osmotic Pressure & Reverse Osmosis", "van't Hoff Factor – Abnormal Molecular Mass"] },
      { name: "Electrochemistry", topics: [
        "Electrochemical Cells – Introduction", "Galvanic Cells & Cell Notation", "Standard Electrode Potential",
        "Electrochemical Series", "Nernst Equation & Applications", "Gibbs Energy & Cell EMF",
        "Electrolytic Conduction – Conductance", "Kohlrausch's Law", "Faraday's Laws of Electrolysis",
        "Dry Cell & Lead Accumulator", "Fuel Cells", "Corrosion – Mechanism & Prevention"] },
      { name: "Chemical Kinetics", topics: [
        "Rate of Reaction & Rate Expressions", "Average & Instantaneous Rate", "Order & Molecularity of Reaction",
        "Zero Order Reactions", "First Order Reactions & Half-Life", "Second Order Reactions",
        "Integrated Rate Equations", "Arrhenius Equation & Activation Energy", "Collision Theory",
        "Catalysis – Types & Mechanism"] },
      { name: "d- and f-Block Elements", topics: [
        "General Properties of Transition Metals", "Variable Oxidation States", "Complex Formation",
        "Coloured Compounds", "Magnetic Properties", "Important Compounds: KMnO₄", "Important Compounds: K₂Cr₂O₇",
        "Lanthanoids – Properties & Uses", "Actinoids – Properties & Uses"] },
      { name: "Coordination Compounds", topics: [
        "Werner's Theory", "IUPAC Nomenclature", "Types of Ligands", "Coordination Number & Geometry",
        "Valence Bond Theory (VBT)", "Crystal Field Theory (CFT)", "Colour in Coordination Compounds",
        "Magnetic Properties", "Isomerism – Structural", "Isomerism – Stereoisomerism",
        "Stability of Coordination Compounds", "Biological & Industrial Applications"] },
      { name: "Haloalkanes & Haloarenes", topics: [
        "Classification & Nomenclature", "Methods of Preparation", "Physical Properties",
        "Nucleophilic Substitution: SN1 Mechanism", "Nucleophilic Substitution: SN2 Mechanism",
        "Elimination Reactions", "Haloarenes – Preparation & Reactions", "Polyhalogen Compounds & Uses"] },
      { name: "Alcohols, Phenols & Ethers", topics: [
        "Classification & Nomenclature", "Methods of Preparation of Alcohols", "Physical Properties of Alcohols",
        "Chemical Reactions of Alcohols", "Phenols – Preparation", "Acidic Nature of Phenols",
        "Reactions of Phenols", "Ethers – Preparation & Properties"] },
      { name: "Aldehydes, Ketones & Carboxylic Acids", topics: [
        "Nomenclature of Aldehydes & Ketones", "Preparation: Oxidation, Ozonolysis", "Nucleophilic Addition Reactions",
        "Aldol Condensation", "Cannizzaro Reaction", "Carboxylic Acids – Nomenclature & Preparation",
        "Acidic Strength & Factors", "Reactions of Carboxylic Acids"] },
      { name: "Amines", topics: [
        "Classification & Nomenclature", "Preparation of Amines", "Physical Properties", "Basicity of Amines",
        "Chemical Reactions", "Diazonium Salts & Reactions", "Uses of Amines"] },
      { name: "Biomolecules", topics: [
        "Carbohydrates – Classification", "Structure of Glucose & Fructose", "Glycosidic Linkage & Disaccharides",
        "Polysaccharides – Starch, Cellulose", "Amino Acids – Classification", "Peptide Bond & Proteins",
        "Structure of Proteins", "Enzymes – Properties", "Nucleic Acids: DNA Structure", "Nucleic Acids: RNA Types",
        "Lipids & Vitamins"] },
    ]
  },
  maths: {
    name: "Mathematics", color: "#F5C842", icon: "∑",
    chapters: [
      { name: "Relations & Functions", topics: [
        "Types of Relations: Reflexive, Symmetric, Transitive", "Equivalence Relations",
        "One-One & Onto Functions", "Composite Functions", "Inverse of a Function",
        "Inverse Trigonometric Functions – Definition & Domain", "Graphs of Inverse Trig Functions",
        "Properties of Inverse Trig Functions", "Principal Value Branch"] },
      { name: "Algebra – Matrices", topics: [
        "Types of Matrices & Order", "Matrix Operations: Addition & Subtraction",
        "Scalar Multiplication & Matrix Multiplication", "Transpose, Symmetric & Skew-Symmetric Matrices",
        "Invertible Matrices", "Uniqueness of Inverse"] },
      { name: "Algebra – Determinants", topics: [
        "Determinant of Square Matrix (up to 3×3)", "Properties of Determinants", "Minors & Cofactors",
        "Adjoint of a Matrix", "Inverse of a Matrix using Adjoint", "Area of Triangle using Determinants",
        "System of Linear Equations – Consistency", "Solving System using Inverse Matrix (Cramer's Rule)"] },
      { name: "Calculus – Continuity & Differentiability", topics: [
        "Continuity at a Point & on an Interval", "Discontinuity – Types", "Differentiability & its Relation to Continuity",
        "Derivatives: Sum, Product, Quotient Rules", "Chain Rule", "Derivatives of Implicit Functions",
        "Derivatives of Inverse Trig Functions", "Derivatives of Logarithmic & Exponential Functions",
        "Parametric Differentiation", "Second Order Derivatives", "Rolle's Theorem & Mean Value Theorem"] },
      { name: "Calculus – Applications of Derivatives", topics: [
        "Rate of Change of Quantities", "Increasing & Decreasing Functions", "Tangents & Normals to Curves",
        "Approximations using Derivatives", "Maxima & Minima – First Derivative Test", "Second Derivative Test",
        "Absolute Maxima & Minima"] },
      { name: "Calculus – Integration", topics: [
        "Integration as Inverse of Differentiation", "Standard Integrals", "Integration by Substitution",
        "Integration using Trigonometric Identities", "Integration by Partial Fractions", "Integration by Parts",
        "Definite Integrals – Properties", "Evaluation of Definite Integrals"] },
      { name: "Calculus – Applications of Integration", topics: [
        "Area Under Simple Curves", "Area Between Two Curves", "Area Using Definite Integrals"] },
      { name: "Calculus – Differential Equations", topics: [
        "Order & Degree of Differential Equations", "General & Particular Solutions", "Variable Separable Method",
        "Homogeneous Differential Equations", "Linear Differential Equations (First Order)",
        "Applications: Population Growth, Decay"] },
      { name: "Vectors", topics: [
        "Types of Vectors", "Addition & Subtraction of Vectors", "Scalar & Vector Components", "Section Formula",
        "Direction Cosines & Direction Ratios", "Dot Product & its Properties", "Cross Product & its Properties",
        "Area of Triangle & Parallelogram using Vectors", "Scalar Triple Product"] },
      { name: "Three-Dimensional Geometry", topics: [
        "Direction Cosines of a Line", "Direction Ratios & Relationship with Cosines", "Equation of a Line in Space",
        "Skew Lines & Shortest Distance", "Angle Between Two Lines", "Equation of a Plane",
        "Angle Between Line & Plane", "Angle Between Two Planes", "Distance of a Point from a Plane",
        "Intercept & Normal Form of Plane"] },
      { name: "Linear Programming", topics: [
        "Introduction to LPP", "Formulation of LPP", "Graphical Solution – Feasible Region", "Corner Point Method",
        "Maximum & Minimum of Objective Function", "Types of Solutions: Bounded, Unbounded"] },
      { name: "Probability", topics: [
        "Conditional Probability", "Multiplication Theorem", "Independent Events", "Bayes' Theorem",
        "Theorem of Total Probability", "Random Variables & Probability Distributions",
        "Mean & Variance of a Random Variable", "Bernoulli Trials & Binomial Distribution"] },
    ]
  }
}

/** Normalise a name so a future edit to either file cannot break the join.
 *  en dash / em dash -> hyphen, & -> and, collapse whitespace, lowercase. */
export function normalizeName(s) {
  return String(s)
    .replace(/[–—]/g, '-')
    .replace(/&/g, ' and ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase()
}

/**
 * data/resolveTopics.js — the topic-resolution contract (Appendix A.1).
 *
 * Physics / Chemistry / Maths chapters reference the topic strings that already
 * exist in the v1 `SYLLABUS` constant via `topicsFrom:'legacy'`, `legacySplit`
 * or `fallbackTopics`. CS / English-I / English-II carry their own `topics`.
 *
 * Also produces a legacy -> v2 assignment map so migrations can translate the
 * v1 index-based tick keys into the new id-based keys.
 */
import { LEGACY_SYLLABUS, normalizeName } from './legacySyllabus.js'
import base from '../../syllabus-exams.data.js'

const { SYLLABUS_XII } = base

export function slugify(text, max = 48) {
  let s = String(text).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
  if (s.length > max) s = s.slice(0, max).replace(/-+$/g, '')
  return s
}

function legacyChapter(subjectKey, name) {
  const subj = LEGACY_SYLLABUS[subjectKey]
  if (!subj) return null
  const norm = normalizeName(name)
  return subj.chapters.find(c => normalizeName(c.name) === norm) || null
}

/**
 * Resolve the topic array for one chapter record.
 * Returns { topics: [ {id, title} ], from: 'own'|'legacy'|'split'|'fallback' }
 */
export function resolveChapterTopics(subjectKey, chapter) {
  if (Array.isArray(chapter.topics) && chapter.topics.length) {
    return { topics: chapter.topics.map(t => ({ id: slugify(t), title: t })), from: 'own' }
  }
  if (chapter.topicsFrom === 'legacy' && chapter.legacyName) {
    const lc = legacyChapter(subjectKey, chapter.legacyName)
    if (lc && lc.topics.length) {
      return { topics: lc.topics.map(t => ({ id: slugify(t), title: t })), from: 'legacy' }
    }
  }
  if (chapter.legacySplit) {
    const lc = legacyChapter(subjectKey, chapter.legacySplit.from)
    if (lc && lc.topics.length) {
      const match = (chapter.legacySplit.match || []).map(m => normalizeName(m))
      const out = []
      for (const t of lc.topics) {
        const tn = normalizeName(t)
        if (match.some(m => tn.includes(m))) out.push({ id: slugify(t), title: t })
      }
      if (out.length) return { topics: out, from: 'split' }
    }
  }
  if (Array.isArray(chapter.fallbackTopics) && chapter.fallbackTopics.length) {
    return { topics: chapter.fallbackTopics.map(t => ({ id: slugify(t), title: t })), from: 'fallback' }
  }
  return { topics: [], from: 'none' }
}

/**
 * Assign every legacy topic of `fromName` to a v2 chapter via the split rules.
 * Used by migrations: returns Map<topicTitle, chapterId> and the chapter ids.
 */
export function assignLegacySplit(subjectKey, fromName, chapterList) {
  const lc = legacyChapter(subjectKey, fromName)
  const map = new Map()
  if (!lc) return map
  const splits = chapterList.filter(c => c.legacySplit && normalizeName(c.legacySplit.from) === normalizeName(fromName))
  if (!splits.length) return map
  // first matching rule wins; `rest:true` catches what nothing matched
  const rest = splits.find(c => c.legacySplit.rest)
  for (const t of lc.topics) {
    const tn = normalizeName(t)
    let hit = null
    for (const c of splits) {
      if ((c.legacySplit.match || []).some(m => tn.includes(normalizeName(m)))) { hit = c; break }
    }
    map.set(t, hit ? hit.id : (rest ? rest.id : null))
  }
  return map
}

/**
 * Build the full v2 syllabus with resolved topics.
 * Returns { [subjectKey]: { ...SUBJECTS[key], chapters: [{...chapter, topics}] } }
 */
export function buildSyllabus(chapters) {
  const out = {}
  for (const subjectKey of Object.keys(chapters)) {
    const resolved = chapters[subjectKey].map(ch => ({
      ...ch,
      topics: resolveChapterTopics(subjectKey, ch).topics,
    }))
    out[subjectKey] = resolved
  }
  return out
}

export default { resolveChapterTopics, assignLegacySplit, buildSyllabus, slugify, SYLLABUS_XII }

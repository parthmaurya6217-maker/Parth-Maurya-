/**
 * features/tasks.js — Task manager (ported from v1, unchanged behaviour).
 */
import { store, addTask, toggleTask, deleteTask, save } from '../state/store.js'
import { esc } from '../lib/format.js'
import { emptyState, toast, confirmDialog } from '../lib/ui.js'
import { renderContent } from './router.js'

export function renderTasks() {
  const doneCount = store.data.tasks.filter(t => t.done).length
  const pending = store.data.tasks.filter(t => !t.done).length
  return `<div class="fadein" style="max-width:700px">
    <div class="card-label">Task Manager</div>
    <div class="card" style="display:flex;gap:10px;margin-bottom:20px;padding:16px 20px;flex-wrap:wrap">
      <input id="task-input" value="${esc(store.ui.taskInput)}" placeholder="Add a task or topic to study today…" style="flex:1;min-width:180px" maxlength="300" data-action="task-input">
      <button class="btn" data-action="add-task" style="background:rgba(245,200,66,.2);border:1px solid rgba(245,200,66,.4);color:#F5C842">ADD</button>
    </div>
    ${store.data.tasks.length === 0
      ? emptyState('🗒', 'No tasks yet', 'Add topics, problems, or chapters you want to work on. They persist across visits.')
      : `
    <div style="display:flex;flex-direction:column;gap:8px">
      ${store.data.tasks.map((t, i) => `<div class="card hov" style="display:flex;align-items:center;gap:14px;padding:14px 18px;opacity:${t.done ? 0.5 : 1}">
        <div data-action="toggle-task" data-i="${i}" role="checkbox" aria-checked="${t.done}" tabindex="0" style="width:20px;height:20px;border-radius:5px;border:1.5px solid ${t.done ? '#4ADE80' : 'var(--border2)'};background:${t.done ? '#4ADE8020' : 'transparent'};display:flex;align-items:center;justify-content:center;cursor:pointer;flex-shrink:0;transition:all .2s">
          ${t.done ? '<span style="font-size:12px;color:#4ADE80">✓</span>' : ''}
        </div>
        <div style="flex:1;font-size:13px;color:${t.done ? 'var(--dim)' : 'var(--white)'};text-decoration:${t.done ? 'line-through' : 'none'};word-break:break-word">${esc(t.text)}</div>
        <button class="btn" data-action="delete-task" data-i="${i}" title="Delete task" aria-label="Delete task" style="background:none;border:none;color:var(--dim);font-size:17px;padding:0 4px">×</button>
      </div>`).join('')}
    </div>
    <div style="margin-top:16px;display:flex;justify-content:center;gap:18px;align-items:center;font-size:12px;color:var(--dim)">
      <span>${pending} pending · ${doneCount} done</span>
      ${doneCount > 0 ? `<button class="btn btn-ghost" style="padding:5px 12px;font-size:10px" data-action="clear-done-tasks">Clear finished</button>` : ''}
    </div>`}
  </div>`
}

export function taskInputHandler(el) {
  store.ui.taskInput = el.value
}
export function addTaskAction() {
  const val = (store.ui.taskInput.trim() || document.getElementById('task-input')?.value?.trim() || '')
  if (!val) { toast('⚠', 'Type something first'); return }
  addTask(val)
  store.ui.taskInput = ''
  renderContent()
}
export function toggleTaskAction(_, ds) {
  const i = +ds.i
  const t = store.data.tasks[i]
  if (!t) return
  toggleTask(i)
  if (t.done) toast('✅', `Done: ${esc(t.text.slice(0, 40))}${t.text.length > 40 ? '…' : ''}`, { ttl: 1600 })
  renderContent()
}
export function deleteTaskAction(_, ds) {
  const i = +ds.i
  const t = deleteTask(i)
  renderContent()
  if (t) toast('🗑', 'Task deleted', { ttl: 5000, action: { id: 'undo-del-' + Date.now(), label: 'UNDO', fn() { store.data.tasks.splice(i, 0, t); save('state'); renderContent() } } })
}
export function clearDoneTasksAction() {
  const n = store.data.tasks.filter(t => t.done).length
  if (!n) { toast('ℹ', 'No finished tasks to clear'); return }
  confirmDialog({
    title: 'Clear finished tasks?',
    message: `This removes <strong style="color:var(--white)">${n}</strong> completed task${n > 1 ? 's' : ''}.`,
    danger: true,
    onConfirm() { store.data.tasks = store.data.tasks.filter(t => !t.done); save('state'); renderContent(); toast('🧹', `${n} task${n > 1 ? 's' : ''} cleared`) },
  })
}

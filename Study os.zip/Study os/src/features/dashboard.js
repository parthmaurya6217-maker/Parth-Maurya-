/**
 * features/dashboard.js — Dashboard tab (v1 features preserved) + the three
 * new v2 glass tiles: Next exam, Today's plan, Focus today.
 */
import { store, sessionDoneToday, toggleSession } from '../state/store.js'
import { SESSIONS } from '../data/sessions.js'
import { EVENTS } from '../data/sessions.js'
import { SUBJECTS } from '../../syllabus-exams.data.js'
import { examById } from '../data/exams.js'
import { examMetrics, readinessBand } from '../state/mastery.js'
import { toMins, fmt12, fmtSecs, todayKey, daysUntil, fmtShort } from '../lib/time.js'
import { esc } from '../lib/format.js'
import { ringHTML, miniBarHTML, emptyState } from '../lib/ui.js'
import { getCurrentSession, getNextSession, getProgress, getRemaining, isStudySession, STUDY_TYPES } from './schedule.js'
import { QUOTES } from '../data/sessions.js'

const COLORS = { maths: '#F5C842', physics: '#60B5FF', chemistry: '#4ADE80', revision: '#C084FC' }

function focusToday() {
  const tk = todayKey()
  let minutes = 0, blocks = 0
  for (const s of store.sessions) {
    if (s.phase === 'focus' && s.startedAt && s.startedAt.slice(0, 10) === tk) {
      minutes += s.minutes || 0
      blocks++
    }
  }
  // 7-day sparkline (minutes per day)
  const days = []
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i)
    const dk = todayKey(d)
    const mins = store.sessions.filter(s => s.phase === 'focus' && s.startedAt && s.startedAt.slice(0, 10) === dk).reduce((a, s) => a + (s.minutes || 0), 0)
    days.push(mins)
  }
  const max = Math.max(...days, 1)
  const spark = days.map(m => {
    const h = Math.max((m / max) * 40, m ? 3 : 1)
    return `<div style="flex:1;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;gap:3px">
      <div style="width:100%;max-width:16px;height:${h}px;border-radius:3px;background:${m ? 'linear-gradient(180deg,#8B5CF6,#60B5FF)' : 'var(--hover)'}"></div>
      <span style="font-size:8px;color:var(--dim)">${m ? Math.round(m) : ''}</span>
    </div>`
  }).join('')
  return { minutes, blocks, spark, days }
}

export function renderDashboard() {
  const now = new Date()
  const sess = getCurrentSession(now)
  const nextSess = getNextSession(now)
  const studySessions = SESSIONS.filter(isStudySession)
  const doneIds = store.data.completed[todayKey()] || []
  const doneCount = doneIds.filter(id => studySessions.some(s => s.id === id)).length
  const totalStudied = Object.values(store.data.subjectTime).reduce((a, b) => a + b, 0)
  const upcomingEvents = EVENTS.filter(e => daysUntil(e.date) >= 0).slice(0, 3)
  const quote = QUOTES[store.ui.quoteIdx]

  // New v2 tiles
  const nextExam = nextExamTile()
  const todayPlan = planTile()
  const focus = focusToday()

  const schedHTML = SESSIONS.map(s => {
    const isCur = sess?.id === s.id
    const isPast = now.getHours() * 60 + now.getMinutes() >= toMins(s.end)
    const isDone = sessionDoneToday(s.id)
    const col = s.subject ? COLORS[s.subject] : (s.type === 'break' ? '#475569' : '#374151')
    const dur = toMins(s.end) - toMins(s.start)
    const clickable = isStudySession(s)
    return `<div class="hov" data-action="${clickable ? 'toggle-session' : ''}" data-id="${s.id}" style="background:${isCur ? `${col}10` : 'var(--card)'};border:1px solid ${isCur ? col + '50' : 'var(--border)'};border-radius:9px;padding:9px 13px;cursor:${clickable ? 'pointer' : 'default'};opacity:${isPast && !isCur && !isDone ? 0.45 : 1};transition:all .25s;position:relative;overflow:hidden;margin-bottom:5px">
      ${isCur ? `<div style="position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,${col},transparent);background-size:200% 100%;animation:slide 2.5s linear infinite"></div>` : ''}
      <div style="display:flex;align-items:center;justify-content:space-between">
        <div style="display:flex;align-items:center;gap:8px">
          <span style="font-size:15px">${s.icon}</span>
          <div>
            <div style="font-size:12px;color:${isDone ? 'var(--dim)' : 'var(--white)'};text-decoration:${isDone ? 'line-through' : 'none'};font-weight:500">${esc(s.label)}</div>
            <div style="font-size:10px;color:var(--dim);margin-top:2px">${fmt12(...s.start)} · ${dur}m</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:5px">
          ${isCur ? `<div style="width:6px;height:6px;border-radius:50%;background:${col};animation:live 1.5s infinite"></div>` : ''}
          <span style="font-size:13px;color:var(--green);display:${isDone ? 'inline' : 'none'}">✓</span>
        </div>
      </div>
      ${isCur ? `<div style="margin-top:7px;background:var(--hover);border-radius:3px;height:3px;overflow:hidden"><div style="height:100%;background:${col};width:${Math.round(getProgress(sess, now) * 100)}%;transition:width 1s linear;border-radius:3px"></div></div>` : ''}
    </div>`
  }).join('')

  let centerHTML = ''
  if (sess) {
    const rem = getRemaining(sess, now)
    const col = sess.subject ? COLORS[sess.subject] : '#64748B'
    centerHTML = `
    <div class="card" style="position:relative;overflow:hidden;text-align:center">
      <div style="position:absolute;inset:0;background:radial-gradient(ellipse at 50% 0%,${col}12,transparent 65%);pointer-events:none"></div>
      <div style="font-size:10px;letter-spacing:4px;color:${col};text-transform:uppercase;margin-bottom:4px">Now Active</div>
      <div style="font-size:24px;font-weight:600;color:var(--white);margin-bottom:2px">${esc(sess.label)}</div>
      ${sess.subtitle ? `<div style="font-size:13px;color:var(--muted);margin-bottom:22px">${esc(sess.subtitle)}</div>` : '<div style="margin-bottom:22px"></div>'}
      <div style="display:flex;justify-content:center;margin-bottom:24px">
        ${ringHTML(rem.total / (toMins(sess.end) * 60 - toMins(sess.start) * 60), col, 210, 11, `
          <div><div id="dash-remain" style="font-family:var(--font-mono);font-size:36px;color:var(--white);line-height:1;font-weight:700">${String(rem.m).padStart(2, '0')}:${String(rem.s).padStart(2, '0')}</div>
          ${rem.h > 0 ? `<div style="font-size:12px;color:var(--muted);margin-top:4px">${rem.h}h remaining</div>` : ''}
          <div style="font-size:11px;color:var(--dim);margin-top:6px">time left</div></div>`)}
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;border-top:1px solid var(--border);padding-top:18px">
        ${[['Elapsed', `${Math.round(getProgress(sess, now) * 100)}%`], ['Started', fmt12(...sess.start)], ['Ends', fmt12(...sess.end)]].map(([l, v]) => `<div><div style="font-size:18px;color:var(--white);font-weight:500">${v}</div><div style="font-size:10px;color:var(--dim);margin-top:3px">${l}</div></div>`).join('')}
      </div>
      <div style="margin-top:18px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
        <button class="btn" data-action="open-focus-mode" style="background:${col}18;border:1px solid ${col}40;color:${col}">FOCUS MODE</button>
        <button class="btn" data-action="toggle-session" data-id="${sess.id}" style="background:${sessionDoneToday(sess.id) ? 'rgba(74,222,128,.12)' : 'rgba(255,255,255,.05)'};border:1px solid ${sessionDoneToday(sess.id) ? '#4ADE8040' : 'var(--border)'};color:${sessionDoneToday(sess.id) ? 'var(--green)' : 'var(--muted)'}">${sessionDoneToday(sess.id) ? '✓ DONE' : 'MARK DONE'}</button>
      </div>
    </div>
    ${nextSess && nextSess.id !== sess.id ? `<div class="card" style="display:flex;align-items:center;gap:14px;padding:14px 20px;margin-top:18px">
      <div style="font-size:10px;letter-spacing:3px;color:var(--dim)">NEXT</div>
      <div style="height:1px;flex:1;background:var(--border)"></div>
      <div style="text-align:right">
        <div style="font-size:13px;color:var(--white);font-weight:500">${esc(nextSess.label)}</div>
        <div id="dash-next-in" style="font-size:11px;color:var(--muted)">starts in …</div>
      </div>
      <div style="font-size:20px">${nextSess.icon}</div>
    </div>` : ''}`
  } else {
    const nextStudy = getNextSession(now)
    const cur = now.getHours() * 60 + now.getMinutes()
    const minsToNext = nextStudy ? (toMins(nextStudy.start) - cur) : null
    const before = (minsToNext !== null && minsToNext > 0) ? `First session starts in <strong style="color:var(--gold);font-family:var(--font-mono)"><span id="dash-next-count">${Math.floor(minsToNext / 60) > 0 ? Math.floor(minsToNext / 60) + 'h ' : ''}${minsToNext % 60}m</span></strong>.` : ''
    centerHTML = emptyState('🌙', 'No Active Session',
      `${before} Study sessions run from <strong style="color:var(--text)">4:00 PM to 11:00 PM</strong> daily. Use the time to revise or get ahead.`)
  }

  const rightHTML = `
  <div class="card">
    <div class="card-label">Today's Progress</div>
    <div style="display:flex;align-items:center;gap:14px;margin-bottom:14px">
      ${ringHTML(doneCount / Math.max(studySessions.length, 1), '#F5C842', 72, 6, `<div style="font-size:16px;font-weight:600;color:var(--white)">${doneCount}</div>`)}
      <div>
        <div style="font-size:13px;color:var(--white);font-weight:500">${doneCount} / ${studySessions.length} sessions</div>
        <div style="font-size:11px;color:var(--muted);margin-top:3px">completed today</div>
        <div style="font-size:11px;color:#F5C842;margin-top:6px"><span id="dash-studied">${fmtSecs(totalStudied)}</span> studied</div>
      </div>
    </div>
    ${miniBarHTML(doneCount, studySessions.length, '#F5C842')}
  </div>
  <div class="card" style="margin-top:16px">
    <div class="card-label">Subject Time Today</div>
    ${Object.entries(SUBJECTS).filter(([k]) => k in store.data.subjectTime).map(([k, subj]) => `
      <div style="margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;margin-bottom:6px">
          <div style="font-size:12px;color:${subj.color};font-weight:500">${subj.name}</div>
          <div style="font-size:12px;color:var(--muted);font-family:var(--font-mono)" data-live-time="${k}">${fmtSecs(store.data.subjectTime[k] || 0)}</div>
        </div>
        ${miniBarHTML(store.data.subjectTime[k] || 0, (subj.target || 120) * 60, subj.color)}
      </div>`).join('')}
  </div>
  ${nextExam}
  ${todayPlan}
  <div class="card" style="margin-top:16px">
    <div class="card-label">Upcoming Events</div>
    ${upcomingEvents.length ? upcomingEvents.map((ev, i) => {
      const days = daysUntil(ev.date), col = eventColor(ev.type)
      return `<div style="display:flex;align-items:center;gap:10px;padding-bottom:10px;${i < upcomingEvents.length - 1 ? 'border-bottom:1px solid var(--border)' : ''};${i > 0 ? 'padding-top:10px' : ''}">
        <div style="background:${col}18;border:1px solid ${col}35;border-radius:7px;padding:4px 8px;font-size:11px;color:${col};min-width:46px;text-align:center;font-family:var(--font-mono);font-weight:700">${days === 0 ? 'TODAY' : days <= 99 ? `${days}d` : '—'}</div>
        <div style="flex:1"><div style="font-size:11.5px;color:var(--white);font-weight:500">${esc(ev.label)}</div>
        <div style="font-size:10px;color:var(--dim)">${fmtShort(ev.date)}</div></div>
      </div>`
    }).join('') : '<div style="font-size:12px;color:var(--dim)">All caught up.</div>'}
  </div>
  <div class="card" style="margin-top:16px">
    <div class="card-label">Focus Today</div>
    <div style="display:flex;align-items:center;gap:14px;margin-bottom:10px">
      ${ringHTML(Math.min(focus.minutes / 120, 1), '#8B5CF6', 60, 5, `<div style="font-size:13px;font-weight:600;color:var(--white)">${Math.round(focus.minutes)}</div>`)}
      <div>
        <div style="font-size:13px;color:var(--white);font-weight:500">${Math.round(focus.minutes)} min focused</div>
        <div style="font-size:11px;color:var(--muted);margin-top:3px">${focus.blocks} pomodoro block${focus.blocks === 1 ? '' : 's'} completed</div>
      </div>
    </div>
    <div style="display:flex;gap:4px;align-items:flex-end;height:52px">${focus.spark}</div>
    <div style="font-size:10px;color:var(--dim);margin-top:8px">Focus minutes per day — last 7 days</div>
  </div>`

  return `<div class="fadein">
    <div style="background:linear-gradient(90deg,rgba(139,92,246,.08),transparent);border:1px solid rgba(139,92,246,.14);border-radius:10px;padding:11px 20px;margin-bottom:22px;font-size:12.5px;color:var(--muted);font-style:italic">
      "${esc(quote)}"
    </div>
    <div class="dashboard-grid" style="display:grid;grid-template-columns:280px 1fr 280px;gap:20px">
      <div>
        <div class="card-label">Today's Schedule</div>
        ${schedHTML}
        <div style="margin-top:10px;font-size:10px;color:var(--dim);text-align:center">Click sessions to mark done</div>
      </div>
      <div>${centerHTML}</div>
      <div style="display:flex;flex-direction:column;gap:0">${rightHTML}</div>
    </div>
  </div>`
}

function nextExamTile() {
  const upcoming = [examById('half_yearly'), examById('preboard1'), examById('preboard2'), examById('boards')]
  const next = upcoming.find(e => daysUntil(e.start) >= 0) || upcoming[0]
  if (!next) return ''
  const m = examMetrics(next.id)
  const band = readinessBand(m.readiness)
  const d = daysUntil(next.start)
  return `<div class="card" style="margin-top:16px">
    <div class="card-label">Next Exam</div>
    <div style="display:flex;align-items:center;gap:14px">
      ${ringHTML(m.readiness / 100, band.color, 64, 5, `<div style="font-size:14px;font-weight:700;color:${band.color};font-family:var(--font-mono)">${m.readiness}</div>`)}
      <div style="flex:1;min-width:0">
        <div style="font-size:13px;color:var(--white);font-weight:500">${esc(next.short)}</div>
        <div style="font-size:11px;color:var(--muted);margin-top:2px">${fmtShort(next.start)} · ${d === 0 ? 'today' : d > 0 ? `${d} day${d === 1 ? '' : 's'} left` : 'completed'}</div>
        <div style="font-size:11px;color:${band.color};margin-top:4px">${band.label} · ${m.checked}/${m.total} topics</div>
      </div>
    </div>
  </div>`
}

function planTile() {
  const plan = store.plan
  const tk = todayKey()
  const items = plan.filter(p => p.date === tk)
  return `<div class="card" style="margin-top:16px">
    <div class="card-label">Today's Plan</div>
    ${items.length ? items.map(it => `
      <div style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--border)">
        <div data-action="toggle-plan-item" data-key="${it.key}" role="checkbox" aria-checked="${it.done ? 'true' : 'false'}" tabindex="0"
          style="width:17px;height:17px;border-radius:5px;border:1.5px solid ${it.done ? '#4ADE80' : 'var(--border2)'};background:${it.done ? 'rgba(74,222,128,.13)' : 'transparent'};display:flex;align-items:center;justify-content:center;cursor:pointer;flex-shrink:0">${it.done ? '<span style="font-size:10px;color:var(--green)">✓</span>' : ''}</div>
        <span style="font-size:12.5px;color:${it.done ? 'var(--dim)' : 'var(--text)'};text-decoration:${it.done ? 'line-through' : 'none'};flex:1">${esc(it.title)}</span>
        <span style="font-size:10px;color:var(--dim);font-family:var(--font-mono)">${it.subject}</span>
      </div>`).join('')
      : `<div style="font-size:12px;color:var(--dim);line-height:1.6">No plan for today yet.<br>Open <strong style="color:var(--white)">Exam Prep</strong> → <strong style="color:var(--white)">Study plan</strong> to generate one.</div>`}
  </div>`
}

function eventColor(t) {
  return { exam: '#FF6B6B', holiday: '#4ADE80', meeting: '#60B5FF', school: '#94A3B8' }[t] || '#94A3B8'
}

/** Targeted per-second updates — no re-render, inputs keep focus. */
export function updateDashboardLive() {
  const sess = getCurrentSession(new Date())
  const now = new Date()
  if (sess) {
    const rem = getRemaining(sess, now)
    const el = document.getElementById('dash-remain')
    if (el) el.textContent = `${String(rem.m).padStart(2, '0')}:${String(rem.s).padStart(2, '0')}`
    const nxt = document.getElementById('dash-next-in')
    if (nxt) {
      const n = getNextSession(now)
      const mins = toMins(n.start) - (now.getHours() * 60 + now.getMinutes())
      nxt.textContent = `starts in ${Math.floor(mins / 60) > 0 ? `${Math.floor(mins / 60)}h ` : ''}${mins % 60}m`
    }
  } else {
    const cnt = document.getElementById('dash-next-count')
    if (cnt) {
      const n = getNextSession(now)
      if (n) {
        const mins = Math.max(toMins(n.start) - (now.getHours() * 60 + now.getMinutes()), 0)
        cnt.textContent = `${Math.floor(mins / 60) > 0 ? Math.floor(mins / 60) + 'h ' : ''}${mins % 60}m`
      }
    }
  }
  const studiedEl = document.getElementById('dash-studied')
  if (studiedEl) studiedEl.textContent = fmtSecs(Object.values(store.data.subjectTime).reduce((a, b) => a + b, 0))
  document.querySelectorAll('[data-live-time]').forEach(el => {
    const k = el.dataset.liveTime
    el.textContent = fmtSecs(store.data.subjectTime[k] || 0)
  })
}

/**
 * features/focusOverlay.js — full-screen ring timer for schedule sessions
 * (v1 behaviour, restyled in Phase 1). Uses getCurrentSession live.
 */
import { store, toggleSession, sessionDoneToday } from '../state/store.js'
import { getCurrentSession, getProgress, getRemaining } from './schedule.js'
import { fmt12 } from '../lib/time.js'

const COLORS = { maths: '#F5C842', physics: '#60B5FF', chemistry: '#4ADE80', revision: '#C084FC' }

export function openFocus() {
  const sess = getCurrentSession(new Date())
  if (!sess || sess.type === 'break') return { ok: false, msg: 'Focus mode needs an active study session' }
  store.ui.focusMode = true
  document.getElementById('focus-overlay').style.display = 'flex'
  updateFocusOverlay()
  return { ok: true }
}
export function closeFocus() {
  store.ui.focusMode = false
  document.getElementById('focus-overlay').style.display = 'none'
}
export function toggleFocus() {
  const sess = getCurrentSession(new Date())
  if (!sess || sess.type === 'break') return
  store.ui.focusMode ? closeFocus() : openFocus()
}

export function updateFocusOverlay() {
  if (!store.ui.focusMode) return
  const sess = getCurrentSession(new Date())
  if (!sess) { closeFocus(); return }
  const col = sess.subject ? COLORS[sess.subject] : '#64748B'
  const rem = getRemaining(sess, new Date()), prog = getProgress(sess, new Date())
  const circ = 2 * Math.PI * 124
  const label = document.getElementById('fo-label')
  if (label) { label.textContent = sess.label + ' — Focus Mode'; label.style.color = col }
  const arc = document.getElementById('fo-ring-arc')
  if (arc) { arc.style.stroke = col; arc.style.filter = `drop-shadow(0 0 6px ${col})`; arc.style.strokeDashoffset = circ * prog }
  const timer = document.getElementById('fo-timer')
  if (timer) timer.textContent = `${String(rem.m).padStart(2, '0')}:${String(rem.s).padStart(2, '0')}`
  const hEl = document.getElementById('fo-timer-h')
  if (hEl) { hEl.style.display = rem.h > 0 ? 'block' : 'none'; if (rem.h > 0) hEl.textContent = `${rem.h}h remaining` }
  const name = document.getElementById('fo-name')
  if (name) name.textContent = sess.label
  const sub = document.getElementById('fo-sub')
  if (sub) sub.textContent = sess.subtitle || ''
  const tr = document.getElementById('fo-time-range')
  if (tr) tr.textContent = `${fmt12(...sess.start)} → ${fmt12(...sess.end)}`
  const db = document.getElementById('fo-done-btn')
  if (db) {
    const done = sessionDoneToday(sess.id)
    db.textContent = done ? '✓ DONE' : 'MARK DONE'
    db.style.background = done ? 'rgba(74,222,128,.15)' : col + '20'
    db.style.border = `1px solid ${done ? '#4ADE8050' : col + '50'}`
    db.style.color = done ? '#4ADE80' : col
  }
}

export function focusDone() {
  const sess = getCurrentSession(new Date())
  if (sess && !sessionDoneToday(sess.id)) toggleSession(sess.id)
  closeFocus()
}

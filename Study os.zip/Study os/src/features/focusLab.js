/**
 * features/focusLab.js — Focus Lab tab (Phase 3).
 * Split layout: YouTube player + AI topic extraction sidebar + Pomodoro.
 * The player lives in a persistent #yt-stage that is moved between the tab
 * mount point and <body>, so switching tabs pauses nothing and returning is
 * instant. The Pomodoro is timestamp-based and keeps running across tabs.
 */
import { store, save } from '../state/store.js'
import { parseYouTubeUrl, fmtTime, parseTimeToSec, loadYouTubeApi } from '../lib/youtube.js'
import { analyzeVideo } from '../lib/ai/gemini.js'
import { esc, truncate, dice } from '../lib/format.js'
import { topicKey } from '../data/syllabus.js'
import { chapterById } from '../data/syllabus.js'
import { SUBJECTS, SUBJECT_ORDER } from '../../syllabus-exams.data.js'
import { mastery, setTopicMastery, revisionQueue } from '../state/mastery.js'
import { toast } from '../lib/ui.js'
import { todayKey } from '../lib/time.js'
import * as pomo from '../lib/pomodoro.js'

const P = {
  player: null,
  videoId: null,
  stage: null,
  mounted: false,
  pollTimer: null,
  lastPersist: 0,
  analysisCtrl: null,
  lastState: -1,
  subtitleColor: 0,
}

// ── persistence helpers for the video cache ─────────────────────────────────
export function videoCache() { return store.videos }
function saveVideos() { save('videos') }

export function getVideo(videoId) {
  if (!store.videos[videoId]) {
    store.videos[videoId] = { title: '', channel: '', durationSec: 0, topics: [], meta: null, lastPosition: 0, notes: {}, topicChecks: {}, analysedAt: null }
  }
  return store.videos[videoId]
}
function cachePrune() {
  const keys = Object.keys(store.videos)
  if (keys.length <= 60) return
  keys.sort((a, b) => (store.videos[a].analysedAt || 0) - (store.videos[b].analysedAt || 0))
  for (let i = 0; i < keys.length - 60; i++) delete store.videos[keys[i]]
  saveVideos()
}

// ── stage + player lifecycle ────────────────────────────────────────────────
function ensureStage() {
  if (P.stage && document.body.contains(P.stage)) return P.stage
  if (!P.stage) {
    P.stage = document.createElement('div')
    P.stage.id = 'yt-stage'
    P.stage.style.cssText = 'position:fixed;left:-9999px;top:0;width:560px;height:315px;pointer-events:none;opacity:0'
    document.body.appendChild(P.stage)
  }
  return P.stage
}
function mountPlayer() {
  const mount = document.getElementById('yt-mount')
  if (!mount) return
  ensureStage()
  if (!P.mounted) { mount.appendChild(P.stage); P.stage.style.cssText = 'position:relative;left:auto;top:auto;width:100%;height:100%;pointer-events:auto;opacity:1' }
  P.mounted = true
}
function unmountPlayer() {
  if (P.mounted && P.stage) {
    ensureStage()
    document.body.appendChild(P.stage)
    P.stage.style.cssText = 'position:fixed;left:-9999px;top:0;width:560px;height:315px;pointer-events:none;opacity:0'
  }
  P.mounted = false
}

export function initFocusLab() {
  mountPlayer()
}
export function teardownFocusLab() {
  unmountPlayer()
  stopPolling()
}

async function createPlayer(videoId, start) {
  const YT = await loadYouTubeApi()
  if (P.player && P.videoId === videoId) {
    if (start > 0) P.player.seekTo(start, true)
    P.player.playVideo()
    return P.player
  }
  if (P.player) { P.player.destroy(); P.player = null }
  const stage = ensureStage()
  P.player = new YT.Player(stage, {
    width: '100%',
    height: '100%',
    videoId,
    playerVars: {
      enablejsapi: 1,
      origin: location.origin,
      rel: 0,
      modestbranding: 1,
      playsinline: 1,
      cc_load_policy: 0,
    },
    events: {
      onReady: e => {
        if (start > 0) e.target.seekTo(start, true)
        const v = getVideo(videoId)
        if (v.title && !document.title.includes('Focus')) { /* keep page title */ }
        syncVideoMeta(videoId)
        e.target.playVideo()
        P.lastState = 1
        startPolling()
      },
      onStateChange: e => {
        P.lastState = e.data
        if (e.data === 1) startPolling()
        else if (e.data === 2 || e.data === 0) maybeStopPolling()
        if (e.data === 0) {
          // ended
          P.player && P.player.seekTo(0)
        }
      },
      onError: e => {
        if (e.data === 101 || e.data === 150) {
          store.ui.focusLabError = { type: 'embed', videoId }
          renderFocusLab()
          toast('⚠', 'This video can\'t be embedded — open it on YouTube to watch', { ttl: 5000 })
        }
      },
    },
  })
  P.videoId = videoId
  P.mounted = true
  return P.player
}

function syncVideoMeta(videoId) {
  try {
    const v = getVideo(videoId)
    if (P.player) {
      const dur = P.player.getDuration?.()
      if (dur && isFinite(dur)) v.durationSec = Math.round(dur)
    }
  } catch {}
}

// ── playback polling ────────────────────────────────────────────────────────
function startPolling() {
  stopPolling()
  P.pollTimer = setInterval(() => {
    if (document.hidden) return
    if (!P.player || !P.videoId) return
    try {
      const t = P.player.getCurrentTime?.() || 0
      const v = getVideo(P.videoId)
      const now = Date.now()
      if (now - P.lastPersist > 5000) {
        v.lastPosition = t
        saveVideos()
        P.lastPersist = now
      }
      updateActiveTopic(t)
      updateTimelineMarker(t)
    } catch {}
  }, 250)
}
function maybeStopPolling() {
  // keep polling a beat in case state changes quickly
}
function stopPolling() {
  if (P.pollTimer) { clearInterval(P.pollTimer); P.pollTimer = null }
}

export function currentVideo() {
  return P.videoId ? getVideo(P.videoId) : null
}

// ── URL input / load ────────────────────────────────────────────────────────
export function loadVideoAction(_, ds) {
  const input = document.getElementById('focus-url')
  const raw = input?.value?.trim() || store.ui.focusLabUrl || ''
  const parsed = parseYouTubeUrl(raw)
  if (!parsed.ok) { store.ui.focusLabError = { type: 'parse', msg: parsed.error }; renderFocusLab(); return }
  store.ui.focusLabUrl = parsed.raw
  store.ui.focusLabError = null
  loadVideo(parsed.videoId, parsed.start)
}
export function loadVideo(videoId, start = 0) {
  store.ui.focusLabVideoId = videoId
  P.videoId = videoId
  const v = getVideo(videoId)
  if (v.lastPosition && !start) start = v.lastPosition
  createPlayer(videoId, start).catch(e => {
    store.ui.focusLabError = { type: 'embed', msg: e.message }
    renderFocusLab()
  })
  renderFocusLab()
}
export function resumeAction(_, ds) {
  const v = getVideo(ds.id)
  if (P.player && P.videoId === ds.id) { P.player.seekTo(v.lastPosition || 0, true); P.player.playVideo() }
  else loadVideo(ds.id, v.lastPosition || 0)
}

// ── analysis ────────────────────────────────────────────────────────────────
export async function analyseAction(_, ds) {
  const videoId = ds.id || store.ui.focusLabVideoId
  const parsed = videoId ? parseYouTubeUrl(videoId) : null
  if (!parsed || !parsed.ok) { const input = document.getElementById('focus-url'); if (input) { loadVideoAction(null, {}) } return }
  const vid = parsed.videoId
  const v = getVideo(vid)
  if (v.analysedAt && !confirmAction('Re-analyse this video? It costs API quota.')) return
  if (P.analysisCtrl) P.analysisCtrl.abort()
  const ctrl = new AbortController()
  P.analysisCtrl = ctrl
  store.ui.focusLabAnalysing = vid
  store.ui.focusLabProgress = 'Starting…'
  renderFocusLab()
  try {
    const result = await analyzeVideo(`https://www.youtube.com/watch?v=${vid}`, vid, {
      durationSec: v.durationSec || 0,
      onProgress: p => { store.ui.focusLabProgress = p; renderFocusLab() },
      signal: ctrl.signal,
    })
    if (ctrl.signal.aborted) return
    if (result.source === 'error') {
      store.ui.focusLabAnalysing = null
      store.ui.focusLabError = { type: 'ai', code: result.error, detail: result.detail }
      renderFocusLab()
      return
    }
    v.topics = result.topics
    v.meta = result.meta
    v.analysedAt = Date.now()
    v.source = result.source
    saveVideos()
    cachePrune()
    store.ui.focusLabAnalysing = null
    store.ui.focusLabError = null
    renderFocusLab()
    toast(`✨ ${result.topics.length} topics extracted (${result.source})`)
  } catch (e) {
    if (e.message === 'CANCELLED' || ctrl.signal.aborted) return
    store.ui.focusLabAnalysing = null
    store.ui.focusLabError = { type: 'ai', code: 'ERR', detail: e.message }
    renderFocusLab()
  }
}
function confirmAction(msg) {
  return window.confirm(msg)
}

export function cancelAnalysis() {
  if (P.analysisCtrl) { P.analysisCtrl.abort(); P.analysisCtrl = null }
  store.ui.focusLabAnalysing = null
  renderFocusLab()
}

// ── topic sidebar ───────────────────────────────────────────────────────────
export function seekToTopic(_, ds) {
  if (!P.player || P.videoId !== ds.vid) { loadVideo(ds.vid, +ds.t); return }
  P.player.seekTo(+ds.t, true)
  P.player.playVideo()
}
export function toggleTopicExpand(_, ds) {
  const v = getVideo(ds.vid)
  const t = v.topics.find(x => x.id === ds.tid)
  if (!t) return
  t._open = !t._open
  renderFocusLab()
}
export function topicCheck(_, ds) {
  const v = getVideo(ds.vid)
  v.topicChecks[ds.tid] = !v.topicChecks[ds.tid]
  if (v.topicChecks[ds.tid]) {
    // sync to mastery when mapped with confidence >= 0.6
    const t = v.topics.find(x => x.id === ds.tid)
    if (t && t.syllabusChapterId && (t.syllabusConfidence ?? 1) >= 0.6) {
      const found = chapterById().get(t.syllabusChapterId)
      if (found) {
        const key = topicKey(found.subjectKey, t.syllabusChapterId, t.topicId || slugId(t.title))
        const rec = mastery(key)
        if (['not_started'].includes(rec.status)) rec.status = 'learning'
        rec.sources.push({ type: 'youtube', videoId: ds.vid, topicId: ds.tid, at: new Date().toISOString() })
        save('mastery')
        showSyncedBadge()
      }
    }
  }
  saveVideos()
  renderFocusLab()
}
function slugId(s) {
  return String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48)
}
function showSyncedBadge() {
  const el = document.getElementById('sync-badge')
  if (el) { el.style.display = 'inline-flex'; setTimeout(() => { el.style.display = 'none' }, 1800) }
}

export function addTopicAtCurrent(_, ds) {
  if (!P.player || !P.videoId) { toast('⚠', 'Load a video first'); return }
  const t = Math.floor(P.player.getCurrentTime?.() || 0)
  const v = getVideo(P.videoId)
  const title = window.prompt('Topic title:', '')
  if (!title) return
  v.topics.push({ id: slugId(title) + '-' + Date.now().toString(36), title, startSec: t, endSec: t + 30, kind: 'concept', summary: '', keyPoints: [], formulas: [], importance: 'medium', _open: true })
  v.topics.sort((a, b) => a.startSec - b.startSec)
  v.analysedAt = v.analysedAt || Date.now()
  saveVideos()
  renderFocusLab()
}

export function setTopicNote(_, ds) {
  const v = getVideo(ds.vid)
  const t = v.topics.find(x => x.id === ds.tid)
  if (!t) return
  const note = window.prompt('Personal note for this topic:', t.note || '')
  if (note == null) return
  t.note = note
  saveVideos()
  renderFocusLab()
}

// ── export / attach ─────────────────────────────────────────────────────────
export function exportNotes(_, ds) {
  const v = getVideo(ds.vid)
  if (!v || !v.topics.length) { toast('ℹ', 'Nothing to export yet'); return }
  const lines = [`# ${v.title || 'Video notes'}`, '', `Link: https://www.youtube.com/watch?v=${ds.vid}`, `Analysed: ${v.analysedAt ? new Date(v.analysedAt).toLocaleString() : ''}`, '']
  for (const t of v.topics) {
    lines.push(`### ${fmtTime(t.startSec)} — ${t.title}`)
    if (t.summary) lines.push(t.summary)
    if (t.keyPoints?.length) lines.push('', 'Key points:', ...t.keyPoints.map(k => `- ${k}`))
    if (t.formulas?.length) lines.push('', 'Formulas:', ...t.formulas.map(f => `- ${f}`))
    if (t.note) lines.push('', `My note: ${t.note}`)
    lines.push('')
  }
  const md = lines.join('\n')
  navigator.clipboard.writeText(md).then(() => toast('📋', 'Notes copied to clipboard'), () => {})
  const blob = new Blob([md], { type: 'text/markdown' })
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob); a.download = `studyos-notes-${ds.vid}.md`; a.click()
  URL.revokeObjectURL(a.href)
}

export function attachToExam(_, ds) {
  const v = getVideo(ds.vid)
  const examId = document.getElementById('attach-exam-select')?.value
  if (!examId) return
  v.attachedExams = v.attachedExams || []
  if (!v.attachedExams.includes(examId)) v.attachedExams.push(examId)
  saveVideos()
  toast('📎', 'Video attached to exam — shows in Exam Prep chapter rows')
  renderFocusLab()
}

// ── active topic highlight ──────────────────────────────────────────────────
let lastActiveId = null
function updateActiveTopic(t) {
  const v = P.videoId ? getVideo(P.videoId) : null
  if (!v || !v.topics?.length) return
  let active = null
  for (const tp of v.topics) {
    if (t >= tp.startSec && (t < tp.endSec || !tp.endSec)) { active = tp; break }
  }
  if (!active && v.topics.length && t >= (v.topics[v.topics.length - 1].endSec || 0)) active = v.topics[v.topics.length - 1]
  if (active && active.id !== lastActiveId) {
    lastActiveId = active.id
    document.querySelectorAll('[data-topic-row]').forEach(el => {
      const on = el.dataset.topicRow === active.id
      el.classList.toggle('fl-active', on)
      if (on && !store.ui.flManualScroll) el.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
    })
  }
}
function updateTimelineMarker(t) {
  const marker = document.getElementById('tl-marker')
  const strip = document.getElementById('tl-strip')
  if (!marker || !strip) return
  const v = P.videoId ? getVideo(P.videoId) : null
  if (!v || !v.durationSec) return
  const pct = Math.min(t / v.durationSec, 1)
  marker.style.left = `calc(${pct * 100}% - 4px)`
}

// ── pomodoro widget ─────────────────────────────────────────────────────────
function pomodoroWidget() {
  const p = store.pomodoro
  const phase = p.phase === 'idle' ? 'focus' : p.phase
  const remainMs = pomo.remainingMs()
  const label = p.phase === 'idle' ? 'Ready' : pomo.phaseLabel(p.phase)
  const running = pomo.isRunning()
  const color = phase === 'focus' ? '#8B5CF6' : (phase === 'short' ? '#4ADE80' : '#60B5FF')
  const total = pomo.totalPhaseMs(phase)
  const progress = total ? 1 - (remainMs / total) : 0
  const circ = 2 * Math.PI * 54
  return `<div class="card pomo-card" style="margin-top:14px">
    <div style="display:flex;justify-content:space-between;align-items:center">
      <div class="card-label" style="margin-bottom:0">Pomodoro</div>
      <span class="chip" style="color:${color}">${p.phase !== 'idle' ? `Focus ${pomo.focusBlockIndex()} of ${pomo.blocksPerCycle()}` : `${pomo.blocksPerCycle()}-block cycles`}</span>
    </div>
    <div style="text-align:center;margin:14px 0 6px">
      <div style="position:relative;width:120px;height:120px;margin:0 auto">
        <svg width="120" height="120" aria-hidden="true">
          <circle cx="60" cy="60" r="54" fill="none" stroke="var(--hover)" stroke-width="7"/>
          <circle cx="60" cy="60" r="54" fill="none" stroke="${color}" stroke-width="7" stroke-dasharray="${circ}" stroke-dashoffset="${circ * (1 - progress)}" stroke-linecap="round" transform="rotate(-90 60 60)" style="transition:stroke-dashoffset 1s linear;filter:drop-shadow(0 0 6px ${color})"/>
        </svg>
        <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
          <div id="pomo-time" style="font-family:var(--font-mono);font-size:24px;color:var(--white);font-weight:700">${fmtTime(remainMs / 1000)}</div>
          <div style="font-size:10px;color:${color};margin-top:2px">${label}</div>
        </div>
      </div>
    </div>
    <div style="display:flex;gap:6px;justify-content:center;flex-wrap:wrap">
      <button class="btn" data-action="pomo-start" style="background:rgba(139,92,246,.16);border:1px solid rgba(139,92,246,.4);color:#C084FC">${p.phase === 'idle' ? 'START' : (running ? 'PAUSE' : 'RESUME')}</button>
      <button class="btn btn-ghost" data-action="pomo-skip" style="padding:9px 12px;font-size:11px">SKIP</button>
      <button class="btn btn-ghost" data-action="pomo-add5" style="padding:9px 12px;font-size:11px">+5m</button>
      <button class="btn btn-ghost" data-action="pomo-reset" style="padding:9px 12px;font-size:11px">RESET</button>
    </div>
    <div style="display:flex;gap:4px;justify-content:center;margin-top:12px">
      ${Array.from({ length: pomo.blocksPerCycle() }, (_, i) => `<span style="width:18px;height:4px;border-radius:2px;background:${i < (p.cyclesDone % pomo.blocksPerCycle()) ? color : 'var(--hover)'}"></span>`).join('')}
    </div>
  </div>`
}

// ── main renderer ───────────────────────────────────────────────────────────
export function renderFocusLab() {
  const videoId = store.ui.focusLabVideoId
  const v = videoId ? getVideo(videoId) : null
  const url = store.ui.focusLabUrl || ''
  const error = store.ui.focusLabError
  const analysing = store.ui.focusLabAnalysing

  const playerBlock = `
    <div class="card" style="position:sticky;top:120px">
      <div style="display:flex;gap:8px;margin-bottom:12px">
        <input id="focus-url" value="${esc(url)}" placeholder="Paste a YouTube lecture link…" data-action="focus-url-input" style="flex:1" spellcheck="false">
        <button class="btn" data-action="focus-load" style="background:rgba(96,181,255,.16);border:1px solid rgba(96,181,255,.4);color:#60B5FF">Load</button>
      </div>
      <div id="yt-mount" style="aspect-ratio:16/9;background:var(--card2);border-radius:12px;overflow:hidden;border:1px solid var(--border)">
        ${!videoId ? '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--dim);font-size:13px">Load a video to begin</div>' : ''}
      </div>
      ${error ? errorBanner(error, videoId) : ''}
      ${videoId && v ? videoMetaBar(v, videoId) : ''}
      ${videoId ? timelineStrip(v, videoId) : ''}
    </div>`

  const topicsBlock = `
    <div style="display:flex;flex-direction:column;gap:14px;min-width:0">
      ${pomodoroWidget()}
      <div class="card" style="position:sticky;top:120px;max-height:calc(100vh - 160px);display:flex;flex-direction:column">
        <div class="card-label">Topics</div>
        <div style="display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap;align-items:center">
          ${v ? `<span class="chip" style="color:var(--muted)">covered ${v.topicChecks ? Object.keys(v.topicChecks).filter(k => v.topicChecks[k]).length : 0}/${v.topics?.length || 0}</span>` : ''}
          ${v && v.meta?.provider ? `<span class="chip" style="color:#8B5CF6">${v.meta.provider}${v.source === 'fuzzy' ? '·fuzzy' : ''}</span>` : ''}
          <span id="sync-badge" class="chip" style="display:none;background:rgba(74,222,128,.14);color:var(--green)">synced to Exam Prep</span>
          <div style="margin-left:auto;display:flex;gap:6px">
            ${v && v.topics?.length ? `<button class="btn btn-ghost" data-action="export-notes" data-vid="${videoId}" style="padding:5px 10px;font-size:10px">⬇ Notes</button>` : ''}
            ${v ? `<button class="btn btn-ghost" data-action="analyse" data-id="${videoId}" style="padding:5px 10px;font-size:10px">${v.analysedAt ? 'Re-analyse' : 'Analyse'}</button>` : ''}
            <button class="btn btn-ghost" data-action="add-topic-now" style="padding:5px 10px;font-size:10px" ${P.player ? '' : 'disabled'}>+ Add topic at time</button>
          </div>
        </div>
        ${v && v.attachedExams?.length ? `<div style="font-size:10px;color:var(--muted);margin-bottom:8px">📎 attached to: ${v.attachedExams.map(id => EX_LABEL[id] || id).join(', ')}</div>` : ''}
        <div style="display:flex;gap:8px;align-items:center;margin-bottom:8px">
          <select id="attach-exam-select" style="flex:1;padding:5px 8px;font-size:11px">
            <option value="">Attach to exam…</option>
            ${SUBJECT_ORDER.length ? EX_OPTIONS : ''}
          </select>
          <button class="btn btn-ghost" data-action="attach-exam" data-vid="${videoId || ''}" style="padding:5px 10px;font-size:10px">Attach</button>
        </div>
        <div id="topic-list" style="overflow-y:auto;flex:1;min-height:0">
          ${topicListHTML(v, videoId, analysing)}
        </div>
      </div>
    </div>`

  return `<div class="fadein">
    <div style="display:flex;gap:18px;align-items:flex-start" class="focuslab-grid">
      <div style="flex:1;min-width:0">${playerBlock}</div>
      <div style="width:390px;flex-shrink:0">${topicsBlock}</div>
    </div>
  </div>`
}

const EX_LABEL = { ut1: 'UT-1', ut2: 'UT-2', half_yearly: 'Half-Yearly', preboard1: 'Pre-Board 1', preboard2: 'Pre-Board 2', boards: 'Boards' }
const EX_OPTIONS = Object.entries(EX_LABEL).map(([id, l]) => `<option value="${id}">${l}</option>`).join('')

function errorBanner(err, videoId) {
  if (err.type === 'parse') return `<div style="background:rgba(255,107,107,.09);border:1px solid rgba(255,107,107,.3);border-radius:10px;padding:10px 14px;font-size:12px;color:var(--red);margin-top:10px">⚠ ${esc(err.msg)}</div>`
  if (err.type === 'embed') {
    return `<div style="background:rgba(245,200,66,.09);border:1px solid rgba(245,200,66,.3);border-radius:10px;padding:12px 14px;margin-top:10px;font-size:12px;color:var(--muted)">
      <div style="color:var(--warn);font-weight:600;margin-bottom:4px">⚠ Embedding is disabled for this video</div>
      ${videoId ? `<a href="https://www.youtube.com/watch?v=${videoId}" target="_blank" rel="noopener" style="color:#60B5FF">Open on YouTube ↗</a> · analysis still works below` : ''}
    </div>`
  }
  if (err.type === 'ai') {
    const msg = err.code === 'NO_KEY' ? 'No Gemini API key set. Add one in Settings → AI to analyse videos.' : err.code === 'VIDEO_UNSUPPORTED' ? 'This video is private, age-restricted or region-locked. Try transcript mode or add topics manually.' : err.code === 'RATE_LIMITED' ? 'Rate limited — wait a minute and retry.' : err.code === 'BAD_KEY' ? 'Gemini API key rejected. Check Settings → AI.' : err.code === 'NO_PROXY' ? 'Proxy mode needs a server. Set the proxy URL in Settings, or switch to direct mode.' : (err.detail || 'Analysis failed.')
    return `<div style="background:rgba(255,107,107,.09);border:1px solid rgba(255,107,107,.3);border-radius:10px;padding:12px 14px;margin-top:10px;font-size:12px;color:var(--muted)">
      <div style="color:var(--red);font-weight:600;margin-bottom:4px">⚠ ${esc(msg)}</div>
      <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap">
        <button class="btn btn-ghost" data-action="analyse" data-id="${videoId || ''}" style="padding:6px 12px;font-size:10px">Retry</button>
        <button class="btn btn-ghost" data-action="add-topic-now" style="padding:6px 12px;font-size:10px">Add topics manually</button>
      </div>
    </div>`
  }
  return ''
}

function videoMetaBar(v, videoId) {
  const resume = v.lastPosition > 5 && v.lastPosition < (v.durationSec - 10)
  const watched = v.topics?.length ? v.topics.reduce((a, t) => a + Math.max(0, (t.endSec || 0) - t.startSec), 0) : 0
  const covered = v.topicChecks ? Object.values(v.topicChecks).filter(Boolean).length : 0
  return `<div style="margin-top:12px">
    <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap">
      <div style="flex:1;min-width:0">
        <div style="font-size:14px;font-weight:600;color:var(--white);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(v.title || 'Video')}</div>
        <div style="font-size:11px;color:var(--muted);margin-top:2px">${esc(v.channel || '')}${v.durationSec ? ` · ${fmtTime(v.durationSec)}` : ''}${v.analysedAt ? ` · analysed ${timeAgo(v.analysedAt)}` : ''}</div>
      </div>
      ${resume ? `<button class="btn btn-ghost" data-action="resume" data-id="${videoId}" style="padding:6px 12px;font-size:10px;color:#60B5FF">Resume at ${fmtTime(v.lastPosition)}</button>` : ''}
    </div>
    ${v.topics?.length ? `<div style="display:flex;gap:6px;align-items:center;margin-top:8px">
      <span class="chip" style="color:var(--muted)">covered ${covered}/${v.topics.length}</span>
      <span class="chip" style="color:var(--muted)">${fmtTime(watched)} of ${fmtTime(v.durationSec)} watched</span>
    </div>` : ''}
  </div>`
}

function timelineStrip(v, videoId) {
  if (!v.topics?.length) return ''
  const dur = Math.max(v.durationSec, 1)
  const segs = v.topics.map(t => {
    const s = (t.startSec / dur) * 100
    const e = Math.max(((t.endSec || t.startSec + 20) / dur) * 100, s + 0.4)
    const color = { high: '#FF6B6B', medium: '#F5C842', low: '#60B5FF' }[t.importance] || '#60B5FF'
    return `<button data-action="seek-topic" data-vid="${videoId}" data-t="${t.startSec}" title="${esc(t.title)} · ${fmtTime(t.startSec)}" style="position:absolute;left:${s}%;width:${e - s}%;height:100%;background:${color}${t.kind === 'admin' ? '33' : '88'};border:none;border-radius:2px;cursor:pointer;padding:0"></button>`
  }).join('')
  return `<div style="margin-top:12px">
    <div id="tl-strip" style="position:relative;height:10px;background:var(--hover);border-radius:5px;overflow:hidden">${segs}<div id="tl-marker" style="position:absolute;top:-3px;left:0;width:8px;height:16px;border-radius:3px;background:var(--white);box-shadow:0 0 6px rgba(255,255,255,.6);pointer-events:none"></div></div>
    <div style="display:flex;justify-content:space-between;font-size:9px;color:var(--dim);margin-top:4px"><span>0:00</span><span>${fmtTime(v.durationSec)}</span></div>
  </div>`
}

function topicListHTML(v, videoId, analysing) {
  if (!videoId) return `<div style="padding:26px 10px;text-align:center;color:var(--dim);font-size:12.5px">Load a lecture link to get AI-extracted topics with timestamps.</div>`
  if (analysing) {
    return `<div style="padding:26px 10px;text-align:center;color:var(--muted);font-size:12.5px">
      <div class="thinking-bar"></div>
      <div style="margin-top:8px">${esc(store.ui.focusLabProgress || 'Analysing…')}</div>
      <button class="btn btn-ghost" data-action="cancel-analysis" style="margin-top:12px;padding:6px 12px;font-size:10px">Cancel</button>
    </div>`
  }
  if (!v || !v.topics?.length) {
    return `<div style="padding:26px 10px;text-align:center;color:var(--dim);font-size:12.5px;line-height:1.7">No topics yet.<br>Press <strong style="color:var(--white)">Analyse</strong> (Gemini watches the video) or add topics manually.</div>`
  }
  return v.topics.map((t, i) => {
    const active = t.id === lastActiveId ? 'fl-active' : ''
    const checked = !!v.topicChecks?.[t.id]
    const open = !!t._open
    const kindIcon = { concept: '📘', derivation: '🧮', formula: 'ƒ', numerical: '🔢', example: '✏️', revision: '🔄', admin: '📢' }[t.kind] || '📘'
    const diff = t.difficulty === 'hard' ? '<span style="color:#FF6B6B" title="hard">●</span>' : t.difficulty === 'medium' ? '<span style="color:#F5C842" title="medium">●</span>' : t.difficulty === 'easy' ? '<span style="color:#4ADE80" title="easy">●</span>' : ''
    const mapped = t.syllabusChapterId
    return `<div data-topic-row="${t.id}" class="fl-topic ${active}" style="border:1px solid var(--border);border-radius:10px;padding:8px 10px;margin-bottom:6px;transition:all .2s">
      <div style="display:flex;align-items:flex-start;gap:8px">
        <span class="chip" data-action="seek-topic" data-vid="${videoId}" data-t="${t.startSec}" style="cursor:pointer;color:#60B5FF;font-family:var(--font-mono);flex-shrink:0;margin-top:1px">${fmtTime(t.startSec)}</span>
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:6px">
            <span style="font-size:10px;color:var(--dim)">${kindIcon}</span>
            <span style="font-size:12.5px;color:var(--white);font-weight:500;cursor:pointer" data-action="toggle-topic-expand" data-vid="${videoId}" data-tid="${t.id}">${esc(t.title)}</span>
            ${diff}
          </div>
          <div style="font-size:11px;color:var(--muted);margin-top:3px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">${esc(t.summary || '')}</div>
          ${mapped ? `<div style="font-size:9.5px;color:#8B5CF6;margin-top:4px">↳ ${chapterName(t.syllabusChapterId)}${t.mapping === 'fuzzy' ? ' (suggested)' : ''}</div>` : ''}
          ${t.note ? `<div style="font-size:10.5px;color:var(--warn);margin-top:4px">📝 ${esc(t.note)}</div>` : ''}
        </div>
        <label class="fl-check" title="Mark covered" style="flex-shrink:0">
          <input type="checkbox" ${checked ? 'checked' : ''} data-action="topic-check" data-vid="${videoId}" data-tid="${t.id}" style="accent-color:#8B5CF6;width:15px;height:15px">
        </label>
      </div>
      ${open ? `<div style="margin:8px 0 2px 30px;border-top:1px dashed var(--border);padding-top:8px">
        ${t.keyPoints?.length ? `<div style="font-size:10px;color:var(--dim);letter-spacing:1px;text-transform:uppercase;margin-bottom:4px">Key points</div><div style="font-size:11.5px;color:var(--muted);line-height:1.6">${t.keyPoints.map(k => `• ${esc(k)}`).join('<br>')}</div>` : ''}
        ${t.formulas?.length ? `<div style="font-size:10px;color:var(--dim);letter-spacing:1px;text-transform:uppercase;margin:8px 0 4px">Formulas</div><div style="font-size:11.5px;font-family:var(--font-mono);color:#F5C842;line-height:1.7">${t.formulas.map(f => `ƒ ${esc(f)}`).join('<br>')}</div>` : ''}
        <button class="btn btn-ghost" data-action="topic-note" data-vid="${videoId}" data-tid="${t.id}" style="margin-top:8px;padding:4px 10px;font-size:9.5px">📝 ${t.note ? 'Edit note' : 'Add note'}</button>
      </div>` : ''}
    </div>`
  }).join('')
}
function chapterName(chId) {
  const found = chapterById().get(chId)
  return found ? found.chapter.name : chId
}
function timeAgo(ts) {
  const s = Math.floor((Date.now() - ts) / 1000)
  if (s < 60) return 'just now'
  if (s < 3600) return `${Math.floor(s / 60)} min ago`
  if (s < 86400) return `${Math.floor(s / 3600)} hr ago`
  return `${Math.floor(s / 86400)} d ago`
}

// ── pomodoro actions ────────────────────────────────────────────────────────
export function pomoStart() {
  const before = pomo.currentPhase()
  const res = pomo.start()
  if (!res.started && before !== 'idle') { pomo.pause() }
  renderFocusLab()
  updatePomoTime()
}
export function pomoSkip() {
  pomo.skipPhase()
  afterPhaseChange()
  renderFocusLab()
  updatePomoTime()
}
export function pomoAdd5() { pomo.addMinutes(5); renderFocusLab(); updatePomoTime() }
export function pomoReset() {
  if (store.settings.pomodoro.strictMode) {
    if (!window.confirm('Reset the pomodoro?')) return
  }
  pomo.reset()
  renderFocusLab()
  updatePomoTime()
}

export function updatePomoTime() {
  const el = document.getElementById('pomo-time')
  if (el) el.textContent = fmtTime(pomo.remainingMs() / 1000)
}

/** Called by router tick while on focusLab — keeps the ring live. */
export function focusLabTick() {
  updatePomoTime()
  if (P.player && P.videoId && document.visibilityState === 'visible') {
    try { const t = P.player.getCurrentTime?.() || 0; updateTimelineMarker(t) } catch {}
  }
}

// ── phase-change side effects (video auto-pause, calm fluid, wake lock) ─────
export function afterPhaseChange() {
  const phase = pomo.currentPhase()
  if (phase === 'focus') {
    if (store.settings.pomodoro.autoPauseVideo && P.player) { try { P.player.playVideo() } catch {} }
  } else {
    if (store.settings.pomodoro.autoPauseVideo && P.player) { try { P.player.pauseVideo() } catch {} }
    pomo.notify(pomo.phaseLabel(phase) + ' finished', 'Time for the next phase.')
  }
  pomo.chime()
  document.title = `⏱ ${pomo.phaseLabel(phase)} — StudyOS`
  setTimeout(() => { document.title = 'StudyOS — ISC Class XII' }, 3000)
}

/** Subscribe to pomodoro phase events (wired in main.js). */
export function onPomodoroPhase(phase) {
  afterPhaseChange()
}

// expose some things for main.js
export function getPlayer() { return P }

/** Started from the Exam Prep revision queue: attach those topics to the next focus block. */
export function attachRevisionTopics() {
  const queue = revisionQueue().list.slice(0, 6)
  store.ui.pendingRevisionKeys = queue.map(q => q.key)
  pomo.start()
  toast('🎯', queue.length ? `Revision focus: ${queue.length} due topics attached` : 'No revision topics due')
  renderFocusLab()
  updatePomoTime()
}

/**
 * features/checklist.js — Syllabus tab. Dual tracking preserved ("My Progress"
 * vs "Progress in School") but now over all six subjects and the v2 mastery
 * model: "my" = mastery.status revised+, "school" = mastery.school flag.
 */
import { store, save } from '../state/store.js'
import { syllabus, SUBJECT_ORDER, topicKey, totals } from '../data/syllabus.js'
import { SUBJECTS } from '../../syllabus-exams.data.js'
import { mastery, defaultMasteryRecord } from '../state/mastery.js'
import { fuzzyMatch, highlightMatch } from '../lib/fuzzy.js'
import { esc } from '../lib/format.js'
import { ringHTML, miniBarHTML, emptyState } from '../lib/ui.js'

const STATUS_LEVEL = { not_started: 0, learning: 1, revised: 2, mastered: 3 }
const CHECK_TYPES = {
  my: { label: 'My Progress', short: 'My', grad: 'linear-gradient(135deg,#60B5FF,#8B5CF6)', color: '#60B5FF' },
  school: { label: 'Progress in School', short: 'School', grad: 'linear-gradient(135deg,#4ADE80,#2DD4BF)', color: '#4ADE80' },
}

function isMyDone(key) {
  const m = store.mastery[key]
  return m && STATUS_LEVEL[m.status] >= 2
}
function isSchoolDone(key) {
  return !!(store.mastery[key] && store.mastery[key].school)
}

function searchMatches() {
  const q = store.ui.checklistSearch.trim()
  if (!q) return null
  const out = []
  for (const sk of SUBJECT_ORDER) {
    for (const ch of syllabus()[sk]) {
      for (const tp of ch.topics) {
        const m = fuzzyMatch(q, tp.title) || fuzzyMatch(q, ch.name) || fuzzyMatch(q, SUBJECTS[sk].name)
        if (m) out.push({ sk, ch, tp, score: m.score + (fuzzyMatch(q, tp.title)?.score || 0) })
      }
    }
  }
  out.sort((a, b) => b.score - a.score)
  return out.slice(0, 30)
}

export function renderChecklist() {
  const type = store.ui.activeChecklist
  const matches = searchMatches()
  const t = totals()
  let myDone = 0, schoolDone = 0
  for (const key of Object.keys(store.mastery)) {
    if (isMyDone(key)) myDone++
    if (isSchoolDone(key)) schoolDone++
  }
  const overallTotal = t.topics
  const overallDone = type === 'my' ? myDone : schoolDone
  const overallPct = Math.round((overallDone / overallTotal) * 100) || 0

  const searchHTML = `
    <div class="search-wrap">
      <span class="search-icon">⌕</span>
      <input id="cl-search" value="${esc(store.ui.checklistSearch)}" placeholder="Search topics… (e.g. gauss, kinetics, bayes)" data-action="checklist-search">
    </div>
    ${store.ui.checklistSearch ? `<button class="btn btn-ghost" style="padding:8px 13px;font-size:11px" data-action="checklist-clear">Clear</button>` : ''}`

  let bodyHTML
  if (matches) {
    const q = store.ui.checklistSearch.trim()
    bodyHTML = matches.length ? matches.map(({ sk, ch, tp }) => {
      const key = topicKey(sk, ch.id, tp.id)
      const done = type === 'my' ? isMyDone(key) : isSchoolDone(key)
      return `<div class="topic-item" data-topic-key="${key}" style="padding:8px 12px;background:var(--card);border:1px solid var(--border);border-radius:9px;margin-bottom:6px">
        <div class="topic-check ${done ? 'done' : ''}" role="checkbox" aria-checked="${done}" tabindex="0" data-action="toggle-checklist" data-type="${type}" data-key="${key}" onkeydown="if(event.key===' '){event.preventDefault();document.querySelector('[data-topic-key=&quot;${key}&quot;] [data-action=&quot;toggle-checklist&quot;]').click()}">${done ? '<span style="font-size:10px;color:var(--green)">✓</span>' : ''}</div>
        <div style="flex:1"><div style="color:${done ? 'var(--dim)' : 'var(--muted)'};text-decoration:${done ? 'line-through' : 'none'}">${highlightMatch(esc(tp.title), esc(q))}</div>
        <div style="font-size:10.5px;color:var(--dim);margin-top:2px">${SUBJECTS[sk].icon} ${SUBJECTS[sk].name} · ${esc(ch.name)}</div></div>
      </div>`
    }).join('')
      : emptyState('⌕', 'No topics found', `Nothing matched “<strong style="color:var(--text)">${esc(store.ui.checklistSearch)}</strong>”. Try fewer letters — search is fuzzy.`)
  } else {
    bodyHTML = SUBJECT_ORDER.map(sk => {
      const subj = SUBJECTS[sk]
      const chs = syllabus()[sk]
      const perSubj = { total: 0, done: 0 }
      for (const ch of chs) {
        for (const tp of ch.topics) {
          const key = topicKey(sk, ch.id, tp.id)
          perSubj.total++
          if ((type === 'my' ? isMyDone(key) : isSchoolDone(key))) perSubj.done++
        }
      }
      const pct = Math.round((perSubj.done / perSubj.total) * 100) || 0
      const chapters = chs.map(ch => {
        const chDone = ch.topics.filter(t => type === 'my' ? isMyDone(topicKey(sk, ch.id, t.id)) : isSchoolDone(topicKey(sk, ch.id, t.id))).length
        const isOpen = !!store.ui.openChapters[`${sk}:${ch.id}`]
        const allDone = chDone === ch.topics.length && ch.topics.length > 0
        const partial = chDone > 0 && !allDone
        const checkState = allDone ? 'done' : (partial ? 'partial' : '')
        return `<div class="checklist-chapter">
          <div class="checklist-chapter-header" data-action="toggle-chapter" data-sk="${sk}" data-chid="${ch.id}">
            <span style="font-size:12px;color:${isOpen ? subj.color : 'var(--muted)'};transform:rotate(${isOpen ? 90 : 0}deg);transition:transform .15s">▸</span>
            <span style="flex:1;color:${allDone ? 'var(--green)' : (partial ? subj.color : 'var(--text)')}">${esc(ch.name)}${ch.no ? ` <span style="font-size:10px;color:var(--dim)">Ch ${ch.no}</span>` : ''}</span>
            <span class="progress-chip" style="color:${allDone ? 'var(--green)' : (partial ? subj.color : 'var(--dim)')}">${chDone}/${ch.topics.length}</span>
            <div class="chapter-check ${checkState}" data-action="toggle-chapter-all" data-sk="${sk}" data-chid="${ch.id}" title="Toggle all topics in chapter">${allDone ? '<span style="font-size:10px;color:var(--green)">✓</span>' : (partial ? '<span style="font-size:8px;color:#F5C842">▪</span>' : '')}</div>
          </div>
          <div class="checklist-topics ${isOpen ? 'open' : ''}">
            ${ch.topics.map(tp => {
              const key = topicKey(sk, ch.id, tp.id)
              const done = type === 'my' ? isMyDone(key) : isSchoolDone(key)
              return `<div class="topic-item" data-topic-key="${key}">
                <div class="topic-check ${done ? 'done' : ''}" role="checkbox" aria-checked="${done}" tabindex="0" data-action="toggle-checklist" data-type="${type}" data-key="${key}" onkeydown="if(event.key===' '){event.preventDefault();this.click()}">${done ? '<span style="font-size:10px;color:var(--green)">✓</span>' : ''}</div>
                <span style="text-decoration:${done ? 'line-through' : 'none'};color:${done ? 'var(--dim)' : 'var(--muted)'}">${esc(tp.title)}</span>
              </div>`}).join('')}
          </div>
        </div>`
      }).join('')
      return `<div class="checklist-subject" style="border-color:${subj.color}25">
        <div class="checklist-subject-header" style="background:${subj.color}0f" data-action="toggle-subject" data-sk="${sk}">
          <div style="display:flex;align-items:center;gap:12px">
            <span style="font-size:22px">${subj.icon}</span>
            <div><div style="font-size:15px;font-weight:600;color:${subj.color}">${subj.name}</div>
            <div style="font-size:11px;color:var(--muted);margin-top:2px">${chs.length} chapters · ${perSubj.total} topics</div></div>
          </div>
          <div style="display:flex;align-items:center;gap:16px">
            <div style="text-align:right">
              <div style="font-size:18px;font-weight:600;color:${pct === 100 ? 'var(--green)' : subj.color};font-family:var(--font-mono)">${pct}%</div>
              <div style="font-size:11px;color:var(--muted)">${perSubj.done}/${perSubj.total} done</div>
            </div>
            <div style="width:48px;height:48px;flex-shrink:0">${ringHTML(perSubj.done / perSubj.total, pct === 100 ? '#4ADE80' : subj.color, 48, 5, `<div style="font-size:10px;color:var(--white);font-weight:600">${pct}%</div>`)}</div>
          </div>
        </div>
        <div style="display:${store.ui.openChapters['subject_' + sk] === false ? 'none' : 'block'}">${chapters}</div>
      </div>`
    }).join('')
  }

  const tabMy = type === 'my'
  return `<div class="fadein">
    <div style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap;align-items:center">
      <div style="display:flex;gap:8px;background:var(--hover);padding:6px;border-radius:12px">
        ${['my', 'school'].map(t => `<button data-action="switch-checklist" data-type="${t}" style="padding:10px 16px;border-radius:8px;border:none;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s;background:${type === t ? CHECK_TYPES[t].grad : 'transparent'};color:${type === t ? '#fff' : 'var(--muted)'}">${t === 'my' ? '📚 My Progress' : '🏫 Progress in School'}</button>`).join('')}
      </div>
      ${searchHTML}
    </div>
    ${matches ? '' : `
    <div style="margin-bottom:20px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;gap:12px;flex-wrap:wrap">
        <div><div style="font-size:16px;font-weight:600;color:var(--white)">${CHECK_TYPES[type].label}</div>
        <div style="font-size:12px;color:var(--muted);margin-top:3px">${overallDone} of ${overallTotal} topics completed across all subjects</div></div>
        <div style="font-size:32px;font-weight:700;color:${overallPct === 100 ? 'var(--green)' : (tabMy ? '#60B5FF' : '#4ADE80')};font-family:var(--font-mono)">${overallPct}%</div>
      </div>
      <div style="background:var(--hover);border-radius:4px;height:8px;overflow:hidden;margin-bottom:14px">
        <div style="height:100%;background:${CHECK_TYPES[type].grad};border-radius:4px;width:${overallPct}%;transition:width .3s"></div>
      </div>
      <div style="display:flex;gap:12px;flex-wrap:wrap">
        ${SUBJECT_ORDER.map(sk => { const s = SUBJECTS[sk]; const chs = syllabus()[sk]; let d = 0, tot = 0; for (const ch of chs) for (const tp of ch.topics) { tot++; const key = topicKey(sk, ch.id, tp.id); if (type === 'my' ? isMyDone(key) : isSchoolDone(key)) d++ }
          return `<div style="flex:1;min-width:150px;background:${s.color}0f;border:1px solid ${s.color}30;border-radius:8px;padding:10px 14px">
            <div style="font-size:12px;color:${s.color};font-weight:500">${s.name}</div>
            <div style="font-size:11px;color:var(--muted);margin-top:2px">${d}/${tot} · ${Math.round(d / tot * 100) || 0}%</div>
            ${miniBarHTML(d, tot, s.color)}</div>` }).join('')}
      </div>
    </div>`}
    <div style="font-size:10px;color:var(--dim);margin-bottom:14px;text-transform:uppercase;letter-spacing:3px">Click topics to mark done · auto-saved</div>
    ${bodyHTML}
  </div>`
}

export function toggleChecklistTopic(type, key) {
  const m = mastery(key)
  if (type === 'my') {
    m.status = STATUS_LEVEL[m.status] >= 2 ? 'not_started' : 'revised'
    if (m.status === 'revised') m.lastRevisedAt = m.lastRevisedAt || new Date().toISOString()
  } else {
    m.school = !m.school
  }
  save('mastery')
}
export function toggleChapterAll(sk, chId) {
  const ch = syllabus()[sk].find(c => c.id === chId)
  if (!ch) return
  const type = store.ui.activeChecklist
  const keys = ch.topics.map(t => topicKey(sk, chId, t.id))
  const allDone = keys.every(k => type === 'my' ? isMyDone(k) : isSchoolDone(k))
  for (const k of keys) {
    const m = mastery(k)
    if (type === 'my') m.status = allDone ? 'not_started' : 'revised'
    else m.school = allDone ? false : true
  }
  save('mastery')
}
export function toggleChapterOpen(sk, chId) {
  const k = `${sk}:${chId}`
  store.ui.openChapters[k] = !store.ui.openChapters[k]
}
export function toggleSubjectOpen(sk) {
  store.ui.openChapters['subject_' + sk] = (store.ui.openChapters['subject_' + sk] === false ? true : false)
}

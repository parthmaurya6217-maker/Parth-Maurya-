/**
 * features/schedule.js — session model + Schedule tab (ported from v1).
 */
import { SESSIONS } from '../data/sessions.js'
import { SUBJECTS } from '../../syllabus-exams.data.js'
import { store, toggleSession, sessionDoneToday } from '../state/store.js'
import { toMins, fmt12 } from '../lib/time.js'
import { esc } from '../lib/format.js'

export { SESSIONS }

export const isStudySession = s => s.type === 'study' || s.type === 'revision'
export const STUDY_TYPES = isStudySession

export function getCurrentSession(nowD) {
  const cur = nowD.getHours() * 60 + nowD.getMinutes()
  return SESSIONS.find(s => cur >= toMins(s.start) && cur < toMins(s.end)) || null
}
export function getNextSession(nowD) {
  const cur = nowD.getHours() * 60 + nowD.getMinutes()
  const up = SESSIONS.find(s => toMins(s.start) > cur)
  return up || SESSIONS.find(s => s.type !== 'break')
}
export function getProgress(s, nowD) {
  const cur = nowD.getHours() * 60 + nowD.getMinutes() + nowD.getSeconds() / 60
  const st = toMins(s.start), en = toMins(s.end)
  return Math.min(Math.max((cur - st) / (en - st), 0), 1)
}
export function getRemaining(s, nowD) {
  const endSec = toMins(s.end) * 60
  const curSec = nowD.getHours() * 3600 + nowD.getMinutes() * 60 + nowD.getSeconds()
  const rem = Math.max(endSec - curSec, 0)
  return { h: Math.floor(rem / 3600), m: Math.floor((rem % 3600) / 60), s: rem % 60, total: rem }
}

export function renderSchedule() {
  const now = new Date()
  const sess = getCurrentSession(now)
  const html = SESSIONS.map((s, i) => {
    const isCur = sess?.id === s.id
    const isPast = now.getHours() * 60 + now.getMinutes() >= toMins(s.end)
    const isDone = sessionDoneToday(s.id)
    const col = s.subject ? (SUBJECTS[s.subject]?.color || '#64748B') : (s.type === 'break' ? '#475569' : '#334155')
    const subj = s.subject ? SUBJECTS[s.subject] : null
    const dur = toMins(s.end) - toMins(s.start)
    const clickable = isStudySession(s)
    return `<div style="display:flex;gap:0;align-items:stretch">
      <div style="display:flex;flex-direction:column;align-items:center;width:44px;flex-shrink:0">
        <div style="width:10px;height:10px;border-radius:50%;background:${isCur ? col : (isPast || isDone) ? 'var(--dim)' : 'var(--hover)'};border:2px solid ${isCur ? col : 'transparent'};flex-shrink:0;margin-top:18px;box-shadow:${isCur ? `0 0 12px ${col}` : 'none'}"></div>
        ${i < SESSIONS.length - 1 ? '<div style="width:1px;flex:1;background:var(--border);margin-top:4px"></div>' : ''}
      </div>
      <div style="flex:1;margin-bottom:8px;margin-left:8px">
        <div class="hov" data-action="${clickable ? 'toggle-session' : ''}" data-id="${s.id}"
          style="background:${isCur ? `${col}08` : 'var(--card)'};border:1px solid ${isCur ? col + '45' : 'var(--border)'};border-radius:11px;padding:14px 18px;cursor:${clickable ? 'pointer' : 'default'};opacity:${isPast && !isCur && !isDone ? 0.4 : 1};transition:all .25s;box-shadow:var(--shadow-card)">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
            <div style="display:flex;align-items:center;gap:14px">
              <div style="width:40px;height:40px;border-radius:9px;background:${subj ? (subj.color + '14') : 'var(--hover)'};display:flex;align-items:center;justify-content:center;font-size:20px;border:1px solid ${col}25;flex-shrink:0">${s.icon}</div>
              <div>
                <div style="font-size:14px;color:${isDone ? 'var(--dim)' : 'var(--white)'};font-weight:500;text-decoration:${isDone ? 'line-through' : 'none'}">${esc(s.label)}</div>
                ${s.subtitle ? `<div style="font-size:12px;color:var(--muted);margin-top:3px">${esc(s.subtitle)}</div>` : ''}
              </div>
            </div>
            <div style="text-align:right">
              <div style="font-size:13px;color:${col};font-family:var(--font-mono)">${fmt12(...s.start)} – ${fmt12(...s.end)}</div>
              <div style="font-size:11px;color:var(--dim);margin-top:3px">${dur} min</div>
              ${isDone ? '<div style="font-size:11px;color:var(--green);margin-top:4px">✓ Completed today</div>' : ''}
              ${isCur ? `<div style="font-size:11px;color:${col};margin-top:4px;animation:live 1.5s infinite">● Live now</div>` : ''}
            </div>
          </div>
          ${isCur ? (() => { const p = getProgress(sess, now), r = getRemaining(sess, now); return `<div style="margin-top:12px">
            <div style="background:var(--hover);border-radius:3px;height:4px;overflow:hidden">
              <div style="height:100%;background:${col};border-radius:3px;width:${Math.round(p * 100)}%;transition:width 1s linear;box-shadow:0 0 6px ${col}"></div>
            </div>
            <div style="font-size:11px;color:var(--dim);margin-top:5px;font-family:var(--font-mono)">${Math.round(p * 100)}% elapsed · ${String(r.m).padStart(2, '0')}:${String(r.s).padStart(2, '0')} remaining</div>
          </div>` })() : ''}
        </div>
      </div>
    </div>`
  }).join('')
  return `<div class="fadein" style="max-width:760px">
    <div class="card-label">Daily Study Schedule — 4:00 PM to 11:00 PM</div>
    ${html}
  </div>`
}

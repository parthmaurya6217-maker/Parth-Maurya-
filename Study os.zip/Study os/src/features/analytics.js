/**
 * features/analytics.js — Analytics tab (v1 charts preserved) + focus minutes
 * by subject, readiness trend per exam and mock-marks charts (inline SVG).
 */
import { store } from '../state/store.js'
import { SESSIONS } from '../data/sessions.js'
import { isStudySession } from './schedule.js'
import { todayKey, fmtSecs } from '../lib/time.js'
import { esc } from '../lib/format.js'
import { examMetrics } from '../state/mastery.js'
import { EXAM_ORDER, EXAMS } from '../data/exams.js'
import { syllabus, SUBJECT_ORDER, topicKey, totals } from '../data/syllabus.js'
import { SUBJECTS } from '../../syllabus-exams.data.js'
import { miniBarHTML } from '../lib/ui.js'

const STATUS_LEVEL = { not_started: 0, learning: 1, revised: 2, mastered: 3 }

export function renderAnalytics() {
  const studySessions = SESSIONS.filter(isStudySession)
  const doneCount = (store.data.completed[todayKey()] || []).filter(id => studySessions.some(s => s.id === id)).length
  const totalStudied = Object.values(store.data.subjectTime).reduce((a, b) => a + b, 0)
  const t = totals()
  let myDone = 0, schoolDone = 0
  for (const key of Object.keys(store.mastery)) {
    if (store.mastery[key].status && STATUS_LEVEL[store.mastery[key].status] >= 2) myDone++
    if (store.mastery[key].school) schoolDone++
  }
  const overallTotal = t.topics

  const hist = []
  let maxSecs = 0
  for (let i = 13; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i)
    const tk = todayKey(d)
    const day = store.data.days[tk]
    let secs = 0, done = 0
    if (i === 0) { secs = totalStudied; done = doneCount }
    else if (day) {
      secs = Object.values(day.seconds || {}).reduce((a, b) => a + b, 0)
      done = (day.completed || []).filter(id => studySessions.some(s => s.id === id)).length
    }
    maxSecs = Math.max(maxSecs, secs)
    hist.push({ tk, secs, done, label: d.toLocaleDateString('en-IN', { weekday: 'short' })[0] })
  }

  const streak = () => {
    let n = 0; const d = new Date()
    const isActive = tk => { const day = store.data.days[tk]; return !!day && ((day.completed?.length > 0) || Object.values(day.seconds || {}).reduce((a, b) => a + b, 0) >= 900) }
    if (!isActive(todayKey(d))) { d.setDate(d.getDate() - 1); if (!isActive(todayKey(d))) return 0 }
    while (isActive(todayKey(d))) { n++; d.setDate(d.getDate() - 1) }
    return n
  }

  const summaryItems = [
    { label: "Today Studied", value: fmtSecs(totalStudied), color: '#F5C842' },
    { label: "Sessions Done", value: `${doneCount}/${studySessions.length}`, color: '#4ADE80' },
    { label: "Current Streak", value: `${streak()} days`, color: '#FF8C00' },
    { label: "Best Streak", value: `${store.data.streak.bestStreak || 0} days`, color: '#C084FC' },
    { label: "My Syllabus", value: `${Math.round(myDone / Math.max(overallTotal, 1) * 100)}%`, color: '#60B5FF' },
    { label: "School Syllabus", value: `${Math.round(schoolDone / Math.max(overallTotal, 1) * 100)}%`, color: '#2DD4BF' },
  ]
  const hasHistory = hist.some(h => h.secs > 0)

  const focusBySubject = focusMinutesBySubject()
  const readinessTrend = readinessTrendChart()
  const mockChart = mockMarksChart()

  return `<div class="fadein">
    <div class="card-label">Study Analytics</div>
    <div class="stats-grid" style="display:grid;grid-template-columns:repeat(6,1fr);gap:14px;margin-bottom:22px">
      ${summaryItems.map(st => `<div class="card" style="text-align:center;padding:18px 12px">
        <div style="font-size:22px;font-weight:600;color:${st.color};font-family:var(--font-mono)">${st.value}</div>
        <div style="font-size:10.5px;color:var(--muted);margin-top:6px">${st.label}</div>
      </div>`).join('')}
    </div>

    <div class="analytics-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
      <div class="card">
        <div style="font-size:14px;font-weight:500;color:var(--white);margin-bottom:6px">Activity — Last 14 Days</div>
        <div style="font-size:11px;color:var(--dim);margin-bottom:18px">Minutes studied per day · hover for detail</div>
        ${hasHistory ? barChart(hist, maxSecs) : emptyLite('📈', 'No history yet', 'Mark sessions done or study during your scheduled window — activity will appear here day by day.')}
      </div>
      <div class="card">
        <div style="font-size:14px;font-weight:500;color:var(--white);margin-bottom:20px">Focus Minutes by Subject</div>
        ${Object.keys(focusBySubject).length ? Object.entries(focusBySubject).map(([sk, mins]) => {
          const subj = SUBJECTS[sk]
          return `<div style="margin-bottom:16px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
              <div style="font-size:13px;color:var(--white);font-weight:500">${subj ? subj.name : sk}</div>
              <div style="font-size:14px;color:${subj?.color || 'var(--muted)'};font-family:var(--font-mono)">${Math.round(mins)} min</div>
            </div>
            ${miniBarHTML(mins, Math.max(...Object.values(focusBySubject), 1), subj?.color || '#8B5CF6')}
          </div>`}).join('') : emptyLite('⏱', 'No focus sessions yet', 'Use the Pomodoro in Focus Lab — minutes attribute to the subject of the video or your pick.')}
      </div>
    </div>

    <div class="card" style="margin-top:20px">
      <div style="font-size:14px;font-weight:500;color:var(--white);margin-bottom:20px">Dual Progress Overview</div>
      <div class="analytics-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:28px">
        ${[['my', '#60B5FF', '📚', 'My Progress'], ['school', '#4ADE80', '🏫', 'School Progress']].map(([typ, col, ico, title]) => `
          <div>
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
              <span style="font-size:14px">${ico}</span><span style="font-size:13px;color:${col};font-weight:600">${title}</span>
            </div>
            ${SUBJECT_ORDER.map(sk => {
              const s = SUBJECTS[sk]; let d = 0, tot = 0
              for (const ch of syllabus()[sk]) for (const tp of ch.topics) { tot++; const key = topicKey(sk, ch.id, tp.id); if (typ === 'my' ? (store.mastery[key] && STATUS_LEVEL[store.mastery[key].status] >= 2) : (store.mastery[key] && store.mastery[key].school)) d++ }
              const pct = Math.round(d / tot * 100) || 0
              return `<div style="margin-bottom:12px">
                <div style="display:flex;justify-content:space-between;margin-bottom:6px">
                  <div style="font-size:12px;color:${s.color};font-weight:500">${s.icon} ${s.name}</div>
                  <div style="font-size:12px;color:var(--muted);font-family:var(--font-mono)">${d}/${tot} (${pct}%)</div>
                </div>
                <div style="background:var(--hover);border-radius:4px;height:6px;overflow:hidden">
                  <div style="height:100%;background:${col};border-radius:4px;width:${pct}%;transition:width .3s"></div>
                </div>
              </div>` }).join('')}
            <div style="display:flex;justify-content:space-between;padding-top:10px;border-top:1px solid var(--border)">
              <div style="font-size:13px;color:var(--white);font-weight:500">${title} Total</div>
              <div style="font-size:13px;color:${col};font-family:var(--font-mono)">${typ === 'my' ? myDone : schoolDone}/${overallTotal} (${Math.round((typ === 'my' ? myDone : schoolDone) / Math.max(overallTotal, 1) * 100)}%)</div>
            </div>
          </div>`).join('')}
      </div>
    </div>

    ${readinessTrend}
    ${mockChart}
  </div>`
}

function barChart(hist, maxSecs) {
  const W = 520, H = 150, n = hist.length, bw = W / n
  const bars = hist.map((h, i) => {
    const mins = Math.round(h.secs / 60)
    const bh = h.secs > 0 ? Math.max((h.secs / maxSecs) * (H - 34), 3) : 2
    const x = i * bw + bw * 0.18, bwid = bw * 0.64, y = H - 18 - bh
    const isToday = i === n - 1
    return `<g>
      <title>${h.tk}: ${mins} min · ${h.done} sessions</title>
      <rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${bwid.toFixed(1)}" height="${bh.toFixed(1)}" rx="3"
        fill="${isToday ? '#F5C842' : '#60B5FF'}" opacity="${h.secs > 0 ? 1 : 0.35}"/>
      ${h.done > 0 ? `<circle cx="${(x + bwid / 2).toFixed(1)}" cy="${(y - 6).toFixed(1)}" r="2.6" fill="#4ADE80"/>` : ''}
      <text x="${(x + bwid / 2).toFixed(1)}" y="${H - 5}" text-anchor="middle" font-size="8.5" fill="var(--dim)">${h.label}</text>
    </g>`
  }).join('')
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto" role="img" aria-label="Bar chart of minutes studied over last 14 days">
    <line x1="0" y1="${H - 17}" x2="${W}" y2="${H - 17}" stroke="var(--border)"/>${bars}</svg>
    <div style="display:flex;gap:16px;margin-top:10px;font-size:10.5px;color:var(--muted)">
      <span><span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:#F5C842;margin-right:5px"></span>today</span>
      <span><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#4ADE80;margin-right:5px"></span>sessions completed</span>
    </div>`
}

function focusMinutesBySubject() {
  const out = {}
  for (const s of store.sessions) {
    if (s.phase !== 'focus') continue
    const sk = s.subject
    if (sk) out[sk] = (out[sk] || 0) + (s.minutes || 0)
  }
  return out
}

function readinessTrendChart() {
  const points = store.history.filter(h => h.exam)
  if (points.length < 2) return ''
  const W = 900, H = 220, padL = 40, padR = 10, padT = 20, padB = 30
  const colors = { ut1: '#F5C842', ut2: '#4ADE80', half_yearly: '#60B5FF', preboard1: '#C084FC', preboard2: '#FB923C', boards: '#FF6B6B' }
  const iw = W - padL - padR, ih = H - padT - padB
  const x = i => padL + (i / (points.length - 1)) * iw
  const series = {}
  for (const p of points) for (const [examId, m] of Object.entries(p.exam)) {
    ;(series[examId] ||= []).push({ x: x(points.indexOf(p)), y: padT + ih - (m.readiness / 100) * ih })
  }
  const yTicks = [0, 25, 50, 75, 100]
  const grid = yTicks.map(v => {
    const y = padT + ih - (v / 100) * ih
    return `<line x1="${padL}" y1="${y}" x2="${W - padR}" y2="${y}" stroke="var(--border)" stroke-dasharray="3 4"/>
      <text x="${padL - 8}" y="${y + 3}" text-anchor="end" font-size="9" fill="var(--dim)">${v}</text>`
  }).join('')
  const lines = Object.entries(series).filter(([, arr]) => arr.length >= 2).map(([id, arr]) => {
    const color = colors[id] || '#60B5FF'
    const name = EXAMS.find(e => e.id === id)?.short || id
    const path = arr.map((p, i) => `${i ? 'L' : 'M'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ')
    const last = arr[arr.length - 1]
    return `<path d="${path}" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" opacity="0.9"/>
      <circle cx="${last.x.toFixed(1)}" cy="${last.y.toFixed(1)}" r="3" fill="${color}"/>
      <text x="${last.x + 6}" y="${last.y + 3}" font-size="9.5" fill="${color}">${name}</text>`
  }).join('')
  const dates = points.map((p, i) => i % Math.ceil(points.length / 5) === 0 ? `<text x="${x(i)}" y="${H - 10}" text-anchor="middle" font-size="9" fill="var(--dim)">${p.tk.slice(5)}</text>` : '').join('')
  return `<div class="card" style="margin-top:20px">
    <div style="font-size:14px;font-weight:500;color:var(--white);margin-bottom:6px">Readiness Trend per Exam</div>
    <div style="font-size:11px;color:var(--dim);margin-bottom:16px">Sampled daily from your ticks — the formula is 55·coverage + 25·revisionDepth + 20·confidence</div>
    <svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto" role="img" aria-label="Readiness trend lines per exam over time">${grid}${lines}${dates}</svg>
  </div>`
}

function mockMarksChart() {
  const series = []
  for (const examId of EXAM_ORDER) {
    const mocks = store.examProgress[examId]?.mocks || []
    if (mocks.length) {
      const name = EXAMS.find(e => e.id === examId)?.short || examId
      series.push({ name, color: mockColor(examId), mocks })
    }
  }
  if (!series.length) return ''
  const W = 900, H = 260, padL = 44, padR = 14, padT = 18, padB = 34
  const iw = W - padL - padR, ih = H - padT - padB
  let maxPct = 100
  const all = series.flatMap(s => s.mocks)
  maxPct = Math.max(100, ...all.map(m => (m.marksObtained / m.marksTotal) * 100))
  const x = i => padL + (i / (Math.max(all.length - 1, 1))) * iw
  const y = v => padT + ih - (v / maxPct) * ih
  const grid = [0, 25, 50, 75, 100].filter(v => v <= maxPct).map(v => {
    const yy = y(v)
    return `<line x1="${padL}" y1="${yy}" x2="${W - padR}" y2="${yy}" stroke="var(--border)" stroke-dasharray="3 4"/><text x="${padL - 8}" y="${yy + 3}" text-anchor="end" font-size="9" fill="var(--dim)">${v}%</text>`
  }).join('')
  let allIdx = 0
  const bodies = series.map(s => {
    const pts = s.mocks.map(m => {
      const pct = (m.marksObtained / Math.max(m.marksTotal, 1)) * 100
      const px = x(allIdx++), py = y(pct)
      return `<circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="4.5" fill="${s.color}">
        <title>${s.name}: ${m.marksObtained}/${m.marksTotal} (${Math.round(pct)}%) · ${m.date || ''}</title></circle>`
    }).join('')
    const avg = s.mocks.reduce((a, m) => a + (m.marksObtained / Math.max(m.marksTotal, 1)), 0) / s.mocks.length * 100
    const avgY = y(avg)
    return `${pts}<line x1="${padL}" y1="${avgY}" x2="${W - padR}" y2="${avgY}" stroke="${s.color}" stroke-dasharray="5 4" opacity="0.5"/>
      <text x="${padL + 4}" y="${avgY - 4}" font-size="9.5" fill="${s.color}">${s.name} avg ${Math.round(avg)}%</text>`
  }).join('')
  const labels = all.map((m, i) => `${i % 2 === 0 ? `<text x="${x(i)}" y="${H - 12}" text-anchor="middle" font-size="8.5" fill="var(--dim)">${m.date || ''}</text>` : ''}`).join('')
  return `<div class="card" style="margin-top:20px">
    <div style="font-size:14px;font-weight:500;color:var(--white);margin-bottom:6px">Mock / Test Marks</div>
    <div style="font-size:11px;color:var(--dim);margin-bottom:16px">Percentage of maximum per attempt, with the average marked per exam</div>
    <svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto" role="img" aria-label="Scatter chart of mock marks as percentages">${grid}${bodies}${labels}</svg>
  </div>`
}
function mockColor(examId) {
  return { ut1: '#F5C842', ut2: '#4ADE80', half_yearly: '#60B5FF', preboard1: '#C084FC', preboard2: '#FB923C', boards: '#FF6B6B' }[examId] || '#60B5FF'
}
function emptyLite(icon, title, sub) {
  return `<div style="text-align:center;padding:36px 16px;color:var(--muted)">
    <div style="font-size:34px;margin-bottom:10px;opacity:.85">${icon}</div>
    <div style="font-size:14px;color:var(--white);font-weight:500;margin-bottom:6px">${title}</div>
    <div style="font-size:12px;line-height:1.6">${sub}</div></div>`
}

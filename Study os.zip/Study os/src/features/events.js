/**
 * features/events.js — Events calendar (filterable), over the v2 EVENTS list
 * which is derived from EXAMS[].papers (no Hindi / Bio / Commerce rows).
 */
import { store } from '../state/store.js'
import { EVENTS } from '../data/sessions.js'
import { daysUntil, fmtFull } from '../lib/time.js'
import { esc } from '../lib/format.js'
import { emptyState } from '../lib/ui.js'

const EVENT_FILTERS = [['all', 'All'], ['exam', 'Exams'], ['holiday', 'Holidays'], ['meeting', 'Meetings'], ['school', 'School']]

function eventColor(t) {
  return { exam: '#FF6B6B', holiday: '#4ADE80', meeting: '#60B5FF', school: '#94A3B8' }[t] || '#94A3B8'
}

export function renderEvents() {
  const f = store.ui.eventFilter
  const list = EVENTS.filter(e => f === 'all' || e.type === f)
  const evHTML = list.map(ev => {
    const days = daysUntil(ev.date), past = days < 0, col = eventColor(ev.type)
    const d = new Date(ev.date + 'T00:00:00')
    const typeLabel = { exam: 'EXAM', holiday: 'HOLIDAY', meeting: 'MEETING', school: 'SCHOOL' }[ev.type]
    return `<div style="background:${past ? 'transparent' : 'var(--card)'};border:1px solid ${past ? 'var(--border)' : (days <= 7 ? col + '40' : 'var(--border)')};border-radius:12px;padding:15px 20px;display:flex;align-items:center;gap:16px;opacity:${past ? 0.42 : 1};margin-bottom:9px;box-shadow:${past ? 'none' : 'var(--shadow-card)'}">
      <div style="background:${col}15;border:1px solid ${col}30;border-radius:10px;padding:10px 14px;text-align:center;min-width:58px">
        <div style="font-size:22px;color:${col};font-weight:700;line-height:1;font-family:var(--font-mono)">${d.getDate()}</div>
        <div style="font-size:10px;color:${col}90;margin-top:2px;letter-spacing:1px">${d.toLocaleString('en-IN', { month: 'short' }).toUpperCase()}</div>
      </div>
      <div style="flex:1">
        <div style="font-size:14px;font-weight:500;color:${past ? 'var(--muted)' : 'var(--white)'}">${esc(ev.label)}</div>
        <div style="font-size:11px;color:var(--dim);margin-top:3px">${fmtFull(ev.date)}</div>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:7px">
        <div class="badge" style="background:${col}18;color:${col}">${typeLabel}</div>
        <div style="font-size:13px;font-family:var(--font-mono);color:${past ? 'var(--dim)' : (days === 0 ? '#F5C842' : (days <= 14 ? '#FF6B6B' : 'var(--muted)'))};font-weight:${past ? 400 : 700}">${past ? `${Math.abs(days)}d ago` : (days === 0 ? 'Today!' : `${days} days`)}</div>
      </div>
    </div>`
  }).join('')
  return `<div class="fadein" style="max-width:780px">
    <div style="background:rgba(255,107,107,.08);border:1px solid rgba(255,107,107,.22);border-radius:14px;padding:20px 26px;margin-bottom:18px;display:flex;align-items:center;gap:24px;flex-wrap:wrap">
      <div style="text-align:center">
        <div style="font-size:44px;font-family:var(--font-mono);color:#FF6B6B;font-weight:700;line-height:1">${Math.max(daysUntil('2027-02-13'), 0)}</div>
        <div style="font-size:11px;color:rgba(255,107,107,.75);margin-top:4px">days left</div>
      </div>
      <div style="flex:1;min-width:220px">
        <div style="font-size:15px;font-weight:600;color:var(--white);margin-bottom:4px">ISC Board Exams — Feb 13, 2027</div>
        <div style="font-size:12px;color:var(--muted);margin-bottom:12px">Make every session count. Stay consistent.</div>
        <div style="background:var(--hover);border-radius:4px;height:5px;overflow:hidden">
          <div style="height:100%;background:linear-gradient(90deg,#FF6B6B80,#FF6B6B);width:${Math.max(0, Math.min(100 - (daysUntil('2027-02-13') / 365 * 100), 100))}%;border-radius:4px"></div>
        </div>
      </div>
    </div>
    <div style="display:flex;gap:8px;margin-bottom:18px;flex-wrap:wrap">
      ${EVENT_FILTERS.map(([k, l]) => `<button data-action="event-filter" data-filter="${k}" class="badge" style="cursor:pointer;padding:6px 14px;font-size:10.5px;background:${f === k ? 'rgba(245,200,66,.16)' : 'var(--card)'};color:${f === k ? 'var(--gold)' : 'var(--muted)'};border:1px solid ${f === k ? 'rgba(245,200,66,.4)' : 'var(--border)'}">${l}</button>`).join('')}
    </div>
    ${list.length ? evHTML : emptyState('📅', 'Nothing here', `No ${f !== 'all' ? f + ' ' : ''}events in this view.`)}
  </div>`
}

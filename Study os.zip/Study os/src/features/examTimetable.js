/**
 * features/examTimetable.js — Exam Timetable tab (v1 "UT Timetable" renamed).
 * Built from EXAMS[].papers. The December and Jan–Feb blocks render as
 * Pre-Board 1 / Pre-Board 2 with a small "printed as UT-3 / UT-4" caption.
 * The absent Pre-Board 1 Physics date renders as "date TBC" with a picker.
 */
import { store, save } from '../state/store.js'
import { EXAMS, EXAM_ORDER } from '../data/exams.js'
import { SUBJECTS, SUBJECT_ORDER } from '../../syllabus-exams.data.js'
import { daysUntil, fmtShort } from '../lib/time.js'
import { esc } from '../lib/format.js'

export function renderExamTimetable() {
  const today = new Date(); today.setHours(0, 0, 0, 0)

  const noteBanner = `<div style="background:rgba(245,200,66,.07);border:1px solid rgba(245,200,66,.2);border-radius:10px;padding:12px 20px;margin-bottom:22px;font-size:12px;color:var(--muted);display:flex;flex-direction:column;gap:4px">
    <div style="color:#F5C842;font-weight:600;font-size:12.5px">📌 Notes</div>
    <div>• Unit Test marks are added to the Half Yearly and Annual Examinations</div>
    <div>• <strong style="color:var(--white)">Unit Test duration: 35 minutes</strong> (pre-boards and boards run full length)</div>
    <div>• The December and Jan–Feb blocks are run as <strong style="color:var(--white)">Pre-Board 1</strong> and <strong style="color:var(--white)">Pre-Board 2</strong> by the school (the wall sheet labels them UT-3 / UT-4)</div>
  </div>`

  const allRows = []
  for (const exam of EXAMS) {
    for (const [sk, date] of Object.entries(exam.papers || {})) {
      if (!date) continue
      const d = new Date(date + 'T00:00:00')
      if (d >= today) allRows.push({ exam, sk, date, d })
    }
  }
  const nextRow = allRows.sort((a, b) => a.d - b.d)[0]

  const nextBanner = nextRow ? `<div style="background:linear-gradient(135deg,rgba(255,107,107,.09),rgba(251,146,60,.09));border:1px solid rgba(255,107,107,.25);border-radius:14px;padding:16px 24px;margin-bottom:22px;display:flex;align-items:center;gap:20px;box-shadow:var(--shadow-card)">
    <div style="text-align:center;min-width:60px">
      <div style="font-size:36px;font-weight:700;color:#FF6B6B;font-family:var(--font-mono);line-height:1">${Math.max(daysUntil(nextRow.date), 0)}</div>
      <div style="font-size:10px;color:rgba(255,107,107,.75);margin-top:3px">${daysUntil(nextRow.date) === 0 ? 'TODAY' : 'days left'}</div>
    </div>
    <div><div style="font-size:13px;color:var(--muted);margin-bottom:2px">${nextRow.exam.short} — Next Paper</div>
      <div style="font-size:16px;font-weight:600;color:var(--white)">${SUBJECTS[nextRow.sk].name}</div>
      <div style="font-size:12px;color:var(--dim);margin-top:2px">${fmtShort(nextRow.date)}</div></div>
  </div>` : ''

  const cards = EXAM_ORDER.map(examId => {
    const exam = EXAMS.find(e => e.id === examId)
    const start = new Date(exam.start + 'T00:00:00')
    const today0 = new Date(); today0.setHours(0, 0, 0, 0)
    const allPast = !exam.papers || Object.values(exam.papers).filter(Boolean).every(d => new Date(d + 'T00:00:00') < today0)
    const someActive = Object.values(exam.papers || {}).filter(Boolean).some(d => new Date(d + 'T00:00:00') >= today0)
    const statusBadge = exam.status === 'completed' ? `<span class="badge" style="background:rgba(74,222,128,.14);color:var(--green)">✓ DONE</span>`
      : someActive ? `<span class="badge" style="background:rgba(245,200,66,.14);color:#F5C842;animation:live 1.5s infinite">● ACTIVE</span>`
      : allPast ? `<span class="badge" style="background:rgba(74,222,128,.14);color:var(--green)">✓ DONE</span>`
      : `<span class="badge" style="background:var(--hover);color:var(--muted)">UPCOMING</span>`

    const rows = SUBJECT_ORDER.map((sk, i) => {
      let date = exam.papers?.[sk] || store.settings.exams.paperDates[examId]?.[sk] || null
      const isTBC = exam.id === 'preboard1' && sk === 'physics' && !date
      const dObj = date ? new Date(date + 'T00:00:00') : null
      const isPast = dObj && dObj < today0
      const isToday = dObj && dObj.toDateString() === today0.toDateString()
      const dDiff = dObj ? Math.ceil((dObj - today0) / 86400000) : null
      const badge = isToday ? `<span class="badge" style="background:rgba(245,200,66,.2);color:#F5C842">TODAY</span>`
        : isPast ? `<span style="font-size:10px;color:var(--dim);font-family:var(--font-mono)">Done</span>`
        : dDiff != null ? `<span style="font-size:10px;color:${exam.color || '#60B5FF'};font-family:var(--font-mono)">${dDiff}d</span>`
        : `<span style="font-size:10px;color:var(--warn);font-family:var(--font-mono)">date TBC</span>`
      const dateCell = isTBC
        ? `<span style="font-size:11px;color:var(--warn)">date TBC</span> <input type="date" value="" data-action="set-paper-date" data-exam="${examId}" data-subject="${sk}" aria-label="Set ${SUBJECTS[sk].name} paper date" style="padding:3px 6px;font-size:11px;width:130px">`
        : `<span style="font-size:11px;color:var(--muted);font-family:var(--font-mono)">${fmtShort(date)}</span>`
      return `<div style="display:flex;align-items:center;gap:14px;padding:11px 18px;border-top:${i > 0 ? '1px solid var(--border)' : 'none'};background:${isToday ? 'rgba(245,200,66,.04)' : 'transparent'};opacity:${isPast ? 0.5 : 1};transition:background .2s">
        <div style="width:34px;font-size:10px;color:var(--dim);flex-shrink:0">${SUBJECTS[sk].icon}</div>
        <div style="flex:1;font-size:13.5px;color:${isPast ? 'var(--dim)' : 'var(--white)'};font-weight:500;text-decoration:${isPast ? 'line-through' : 'none'}">${SUBJECTS[sk].name}</div>
        <div style="min-width:150px;text-align:right">${dateCell}</div>
        ${badge}</div>`
    }).join('')

    const range = exam.end
      ? `${fmtShort(exam.start)} – ${fmtShort(exam.end)}`
      : `${fmtShort(exam.start)} → (end open — set in Settings)`
    return `<div style="background:var(--card);border:1px solid ${someActive ? (exam.color || '#60B5FF') + '35' : 'var(--border)'};border-radius:14px;overflow:hidden;margin-bottom:16px;box-shadow:var(--shadow-card)">
      <div style="padding:16px 18px;background:${(exam.color || '#60B5FF')}08;border-bottom:1px solid ${(exam.color || '#60B5FF')}20;display:flex;align-items:center;justify-content:space-between;gap:10px">
        <div>
          <div style="display:flex;align-items:center;gap:8px">
            <div style="font-size:15px;font-weight:600;color:${exam.color || '#60B5FF'};letter-spacing:.5px">${esc(exam.name)}</div>
            ${exam.printedAs ? `<span style="font-size:10px;color:var(--dim)">(printed as ${exam.printedAs})</span>` : ''}
          </div>
          <div style="font-size:11px;color:var(--dim);margin-top:3px">${range}${exam.kind === 'unit_test' ? ' · 35 min each' : ''}</div>
        </div>
        ${statusBadge}
      </div>
      <div>${rows}</div>
    </div>`
  }).join('')

  return `<div class="fadein" style="max-width:820px">
    <div class="card-label">Class XII · Exam Timetable 2026–27</div>
    <div style="font-size:20px;font-weight:600;color:var(--white);margin-bottom:20px">Exam Timetable</div>
    ${nextBanner}${noteBanner}
    ${cards}
  </div>`
}

export function setPaperDateAction(_, ds) {
  const el = document.querySelector(`[data-action="set-paper-date"][data-exam="${ds.exam}"][data-subject="${ds.subject}"]`)
  const v = el?.value
  if (!v) return
  const paperDates = store.settings.exams.paperDates || (store.settings.exams.paperDates = {})
  paperDates[ds.exam] = paperDates[ds.exam] || {}
  paperDates[ds.exam][ds.subject] = v
  save('settings')
}

/**
 * features/examPrep.js — Exam Prep tab (Phase 2, the core feature).
 *
 * Level 1  exam rail (six cards, UT-1/UT-2 completed+locked)
 * Level 2  selected-exam header: readiness ring, pace, risk list, revision
 *          queue, actions (Study plan / Edit scope / Mark complete)
 * Level 3  subject accordions
 * Level 4  chapter rows
 * Level 5  topic rows (confidence, revise, flag, note, minutes)
 */
import { store, save } from '../state/store.js'
import { EXAMS, EXAM_ORDER, resolveScope, examPaperDate } from '../data/exams.js'
import { syllabus, SUBJECT_ORDER, topicKey, chapterById } from '../data/syllabus.js'
import { SUBJECTS } from '../../syllabus-exams.data.js'
import {
  examMetrics, readinessBand, isExamChecked, toggleExamTick, examState, mastery,
  bumpRevision, clampReviewDate, riskList, revisionQueue, paceInfo, spacedReviewDate,
  taughtChapterIds,
} from '../state/mastery.js'
import { todayKey, daysUntil, fmtShort, countdownLabel } from '../lib/time.js'
import { esc, pct } from '../lib/format.js'
import { ringHTML, toast, openModal, closeModal, confirmDialog } from '../lib/ui.js'
import { renderContentPreserveScroll } from './router.js'

const EXAM_COLORS = { ut1: '#F5C842', ut2: '#4ADE80', half_yearly: '#60B5FF', preboard1: '#C084FC', preboard2: '#FB923C', boards: '#FF6B6B' }

export function renderExamPrep() {
  const selected = store.ui.selectedExam
  const exam = EXAMS.find(e => e.id === selected) || EXAMS[0]
  const metrics = examMetrics(selected)
  const band = readinessBand(metrics.readiness)
  const locked = exam.locked && store.examProgress[selected]?.completedAt
  const isCompleted = exam.status === 'completed' || !!store.examProgress[selected]?.completedAt

  const rail = examRail()
  const header = examHeader(exam, metrics, band)
  const subjects = subjectAccordions(exam, metrics)
  const panels = analysisPanels(exam, metrics)

  return `<div class="fadein">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:16px">
      <div class="card-label" style="margin-bottom:0">Exam Prep</div>
      <div style="font-size:11px;color:var(--dim)">Tick topics to prepare for each exam · mastery feeds every ring</div>
    </div>
    ${rail}
    ${header}
    ${panels}
    ${subjects}
  </div>`
}

// ── Level 1: exam rail ──────────────────────────────────────────────────────
function examRail() {
  const cards = EXAM_ORDER.map(id => {
    const exam = EXAMS.find(e => e.id === id)
    const m = examMetrics(id)
    const band = readinessBand(m.readiness)
    const done = exam.status === 'completed' || !!store.examProgress[id]?.completedAt
    const selected = store.ui.selectedExam === id
    const days = daysUntil(exam.start)
    const color = EXAM_COLORS[id] || '#60B5FF'
    const dots = SUBJECT_ORDER.map(sk => {
      const bs = m.bySubject[sk]
      if (!bs) return ''
      const f = bs.total ? bs.checked / bs.total : 0
      return `<div style="flex:1;height:3px;border-radius:2px;background:${f > 0.99 ? SUBJECTS[sk].color : (f > 0.5 ? SUBJECTS[sk].color + '88' : (f > 0 ? SUBJECTS[sk].color + '44' : 'var(--hover)'))}"></div>`
    }).join('')
    return `<button data-action="exam-select" data-id="${id}" style="flex:0 0 170px;text-align:left;padding:14px 16px;border-radius:16px;border:1px solid ${selected ? color + '66' : 'var(--border)'};background:${selected ? `linear-gradient(180deg,${color}1c,var(--card))` : 'var(--card)'};cursor:pointer;position:relative;overflow:hidden;opacity:${done && !selected ? 0.75 : 1};transition:all .2s">
      ${done ? `<div style="position:absolute;top:10px;right:10px;background:rgba(74,222,128,.16);border:1px solid rgba(74,222,128,.4);color:var(--green);font-size:8px;font-family:var(--font-mono);padding:2px 7px;border-radius:20px;letter-spacing:1px">COMPLETED</div>` : ''}
      <div style="font-size:10px;letter-spacing:2px;color:${color};text-transform:uppercase;font-family:var(--font-mono);margin-bottom:6px">${exam.short}</div>
      <div style="font-size:13px;font-weight:600;color:var(--white);line-height:1.3">${esc(exam.name)}</div>
      ${exam.printedAs ? `<div style="font-size:9px;color:var(--dim);margin-top:2px">printed as ${exam.printedAs}</div>` : ''}
      <div style="font-size:10px;color:var(--muted);margin-top:6px;font-family:var(--font-mono)">${fmtShort(exam.start)} · ${done ? 'done' : countdownLabel(exam.start)}</div>
      <div style="display:flex;align-items:center;gap:10px;margin-top:12px">
        ${ringHTML(m.readiness / 100, band.color, 40, 4, `<div style="font-size:11px;font-weight:700;color:${band.color};font-family:var(--font-mono)">${m.readiness}</div>`)}
        <div style="flex:1;display:flex;gap:3px">${dots}</div>
      </div>
      <div style="font-size:9.5px;color:${band.color};margin-top:8px">${band.label} · ${m.checked}/${m.total}</div>
    </button>`
  }).join('')
  return `<div style="display:flex;gap:10px;overflow-x:auto;padding:4px 2px 12px;margin-bottom:18px;scrollbar-width:thin">${cards}</div>`
}

// ── Level 2: exam header ────────────────────────────────────────────────────
function examHeader(exam, m, band) {
  const locked = exam.locked && store.examProgress[exam.id]?.completedAt
  const days = daysUntil(exam.start)
  const daysLabel = days < 0 ? `ended ${Math.abs(days)}d ago` : (days === 0 ? 'today' : `${days} days left`)
  const progressBar = SUBJECT_ORDER.map(sk => {
    const bs = m.bySubject[sk]
    if (!bs || !bs.total) return ''
    return `<div style="flex:1;min-width:60px">
      <div style="display:flex;justify-content:space-between;font-size:9.5px;margin-bottom:4px">
        <span style="color:${SUBJECTS[sk].color}">${SUBJECTS[sk].short}</span>
        <span style="color:var(--dim);font-family:var(--font-mono)">${pct(bs.checked, bs.total)}%</span>
      </div>
      <div style="background:var(--hover);border-radius:3px;height:5px;overflow:hidden"><div style="height:100%;width:${pct(bs.checked, bs.total)}%;background:${SUBJECTS[sk].color};border-radius:3px;transition:width .3s"></div></div>
    </div>`
  }).join('')

  const title = exam.locked && !store.examProgress[exam.id]?.completedAt ? exam.name : exam.name

  return `<div class="card" style="margin-bottom:18px;position:relative;overflow:hidden">
    <div style="position:absolute;inset:0;background:radial-gradient(ellipse at 0% 0%,${EXAM_COLORS[exam.id] || '#60B5FF'}14,transparent 60%);pointer-events:none"></div>
    <div style="display:flex;gap:22px;flex-wrap:wrap;position:relative">
      ${ringHTML(m.readiness / 100, band.color, 108, 9, `
        <div><div style="font-size:26px;font-weight:700;color:${band.color};font-family:var(--font-mono);line-height:1">${m.readiness}</div>
        <div style="font-size:9px;color:var(--dim);margin-top:3px;letter-spacing:1px">READY</div></div>`)}
      <div style="flex:1;min-width:260px">
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <div style="font-size:20px;font-weight:600;color:var(--white)">${esc(title)}</div>
          ${exam.printedAs ? `<span class="chip" style="color:var(--dim)">printed as ${exam.printedAs}</span>` : ''}
          ${exam.locked && store.examProgress[exam.id]?.completedAt ? `<span class="chip" style="background:rgba(74,222,128,.14);color:var(--green)">✓ completed</span>` : ''}
          ${exam.dateStatus === 'estimated' ? `<span class="chip" style="background:rgba(245,200,66,.14);color:var(--warn)" title="Date not confirmed on the sheet">date not confirmed</span>` : ''}
          ${exam.allowTaughtOnlyToggle ? `<span class="chip" style="background:rgba(139,92,246,.14);color:#C084FC" title="Pre-Board 1 can be limited to taught chapters">limit-to-taught available</span>` : ''}
        </div>
        <div style="font-size:12px;color:var(--muted);margin-top:6px">
          ${fmtShort(exam.start)}${exam.end ? ` – ${fmtShort(exam.end)}` : ' (end open)'} · <strong style="color:${band.color}">${daysLabel}</strong> · ${m.checked} of ${m.total} topics ready
          ${exam.note ? `<div style="font-size:11px;color:var(--dim);margin-top:6px;line-height:1.5">${esc(exam.note)}</div>` : ''}
        </div>
        <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap">
          <button class="btn" data-action="exam-plan" data-id="${exam.id}" style="background:${EXAM_COLORS[exam.id]}1a;border:1px solid ${EXAM_COLORS[exam.id]}45;color:${EXAM_COLORS[exam.id]}">📅 Study plan</button>
          <button class="btn btn-ghost" data-action="exam-edit-scope" data-id="${exam.id}" style="padding:9px 14px;font-size:11px">Edit scope</button>
          ${!store.examProgress[exam.id]?.completedAt ? `<button class="btn btn-ghost" data-action="exam-complete" data-id="${exam.id}" style="padding:9px 14px;font-size:11px">Mark exam complete</button>` : ''}
          ${exam.locked && store.examProgress[exam.id]?.completedAt ? `<button class="btn btn-ghost" data-action="exam-unlock" data-id="${exam.id}" style="padding:9px 14px;font-size:11px;color:var(--warn)">Unlock to edit</button>` : ''}
        </div>
        ${exam.allowTaughtOnlyToggle ? `<div style="margin-top:12px;display:flex;align-items:center;gap:10px">
          <input type="checkbox" id="pb1-taught" ${taughtOnlyOn(exam.id) ? 'checked' : ''} data-action="exam-taught-toggle" data-id="${exam.id}" style="width:16px;height:16px;accent-color:#8B5CF6">
          <label for="pb1-taught" style="font-size:12px;color:var(--muted)">Limit to what is taught (intersect with school-taught chapters)</label>
        </div>` : ''}
        <div style="display:flex;gap:10px;margin-top:16px;flex-wrap:wrap">${progressBar}</div>
      </div>
    </div>
  </div>`
}

function taughtOnlyOn(examId) {
  const ep = store.examProgress[examId]
  return !!(ep && ep.taughtOnly)
}

// ── Analysis panels: pace, risk, revision queue ────────────────────────────
function analysisPanels(exam, m) {
  const pace = paceInfo(exam.id, m)
  const risk = riskList(exam.id, 8)
  const queue = revisionQueue()
  const inScopeQueue = queue.list.filter(q => m.scope.inScope.has(q.key.split('|')[1]))
  const paceHTML = pace ? `
    <div class="card" style="flex:1;min-width:220px">
      <div class="card-label">Pace</div>
      <div style="font-size:13px;color:var(--white);line-height:1.7">
        You need <strong style="color:${pace.onTrack ? 'var(--green)' : 'var(--warn)'}">${pace.needPerDay.toFixed(1)}/day</strong> to finish before the exam.
        You're doing <strong style="color:${pace.onTrack ? 'var(--green)' : 'var(--warn)'}">${pace.doingPerDay.toFixed(1)}/day</strong>.
      </div>
      <div style="font-size:11px;color:var(--muted);margin-top:6px">${pace.remaining} topics left · ${pace.daysLeft} days</div>
    </div>` : ''
  const riskHTML = `
    <div class="card" style="flex:1.4;min-width:280px">
      <div class="card-label">Top Risks</div>
      ${risk.length ? risk.map(r => `
        <div style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--border)">
          <span style="width:6px;height:6px;border-radius:50%;background:${r.mastery.flagged ? '#FF6B6B' : 'var(--warn)'};flex-shrink:0"></span>
          <div style="flex:1;min-width:0">
            <div style="font-size:12px;color:var(--white);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(r.topic.title)}</div>
            <div style="font-size:10px;color:var(--dim)">${SUBJECTS[r.subjectKey].short} · ${esc(r.chapter.name)}</div>
          </div>
          <span style="font-size:9.5px;color:var(--muted);font-family:var(--font-mono);flex-shrink:0">${r.reason}</span>
        </div>`).join('') : `<div style="font-size:12px;color:var(--dim)">No at-risk topics in scope — great.</div>`}
    </div>`
  const queueHTML = `
    <div class="card" style="flex:1.4;min-width:280px">
      <div class="card-label">Revision Queue (due today)</div>
      ${inScopeQueue.length ? inScopeQueue.slice(0, 8).map(q => `
        <div style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--border)">
          <span style="font-size:10px;color:#C084FC;flex-shrink:0">R${q.rec.revisions + 1}</span>
          <div style="flex:1;min-width:0">
            <div style="font-size:12px;color:var(--white);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(q.title)}</div>
            <div style="font-size:10px;color:var(--dim)">${SUBJECTS[q.subjectKey].short} · ${esc(q.chapter.name)}</div>
          </div>
        </div>`).join('') : '<div style="font-size:12px;color:var(--dim)">Nothing due — spaced repetition is up to date.</div>'}
      ${inScopeQueue.length ? `<button class="btn" data-action="focus-lab-revision" style="margin-top:12px;padding:7px 14px;font-size:11px;background:rgba(139,92,246,.15);border:1px solid rgba(139,92,246,.4);color:#C084FC">Start 30-min revision</button>` : ''}
    </div>`
  return `<div style="display:flex;gap:14px;margin-bottom:18px;flex-wrap:wrap">${paceHTML}${riskHTML}${queueHTML}</div>`
}

// ── Level 3-5: subject accordions ───────────────────────────────────────────
function subjectAccordions(exam, metrics) {
  return SUBJECT_ORDER.map(sk => {
    const subj = SUBJECTS[sk]
    const chs = syllabus()[sk]
    const scopeChapters = metrics.scope.subjects[sk]?.chapters || []
    const inScopeIds = new Set(scopeChapters)
    const bs = metrics.bySubject[sk] || { total: 0, checked: 0, chapters: 0, chapterDone: 0 }
    const pctDone = pct(bs.checked, bs.total)
    const isOpen = store.ui.examOpenSubject === sk
    const paperDate = examPaperDate(exam, sk) || store.settings.exams.paperDates[exam.id]?.[sk]

    const chapterRows = chs.map(ch => {
      const inScope = inScopeIds.has(ch.id)
      const showOut = !!store.ui.examShowAll
      if (!inScope && !showOut) return ''
      const chDone = ch.topics.filter(t => isExamChecked(exam.id, topicKey(sk, ch.id, t.id))).length
      const allDone = chDone === ch.topics.length && ch.topics.length > 0
      const partial = chDone > 0 && !allDone
      const recCounts = ch.topics.map(t => store.mastery[topicKey(sk, ch.id, t.id)]).filter(Boolean)
      const maxRev = recCounts.reduce((a, r) => Math.max(a, r.revisions || 0), 0)
      const taught = recCounts.some(r => r.school)
      const open = !!store.ui.openChapters[`ep:${exam.id}:${ch.id}`]
      const topicsHTML = ch.topics.map((tp, ti) => {
        const key = topicKey(sk, ch.id, tp.id)
        const done = isExamChecked(exam.id, key)
        const rec = store.mastery[key]
        const conf = rec?.confidence || 0
        return topicRowHTML(exam.id, sk, ch, tp, key, done, rec, conf, inScope)
      }).join('')
      return `<div class="ep-chapter" data-chapter="${ch.id}" style="opacity:${inScope ? 1 : 0.45}">
        <div class="ep-chapter-head" data-action="exam-toggle-chapter" data-exam="${exam.id}" data-chid="${ch.id}" role="button" aria-expanded="${open}" aria-controls="ep-topics-${ch.id}">
          <span style="transform:rotate(${open ? 90 : 0}deg);transition:transform .15s;color:${isOpen ? subj.color : 'var(--muted)'}">▸</span>
          <div class="chapter-check ${allDone ? 'done' : (partial ? 'partial' : '')}" data-action="exam-chapter-all" data-exam="${exam.id}" data-chid="${ch.id}" role="checkbox" aria-checked="${allDone ? 'true' : (partial ? 'mixed' : 'false')}" tabindex="0">${allDone ? '<span style="font-size:10px;color:var(--green)">✓</span>' : (partial ? '<span style="font-size:8px;color:#F5C842">▪</span>' : '')}</div>
          <span style="font-size:11px;color:var(--dim);font-family:var(--font-mono);flex-shrink:0">${ch.no ? `Ch ${ch.no}` : '▪'}</span>
          <span style="flex:1;font-size:13px;color:${allDone ? 'var(--green)' : (partial ? subj.color : 'var(--text)' )}">${esc(ch.name)}</span>
          ${recCounts.some(r => r.flagged) ? '<span title="Has flagged topics" style="font-size:11px">🚩</span>' : ''}
          ${!inScope ? '<span class="chip" style="color:var(--dim)">out of scope</span>' : ''}
          ${maxRev > 0 ? `<span class="chip" style="color:#C084FC">R${maxRev}</span>` : ''}
          <span class="progress-chip" style="color:${allDone ? 'var(--green)' : (partial ? subj.color : 'var(--dim)')}">${chDone}/${ch.topics.length}</span>
        </div>
        <div class="ep-topics" id="ep-topics-${ch.id}" style="display:${open ? 'block' : 'none'}">${topicsHTML}</div>
      </div>`
    }).join('')

    return `<div class="ep-subject" style="border:1px solid ${subj.color}28;border-radius:14px;overflow:hidden;margin-bottom:14px;background:var(--card)">
      <div class="ep-subject-head" data-action="exam-toggle-subject" data-sk="${sk}" role="button" aria-expanded="${isOpen}">
        <div style="display:flex;align-items:center;gap:12px">
          <span style="width:34px;height:34px;border-radius:10px;background:${subj.color}14;border:1px solid ${subj.color}30;display:flex;align-items:center;justify-content:center;font-size:13px;color:${subj.color}">${subj.icon}</span>
          <div>
            <div style="font-size:14px;font-weight:600;color:${subj.color}">${subj.name}</div>
            <div style="font-size:10.5px;color:var(--dim);margin-top:2px">${bs.chapters} chapters in scope · ${bs.total} topics</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:16px">
          ${paperDate ? `<div style="text-align:right"><div style="font-size:12px;color:${subj.color};font-family:var(--font-mono)">${fmtShort(paperDate)}</div><div style="font-size:9px;color:var(--dim)">paper</div></div>` : ''}
          <div style="text-align:right">
            <div style="font-size:17px;font-weight:600;color:${pctDone === 100 ? 'var(--green)' : subj.color};font-family:var(--font-mono)">${pctDone}%</div>
            <div style="font-size:10.5px;color:var(--muted)">${bs.checked}/${bs.total}</div>
          </div>
          ${ringHTML(bs.total ? bs.checked / bs.total : 0, subj.color, 46, 5, `<div style="font-size:10px;color:var(--white);font-weight:600">${pctDone}%</div>`)}
        </div>
      </div>
      <div class="ep-subject-body" style="display:${isOpen ? 'block' : 'none'}">
        <div style="display:flex;gap:8px;padding:10px 14px;border-bottom:1px solid var(--border);flex-wrap:wrap;align-items:center">
          <span class="chip" style="color:var(--dim)">${bs.chapterDone}/${bs.chapters} chapters complete</span>
          <button class="chip" style="cursor:pointer;color:var(--muted);background:var(--hover)" data-action="exam-toggle-out" data-sk="${sk}">${store.ui.examShowAll ? 'hide out-of-scope' : 'show out-of-scope'}</button>
        </div>
        ${chapterRows}
      </div>
    </div>`
  }).join('')
}

// ── Level 5: topic row ─────────────────────────────────────────────────────
function topicRowHTML(examId, sk, ch, tp, key, done, rec, conf, inScope) {
  const minutes = rec?.minutes || 0
  const dots = [1, 2, 3, 4, 5].map(d => `
    <span role="checkbox" aria-checked="${conf >= d}" tabindex="0" data-action="exam-confidence" data-key="${key}" data-level="${d}"
      style="width:11px;height:11px;border-radius:50%;cursor:pointer;background:${conf >= d ? '#F5C842' : 'var(--hover)'};border:1px solid ${conf >= d ? '#F5C84288' : 'var(--border)'}"></span>`).join('')
  return `<div class="ep-topic" data-topic-key="${key}" data-exam="${examId}"
    style="display:flex;align-items:center;gap:9px;padding:7px 14px 7px 48px;border-bottom:1px solid var(--border);font-size:12.5px;color:${done ? 'var(--dim)' : 'var(--muted)'}">
    <div class="topic-check ${done ? 'done' : ''}" data-action="exam-tick" data-exam="${examId}" data-key="${key}" role="checkbox" aria-checked="${done}" tabindex="0" title="Mark prepared for this exam">${done ? '<span style="font-size:10px;color:var(--green)">✓</span>' : ''}</div>
    <span style="flex:1;text-decoration:${done ? 'line-through' : 'none'}">${esc(tp.title)}</span>
    ${!inScope ? '<span class="chip" style="color:var(--dim);font-size:8.5px">out</span>' : ''}
    ${minutes > 0 ? `<span style="font-size:10px;color:var(--dim);font-family:var(--font-mono)" title="Study minutes">⏱ ${Math.round(minutes)}m</span>` : ''}
    ${rec?.note ? `<span style="font-size:11px" title="${esc(rec.note.slice(0, 60))}">📝</span>` : ''}
    ${rec?.flagged ? `<button data-action="exam-flag" data-key="${key}" title="Unflag" style="background:none;border:none;font-size:12px;cursor:pointer;color:#FF6B6B">🚩</button>` : `<button data-action="exam-flag" data-key="${key}" title="Flag as weak" style="background:none;border:none;font-size:12px;cursor:pointer;opacity:.35">🚩</button>`}
    <button class="btn" data-action="exam-revise" data-key="${key}" title="Mark revised" style="padding:3px 9px;font-size:9.5px;font-family:var(--font-mono);background:rgba(192,132,252,.12);border:1px solid rgba(192,132,252,.3);color:#C084FC">+REVISE</button>
    <span style="display:flex;gap:3px" title="Confidence (1-5)">${dots}</span>
  </div>`
}

// ── actions ─────────────────────────────────────────────────────────────────
export function selectExam(_, ds) {
  store.ui.selectedExam = ds.id
  renderContentPreserveScroll()
}

export function toggleExamSubject(_, ds) {
  store.ui.examOpenSubject = store.ui.examOpenSubject === ds.sk ? null : ds.sk
  renderContentPreserveScroll()
}
export function toggleExamChapter(_, ds) {
  const k = `ep:${ds.exam}:${ds.chid}`
  store.ui.openChapters[k] = !store.ui.openChapters[k]
  renderContentPreserveScroll()
}
export function toggleOutOfScope(_, ds) {
  store.ui.examShowAll = !store.ui.examShowAll
  renderContentPreserveScroll()
}

export function examTick(_, ds) {
  toggleExamTick(ds.exam, ds.key)
  renderContentPreserveScroll()
}

export function examChapterAll(_, ds) {
  const found = chapterById().get(ds.chid)
  if (!found) return
  const { subjectKey: sk, chapter: ch } = found
  const keys = ch.topics.map(t => topicKey(sk, ch.id, t.id))
  const ep = examState(ds.exam)
  const allDone = keys.every(k => isExamChecked(ds.exam, k))
  for (const k of keys) {
    if (allDone) delete ep.checked[k]
    else ep.checked[k] = true
  }
  save('examProgress')
  renderContentPreserveScroll()
}

export function examConfidence(_, ds) {
  const rec = mastery(ds.key)
  const target = +ds.level
  rec.confidence = rec.confidence === target ? 0 : target
  save('mastery')
  renderContentPreserveScroll()
}

export function examRevise(_, ds) {
  bumpRevision(ds.key)
  const rec = store.mastery[ds.key]
  renderContentPreserveScroll()
  toast('🔄', `Revised · next review ${rec.nextReviewAt}`, { ttl: 1600 })
}

export function examFlag(_, ds) {
  const rec = mastery(ds.key)
  rec.flagged = !rec.flagged
  save('mastery')
  renderContentPreserveScroll()
}

export function examComplete(_, ds) {
  const exam = EXAMS.find(e => e.id === ds.id)
  confirmDialog({
    title: `Mark ${exam.short} complete?`,
    message: 'This locks the exam as finished. You can unlock it again later.',
    confirmLabel: 'Complete',
    onConfirm() {
      const ep = examState(ds.id)
      ep.completedAt = new Date().toISOString()
      store.settings.exams.status[ds.id] = 'completed'
      save('examProgress'); save('settings')
      renderContentPreserveScroll()
      toast('🎉', `${exam.short} marked complete`)
    },
  })
}

export function examUnlock(_, ds) {
  const ep = examState(ds.id)
  confirmDialog({
    title: 'Unlock to edit?',
    message: 'This opens UT-1/UT-2 for editing. Your existing ticks stay, but the completed ribbon is removed.',
    confirmLabel: 'Unlock',
    danger: true,
    onConfirm() {
      ep.completedAt = null
      store.settings.exams.status[ds.id] = 'active'
      save('examProgress'); save('settings')
      renderContentPreserveScroll()
      toast('🔓', 'Unlocked — you can now edit')
    },
  })
}

export function examTaughtToggle(_, ds) {
  const ep = examState(ds.id)
  ep.taughtOnly = !!ep.taughtOnly ? false : true
  if (ep.taughtOnly) {
    // intersect scope with taught chapters, saved as a scope override
    const taught = taughtChapterIds()
    const scope = resolveScope(ds.id, { sectionC: store.settings.exams.sectionC })
    const override = {}
    for (const sk of SUBJECT_ORDER) {
      const keep = (scope.subjects[sk]?.chapters || []).filter(id => taught.has(id))
      if (keep.length) override[sk] = keep
    }
    ep.scopeOverride = override
    toast('🎯', 'Scope limited to taught chapters')
  } else {
    ep.scopeOverride = null
    toast('↩', 'Scope restored to full')
  }
  save('examProgress')
  renderContentPreserveScroll()
}

// ── Edit scope modal ────────────────────────────────────────────────────────
export function examEditScope(_, ds) {
  const examId = ds.id
  const scope = resolveScope(examId, { sectionC: store.settings.exams.sectionC })
  const current = scope.subjects
  const html = SUBJECT_ORDER.map(sk => {
    const subj = SUBJECTS[sk]
    const rows = syllabus()[sk].map(ch => {
      const inNow = (current[sk]?.chapters || []).includes(ch.id)
      return `<label style="display:flex;align-items:center;gap:10px;padding:7px 10px;border:1px solid var(--border);border-radius:9px;margin-bottom:6px;cursor:pointer;font-size:12.5px;color:var(--text)">
        <input type="checkbox" data-scope-sk="${sk}" data-scope-chid="${ch.id}" ${inNow ? 'checked' : ''} style="accent-color:${subj.color};width:15px;height:15px">
        ${ch.no ? `<span style="font-size:10px;color:var(--dim);font-family:var(--font-mono)">${ch.no}</span>` : ''}
        <span style="flex:1">${esc(ch.name)}</span>
        <span style="font-size:10px;color:var(--dim);font-family:var(--font-mono)">${ch.topics.length} topics</span>
      </label>`
    }).join('')
    return `<div style="margin-bottom:14px"><div style="font-size:11px;color:${subj.color};font-weight:600;margin-bottom:8px">${subj.name}</div>${rows}</div>`
  }).join('')
  openModal(`
    <div class="modal-head"><h2>Edit scope — ${esc(EXAMS.find(e => e.id === examId).name)}</h2><button class="icon-btn modal-x" data-action="modal-close" aria-label="Close">✕</button></div>
    <div class="modal-body">${html}
      <div style="display:flex;gap:10px;margin-top:16px;justify-content:flex-end">
        <button class="btn btn-ghost" data-action="modal-close">Cancel</button>
        <button class="btn" data-action="scope-save" data-exam="${examId}" style="background:rgba(139,92,246,.18);border:1px solid rgba(139,92,246,.4);color:#C084FC">Save scope</button>
      </div>
    </div>`, { width: 560 })
}

export function scopeSave(_, ds) {
  const examId = ds.exam
  const override = {}
  document.querySelectorAll('[data-scope-sk]').forEach(cb => {
    if (cb.checked) {
      const sk = cb.dataset.scopeSk, chid = cb.dataset.scopeChid
      ;(override[sk] ||= []).push(chid)
    }
  })
  const ep = examState(examId)
  ep.scopeOverride = override
  save('examProgress')
  closeModal()
  renderContentPreserveScroll()
  toast('✓', 'Scope saved')
}

// ── Study plan generator ────────────────────────────────────────────────────
export function generatePlan(_, ds) {
  const examId = ds.id
  const exam = EXAMS.find(e => e.id === examId)
  const m = examMetrics(examId)
  const deadline = exam.end || exam.start
  const today = todayKey()
  const days = Math.max(daysUntil(deadline), 1)
  if (days <= 3) { toast('⚠', 'Too close to the exam — revise instead'); return }

  const remaining = []
  for (const sk of SUBJECT_ORDER) {
    for (const chId of (m.scope.subjects[sk]?.chapters || [])) {
      const ch = chapterById().get(chId)?.chapter
      if (!ch) continue
      for (const t of ch.topics) {
        const key = topicKey(sk, chId, t.id)
        if (!isExamChecked(examId, key)) remaining.push({ sk, ch, t, key })
      }
    }
  }
  if (!remaining.length) { toast('✅', 'Everything in scope is already covered'); return }

  // revision queue first (spaced repetition)
  const queue = revisionQueue().list.filter(q => m.scope.inScope.has(q.key.split('|')[1]))
  const queuedKeys = new Set(queue.map(q => q.key))
  const planTopics = [...remaining.filter(r => queuedKeys.has(r.key)), ...remaining.filter(r => !queuedKeys.has(r.key))]

  // weights by subject remaining volume
  const weights = {}
  for (const r of planTopics) weights[r.sk] = (weights[r.sk] || 0) + 1
  const totalW = Object.values(weights).reduce((a, b) => a + b, 0)
  const slotOrder = ['maths', 'physics', 'chemistry'] // SESSIONS blocks: M 4-6, P 6:15-8:15, C 8:30-10:30

  const plan = []
  let idx = 0
  // study days: all but the last 3 (revision only)
  for (let d = 0; d < days - 3; d++) {
    const date = addDays(today, d)
    if (date > deadline) break
    // pick up to 3 topics weighted by subject, no two same subject per day
    const todayTopics = []
    const usedSubj = new Set()
    for (let slot = 0; slot < 3 && idx < planTopics.length; slot++) {
      const slotSubj = slotOrder[slot % 3]
      let pick = null
      // try to find one of the slot subject if not used
      for (let tries = 0; tries < 20 && idx < planTopics.length; tries++) {
        const candidate = planTopics[idx % planTopics.length]
        if (!candidate) break
        idx++
        if (usedSubj.has(candidate.sk)) { idx = (idx - 1 + planTopics.length) % planTopics.length; continue }
        pick = candidate
        break
      }
      if (!pick) break
      usedSubj.add(pick.sk)
      todayTopics.push(pick)
    }
    for (const t of todayTopics) {
      plan.push({ date, key: t.key, subject: SUBJECTS[t.sk].short, title: t.title, done: false })
    }
  }
  // revision-only tail: pull from queue first, then remaining
  const revisionTail = []
  for (let d = Math.max(days - 3, 0); d < days; d++) {
    const date = addDays(today, d)
    if (date > deadline) break
    const revItem = planTopics[idx % planTopics.length]
    if (revItem) {
      idx++
      revisionTail.push({ date, key: revItem.key, subject: 'Revise', title: `Revision: ${revItem.title}`, done: false })
    }
  }
  store.plan = [...plan, ...revisionTail]
  save('plan')
  toast('📅', `Plan generated for ${days} days (${plan.length + revisionTail.length} items)`)
  renderContentPreserveScroll()
}
function addDays(dateStr, n) {
  const d = new Date(dateStr + 'T00:00:00')
  d.setDate(d.getDate() + n)
  return todayKey(d)
}

// ── mocks ───────────────────────────────────────────────────────────────────
export function examAddMock(examId) {
  const subjects = SUBJECT_ORDER.map(sk => `<option value="${sk}">${SUBJECTS[sk].name}</option>`).join('')
  openModal(`
    <div class="modal-head"><h2>Add mock / test score</h2><button class="icon-btn modal-x" data-action="modal-close" aria-label="Close">✕</button></div>
    <div class="modal-body">
      <div style="display:flex;flex-direction:column;gap:10px">
        <select id="mock-subject" style="width:100%">${subjects}</select>
        <div style="display:flex;gap:10px">
          <input type="date" id="mock-date" value="${todayKey()}" style="flex:1">
          <input type="number" id="mock-obtained" placeholder="Marks obtained" min="0" style="flex:1">
          <input type="number" id="mock-total" placeholder="Out of" min="1" style="flex:1">
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:8px">
          <button class="btn btn-ghost" data-action="modal-close">Cancel</button>
          <button class="btn" data-action="mock-save" data-exam="${examId}">Save</button>
        </div>
      </div>
    </div>`, { width: 480 })
}

export function mockSave(_, ds) {
  const ep = examState(ds.exam)
  ep.mocks.push({
    id: Date.now(),
    subject: document.getElementById('mock-subject').value,
    date: document.getElementById('mock-date').value || todayKey(),
    marksObtained: +document.getElementById('mock-obtained').value || 0,
    marksTotal: +document.getElementById('mock-total').value || 1,
  })
  save('examProgress')
  closeModal()
  renderContentPreserveScroll()
  toast('✓', 'Score saved')
}

// ── mark for all exams ─────────────────────────────────────────────────────
export function markForAllExams(key) {
  const m = mastery(key)
  m.status = 'mastered'
  save('mastery')
  for (const id of EXAM_ORDER) {
    const ep = examState(id)
    ep.checked[key] = true
  }
  save('examProgress')
  renderContentPreserveScroll()
  toast('⭐', 'Marked for all exams & mastery set to mastered')
}

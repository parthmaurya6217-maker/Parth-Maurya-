/**
 * features/nav.js — tab registry, nav rendering, command palette,
 * global keyboard shortcuts. Registered once by main.js.
 */
import { store, setTab, currentStreak, toggleSession, sessionDoneToday, addTask } from '../state/store.js'
import { syllabus, SUBJECT_ORDER, totals } from '../data/syllabus.js'
import { SUBJECTS } from '../../syllabus-exams.data.js'
import { EXAMS } from '../data/exams.js'
import { fuzzyMatch, highlightMatch } from '../lib/fuzzy.js'
import { esc } from '../lib/format.js'
import { openModal, closeModal, confirmDialog, toast, isModalOpen } from '../lib/ui.js'
import { openSettings } from '../features/settings/settings.js'
import { renderContent, renderContentPreserveScroll } from './router.js'

export const TABS = [
  { tab: 'dashboard', label: 'Dashboard', icon: '◉' },
  { tab: 'examPrep', label: 'Exam Prep', icon: '🎯' },
  { tab: 'schedule', label: 'Schedule', icon: '◷' },
  { tab: 'checklist', label: 'Syllabus', icon: '☑' },
  { tab: 'focusLab', label: 'Focus Lab', icon: '⏱' },
  { tab: 'stats', label: 'Analytics', icon: '📊' },
  { tab: 'events', label: 'Events', icon: '📅' },
  { tab: 'tasks', label: 'Tasks', icon: '✓' },
  { tab: 'examTimetable', label: 'Exam Timetable', icon: '📋' },
  { tab: 'aichat', label: 'AI Tutor', icon: '✦' },
  { tab: 'settings', label: 'Settings', icon: '⚙' },
]

export function buildNav() {
  const tabsEl = document.getElementById('tabs')
  const mobileEl = document.getElementById('mobile-nav-inner')
  tabsEl.innerHTML = TABS.map(t =>
    `<button class="tab-btn" data-tab="${t.tab}" role="tab" aria-selected="${store.ui.tab === t.tab}" data-action="nav-tab" data-tabid="${t.tab}"><span aria-hidden="true">${t.icon}</span> ${t.label}</button>`).join('')
  mobileEl.innerHTML = TABS.map(t =>
    `<button class="${store.ui.tab === t.tab ? 'active' : ''}" data-action="nav-tab" data-tabid="${t.tab}" aria-label="${t.label}"><span class="mi" aria-hidden="true">${t.icon}</span>${t.label}</button>`).join('')
}

export function activateTab(id) {
  document.querySelectorAll('.tab-btn').forEach(b => {
    const a = b.dataset.tab === id
    b.classList.toggle('active', a)
    b.setAttribute('aria-selected', a)
  })
  document.querySelectorAll('#mobile-nav button').forEach(b => b.classList.remove('active'))
}

export function switchTab(tab) {
  if (!TABS.some(t => t.tab === tab)) return
  setTab(tab)
  activateTab(tab)
  renderContent()
  window.scrollTo({ top: 0 })
}

export function jumpToTopic(subjectKey, chapterId, topicId) {
  switchTab('checklist')
  store.ui.activeChecklist = 'my'
  store.ui.openChapters[`${subjectKey}:${chapterId}`] = true
  store.ui.openChapters[`subject_${subjectKey}`] = true
  store.ui.jumpTarget = { subjectKey, chapterId, topicId, t: Date.now() }
  renderContent()
  requestAnimationFrame(() => {
    const el = document.querySelector(`[data-topic-key="${subjectKey}|${chapterId}|${topicId}"]`)
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' })
      const chk = el.querySelector('.topic-check')
      if (chk) { chk.classList.add('checkpop'); setTimeout(() => chk.classList.remove('checkpop'), 300) }
    } else toast('⚠', 'Could not scroll to topic')
  })
}

// ── Command palette ─────────────────────────────────────────────────────────
let cmdkItems = [], cmdkFiltered = [], cmdkSel = 0, cmdkOpen = false

function buildCmdKItems() {
  const items = []
  TABS.forEach(t => items.push({ group: 'Navigate', icon: t.icon, label: t.label, run: () => switchTab(t.tab) }))
  items.push(
    { group: 'Actions', icon: '🌓', label: 'Cycle theme', run: cycleThemeAction },
    { group: 'Actions', icon: '⚙', label: 'Open settings', run: openSettings },
    { group: 'Actions', icon: '⬇', label: 'Export backup (.json)', run: exportDataAction },
    { group: 'Actions', icon: '⏱', label: 'Focus Lab — Pomodoro', run: () => switchTab('focusLab') },
    { group: 'Actions', icon: '🧹', label: 'Clear finished tasks', run: clearDoneTasksAction },
  )
  for (const s of [0, 2, 4, 6]) {
    items.push({
      group: 'Sessions', icon: '◷', label: (sessionDoneToday(s) ? '↩ Unmark ' : '✓ Mark done ') + ['Mathematics', 'Physics', 'Chemistry', 'Revision'][s],
      run: () => { toggleSession(s); renderContent(); toast(sessionDoneToday(s) ? '✓' : '↩', 'Session toggled') },
    })
  }
  // Topic jump — index every syllabus topic once
  for (const sk of SUBJECT_ORDER) {
    const subj = SUBJECTS[sk]
    for (const ch of syllabus()[sk]) {
      for (const tp of ch.topics) {
        items.push({
          group: 'Topics', icon: subj.icon || '📘', label: tp.title, sub: `${subj.name} · ${ch.name}`,
          run: () => jumpToTopic(sk, ch.id, tp.id),
        })
      }
    }
  }
  // Exam quick-switch
  for (const ex of EXAMS) {
    items.push({ group: 'Exams', icon: '📅', label: `Open Exam Prep — ${ex.short}`, run: () => { store.ui.selectedExam = ex.id; switchTab('examPrep') } })
  }
  return items
}

export function openCmdK() {
  cmdkOpen = true
  cmdkItems = buildCmdKItems()
  const scrim = document.createElement('div')
  scrim.id = 'cmdk-scrim'
  scrim.innerHTML = `<div id="cmdk" role="dialog" aria-modal="true" aria-label="Command palette">
    <div id="cmdk-input-wrap"><span style="font-size:15px;color:var(--dim)">⌕</span>
      <input id="cmdk-input" placeholder="Search actions, tabs, topics, exams…" autocomplete="off" spellcheck="false">
      <span class="cmdk-kbd">ESC</span></div>
    <div id="cmdk-list" role="listbox"></div>
  </div>`
  scrim.addEventListener('mousedown', e => { if (e.target === scrim) closeCmdK() })
  document.body.appendChild(scrim)
  const inp = scrim.querySelector('#cmdk-input')
  inp.oninput = () => renderCmdKList(inp.value)
  inp.onkeydown = e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); moveCmdK(1) }
    else if (e.key === 'ArrowUp') { e.preventDefault(); moveCmdK(-1) }
    else if (e.key === 'Enter') { e.preventDefault(); execCmdK() }
  }
  renderCmdKList('')
  setTimeout(() => inp.focus(), 20)
}
export function closeCmdK() { cmdkOpen = false; document.getElementById('cmdk-scrim')?.remove() }
function moveCmdK(dir) {
  if (!cmdkFiltered.length) return
  cmdkSel = (cmdkSel + dir + cmdkFiltered.length) % cmdkFiltered.length
  paintCmdKSel()
}
function paintCmdKSel() {
  const list = document.getElementById('cmdk-list'); if (!list) return
  list.querySelectorAll('.cmdk-item').forEach(el => {
    const sel = +el.dataset.idx === cmdkSel
    el.classList.toggle('selected', sel)
    if (sel) el.scrollIntoView({ block: 'nearest' })
  })
}
function renderCmdKList(q) {
  const list = document.getElementById('cmdk-list'); if (!list) return
  q = q.trim()
  let scored
  if (!q) scored = cmdkItems.filter(i => i.group !== 'Topics').map(it => ({ it, score: 0 }))
  else {
    scored = cmdkItems.map(it => {
      const l = fuzzyMatch(q, it.label)
      if (!l) return null
      const sub = it.sub ? fuzzyMatch(q, it.sub)?.score * 0.4 || 0 : 0
      return { it, score: l.score + sub }
    }).filter(Boolean).sort((a, b) => b.score - a.score).slice(0, 40)
  }
  cmdkFiltered = scored.map(x => x.it); cmdkSel = 0
  if (!cmdkFiltered.length) { list.innerHTML = '<div class="cmdk-empty">No matches. Try a topic like “electrostatics” or an action like “theme”.</div>'; return }
  let html = '', lastGroup = null
  cmdkFiltered.forEach((it, idx) => {
    if (it.group !== lastGroup) { html += `<div class="cmdk-group">${it.group}</div>`; lastGroup = it.group }
    html += `<div class="cmdk-item${idx === 0 ? ' selected' : ''}" data-idx="${idx}" role="option" aria-selected="${idx === 0}">
      <div class="ci-ico">${it.icon}</div>
      <div style="flex:1;min-width:0"><div>${highlightMatch(esc(it.label), esc(q))}</div>${it.sub ? `<div class="ci-sub">${esc(it.sub)}</div>` : ''}${it.hint ? `<div class="ci-sub">${esc(it.hint)}</div>` : ''}</div>
    </div>`
  })
  list.innerHTML = html
  list.querySelectorAll('.cmdk-item').forEach(el => {
    el.onclick = () => { cmdkSel = +el.dataset.idx; execCmdK() }
    el.onmousemove = () => { if (cmdkSel !== +el.dataset.idx) { cmdkSel = +el.dataset.idx; paintCmdKSel() } }
  })
}
function execCmdK() {
  const it = cmdkFiltered[cmdkSel]
  if (!it) return
  closeCmdK()
  it.run()
}

function cycleThemeAction() {
  import('../features/settings/settings.js').then(m => m.cycleTheme())
}
function exportDataAction() {
  import('../features/settings/settings.js').then(m => m.exportData())
}
function clearDoneTasksAction() {
  const n = store.data.tasks.filter(t => t.done).length
  if (!n) { toast('ℹ', 'No finished tasks to clear'); return }
  confirmDialog({
    title: 'Clear finished tasks?',
    message: `This removes <strong style="color:var(--white)">${n}</strong> completed task${n > 1 ? 's' : ''}.`,
    danger: true,
    onConfirm() { store.data.tasks = store.data.tasks.filter(t => !t.done); toast('🧹', `${n} task${n > 1 ? 's' : ''} cleared`); renderContent() },
  })
}

export function isCmdKOpen() { return cmdkOpen }
export function closeCmdKIfOpen() { if (cmdkOpen) closeCmdK() }

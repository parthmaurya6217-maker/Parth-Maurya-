/**
 * features/settings/settings.js — Settings tab + the ⚙ modal entry points.
 * Sections: Pomodoro · AI · Appearance · Exams · Syllabus editor · Data.
 * Everything applies instantly with a "Saved" micro-toast.
 */
import { store, save, resetAll, saveAll } from '../../state/store.js'
import { syllabus, SUBJECT_ORDER, applyOverrides, chapterById, topicKey as topicKeyFor } from '../../data/syllabus.js'
import { SUBJECTS } from '../../../syllabus-exams.data.js'
import { EXAMS, EXAM_ORDER } from '../../data/exams.js'
import { esc } from '../../lib/format.js'
import { toast, openModal, closeModal, confirmDialog } from '../../lib/ui.js'
import { renderContent, renderContentPreserveScroll } from '../router.js'
import { setTab } from '../../state/store.js'
import { exportAll, importAll } from '../../state/storage.js'
import { todayKey } from '../../lib/time.js'

export function renderSettings() {
  return `<div class="fadein" style="max-width:860px">
    <div class="card-label">Settings</div>
    ${sectionPomodoro()}
    ${sectionAI()}
    ${sectionAppearance()}
    ${sectionExams()}
    ${sectionSyllabus()}
    ${sectionData()}
  </div>`
}

function section(title, icon, body) {
  return `<div class="card" style="margin-bottom:16px">
    <div class="card-label">${icon} ${title}</div>
    ${body}
  </div>`
}
function row(label, sub, control) {
  return `<div class="set-row"><div><div class="sr-label">${label}</div>${sub ? `<div class="sr-sub">${sub}</div>` : ''}</div>${control}</div>`
}
function seg(opts, current, action, extra = '') {
  return `<div class="seg" data-seg="${action}">${opts.map(o => `<button data-action="${action}" data-val="${o[0]}" class="${current === o[0] ? 'active' : ''}" ${extra}>${o[1]}</button>`).join('')}</div>`
}

// ── 1. Pomodoro ─────────────────────────────────────────────────────────────
function sectionPomodoro() {
  const p = store.settings.pomodoro
  return section('Pomodoro', '⏱', `
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:12px">
      ${num('focusMin', 'Focus (min)', p.focusMin, 5, 120)}
      ${num('shortMin', 'Short break', p.shortMin, 1, 30)}
      ${num('longMin', 'Long break', p.longMin, 5, 60)}
      ${num('cycles', 'Blocks / cycle', p.cycles, 2, 8)}
    </div>
    ${row('Auto-start breaks', 'Next break begins when focus ends', toggle('autoStartBreak', p.autoStartBreak))}
    ${row('Auto-start next focus', 'Next focus begins when a break ends', toggle('autoStartFocus', p.autoStartFocus))}
    ${row('Auto-pause YouTube on breaks', 'Pauses the video in Focus Lab during breaks, resumes on focus', toggle('autoPauseVideo', p.autoPauseVideo))}
    ${row('Calm fluid during focus', 'Drops GPU load and distraction while a focus block runs', toggle('calmFluid', p.calmFluid))}
    ${row('Strict mode', 'Confirm before resetting the timer', toggle('strictMode', p.strictMode))}
    ${row('Chime volume', '', `<div style="display:flex;align-items:center;gap:8px"><input type="range" min="0" max="1" step="0.05" value="${p.chimeVolume}" data-action="pomo-volume" style="width:110px;accent-color:#8B5CF6">${toggle('chimeMute', p.chimeMute)}</div>`)}
    ${row('Wake lock', 'Keeps the screen awake during a focus block (supported browsers)', toggle('wakeLock', p.wakeLock))}
    <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
      <button class="btn btn-ghost" data-action="pomo-notify-perm" style="padding:7px 14px;font-size:11px">🔔 Enable notifications</button>
      <button class="btn btn-ghost" data-action="pomo-reset-defaults" style="padding:7px 14px;font-size:11px">Reset to 30/5/15</button>
    </div>`)
}
function num(key, label, val, min, max) {
  return `<label style="display:flex;flex-direction:column;gap:4px"><span style="font-size:10px;color:var(--dim);text-transform:uppercase;letter-spacing:1px">${label}</span>
    <input type="number" min="${min}" max="${max}" value="${val}" data-action="pomo-num" data-key="${key}" style="width:100%"></label>`
}
function toggle(key, val) {
  return `<input type="checkbox" data-action="set-toggle" data-key="${key}" ${val ? 'checked' : ''} style="width:38px;height:22px;accent-color:#8B5CF6">`
}

// ── 2. AI ───────────────────────────────────────────────────────────────────
function sectionAI() {
  const ai = store.settings.ai
  return section('AI', '✦', `
    ${row('Provider', 'Gemini understands YouTube links natively; transcript mode needs the local proxy', seg([['gemini', 'Gemini'], ['transcript', 'Transcript + chat model'], ['manual', 'Manual only']], ai.provider, 'ai-provider'))}
    ${row('Model', '', `<select data-action="ai-model" style="width:220px">${['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.0-flash'].map(m => `<option ${ai.model === m ? 'selected' : ''}>${m}</option>`).join('')}</select>`)}
    ${row('Mode', 'direct = browser → Gemini (key in this browser). proxy = browser → your server → Gemini', seg([['direct', 'Direct'], ['proxy', 'Proxy']], ai.mode, 'ai-mode'))}
    ${ai.mode === 'proxy' ? row('Proxy URL', 'e.g. http://localhost:3000', `<input type="text" value="${esc(ai.proxyUrl)}" data-action="ai-proxy-url" placeholder="http://localhost:3000" style="width:220px" spellcheck="false">`) : ''}
    ${row('Gemini API key', 'Used for YouTube video analysis', `<input type="password" value="${esc(ai.geminiKey)}" data-action="ai-gemini-key" placeholder="AIza…" autocomplete="off" spellcheck="false" style="width:240px;font-family:var(--font-mono);font-size:12px">`)}
    ${row('AI Chat key (OpenRouter)', 'For the AI Tutor tab', `<input type="password" value="${esc(ai.openrouterKey)}" data-action="ai-or-key" placeholder="sk-or-v1-…" autocomplete="off" spellcheck="false" style="width:240px;font-family:var(--font-mono);font-size:12px">`)}
    ${row('Max topics per video', '', `<input type="number" min="8" max="40" value="${ai.maxTopics}" data-action="ai-max-topics" style="width:90px">`)}
    ${row('Thinking budget', '0 = fastest/cheapest; 1024 = deeper reasoning for dense lectures', `<input type="number" min="0" max="1024" step="64" value="${ai.thinkingBudget}" data-action="ai-thinking" style="width:90px">`)}
    <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
      <button class="btn btn-ghost" data-action="ai-test-key" style="padding:7px 14px;font-size:11px">Test Gemini key</button>
      <button class="btn btn-ghost" data-action="ai-test-or" style="padding:7px 14px;font-size:11px">Test OpenRouter key</button>
    </div>
    <div style="margin-top:14px;background:rgba(245,200,66,.07);border:1px solid rgba(245,200,66,.2);border-radius:10px;padding:12px 14px;font-size:11.5px;color:var(--muted);line-height:1.6">
      <strong style="color:var(--warn)">Keys stored in a browser can be read by anything running in this browser.</strong> Use a key restricted to the Generative Language API, and prefer proxy mode if you deploy this publicly. Keys are never logged or committed.
    </div>`)
}

// ── 3. Appearance ───────────────────────────────────────────────────────────
function sectionAppearance() {
  const a = store.settings.appearance
  return section('Appearance', '🎨', `
    ${row('Theme', 'Light / dark / follow your OS', seg([['light', '☀️ Light'], ['dark', '🌙 Dark'], ['system', 'System']], store.settings.theme, 'theme-pref'))}
    ${row('Glass intensity', 'Drives blur, tint and rim opacity', seg([['subtle', 'Subtle'], ['standard', 'Standard'], ['intense', 'Intense']], a.glassIntensity, 'glass-intensity'))}
    ${row('Glass motion', 'Pointer-tracked sheen and caustic rim', toggle('glassMotion', a.glassMotion))}
    ${row('Fluid background', 'The LiquidEther palette behind the glass', seg([['aurora', 'Aurora'], ['nebula', 'Nebula'], ['ink', 'Ink'], ['off', 'Off']], a.palette, 'fluid-palette'))}
    ${row('Fluid resolution', 'GPU cost vs smoothness', seg([['performance', 'Performance'], ['balanced', 'Balanced'], ['quality', 'Quality']], a.resolution, 'fluid-res'))}
    ${row('Calm fluid during focus', 'Pause the background animation during focus blocks', toggle('calmFluid', a.calmFluid))}
    ${row('Reduced motion', 'Respects your OS setting by default', seg([['auto', 'Auto'], ['reduced', 'Reduced'], ['full', 'Full']], a.reducedMotion === null ? 'auto' : (a.reducedMotion ? 'reduced' : 'full'), 'reduced-motion'))}
    <div style="display:flex;gap:10px;margin-top:12px;align-items:center;flex-wrap:wrap">
      <span class="chip" style="color:var(--muted)">FPS <span id="fps-readout" style="font-family:var(--font-mono);color:var(--white)">${store.ui.fps || 60}</span></span>
      ${store.ui.glassLite ? `<span class="chip" style="background:rgba(245,200,66,.14);color:var(--warn)">glass-lite: performance mode active</span>` : ''}
    </div>`)
}

// ── 4. Exams ────────────────────────────────────────────────────────────────
function sectionExams() {
  const e = store.settings.exams
  const rows = EXAM_ORDER.map(id => {
    const exam = EXAMS.find(x => x.id === id)
    const status = e.status[id] || exam.status || 'upcoming'
    const startOverride = e.examDates[id]?.start || exam.start
    const endOverride = e.examDates[id]?.end !== undefined ? e.examDates[id].end : (exam.end || '')
    return `<div style="display:flex;gap:10px;align-items:center;padding:8px 0;border-bottom:1px solid var(--border);flex-wrap:wrap">
      <div style="flex:1;min-width:150px">
        <div style="font-size:12.5px;color:var(--white);font-weight:500">${esc(e.names[id] || exam.name)}</div>
        ${exam.printedAs ? `<div style="font-size:9.5px;color:var(--dim)">printed as ${exam.printedAs}</div>` : ''}
      </div>
      <input type="date" value="${startOverride}" data-action="exam-date" data-exam="${id}" data-field="start" aria-label="${exam.short} start" style="width:140px">
      <input type="date" value="${endOverride || ''}" data-action="exam-date" data-exam="${id}" data-field="end" aria-label="${exam.short} end" style="width:140px">
      <select data-action="exam-status" data-exam="${id}" style="width:120px">
        ${['upcoming', 'active', 'completed'].map(s => `<option ${status === s ? 'selected' : ''}>${s}</option>`).join('')}
      </select>
      <button class="btn btn-ghost" data-action="exam-edit-scope" data-id="${id}" style="padding:5px 10px;font-size:10px">Scope</button>
    </div>`
  }).join('')
  return section('Exams', '📅', `
    ${row('Electives', 'PCM → Maths Section B. Turning Section C on changes every scope, ring and readiness number', seg([['off', 'Section B (PCM)'], ['on', 'Section C on']], e.sectionC ? 'on' : 'off', 'section-c'))}
    <div style="margin-top:10px">${rows}</div>`)
}

// ── 5. Syllabus editor ──────────────────────────────────────────────────────
function sectionSyllabus() {
  const over = store.syllabusOverrides.chapters || {}
  const body = SUBJECT_ORDER.map(sk => {
    const subj = SUBJECTS[sk]
    const chs = syllabus()[sk]
    const rows = chs.map(ch => {
      const isTaught = ch.topics.some(t => store.mastery[topicKeyFor(sk, ch.id, t.id)]?.school)
      const needsConf = ch.needsConfirmation
      return `<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border);flex-wrap:wrap">
        ${needsConf ? '<span title="needs confirmation" style="color:var(--warn);font-size:11px">●</span>' : '<span style="width:11px"></span>'}
        <span style="flex:1;min-width:160px;font-size:12px;color:var(--text)">${ch.no ? `Ch ${ch.no} · ` : ''}${esc(ch.name)} <span style="color:var(--dim)">(${ch.topics.length} topics)</span></span>
        <input type="text" value="${esc(ch.name)}" data-action="sy-rename" data-sk="${sk}" data-chid="${ch.id}" style="width:200px;padding:4px 8px;font-size:11px" title="Rename chapter">
        <button class="btn btn-ghost" data-action="sy-taught" data-sk="${sk}" data-chid="${ch.id}" style="padding:4px 10px;font-size:9.5px;background:${isTaught ? 'rgba(74,222,128,.12)' : 'transparent'};color:${isTaught ? 'var(--green)' : 'var(--muted)'}">${isTaught ? '✓ taught' : 'taught?'}</button>
        <button class="btn btn-ghost" data-action="sy-del-chapter" data-sk="${sk}" data-chid="${ch.id}" style="padding:4px 8px;font-size:10px;color:var(--red)">×</button>
      </div>`
    }).join('')
    return `<div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
        <div style="font-size:11px;color:${subj.color};font-weight:600">${subj.name}</div>
        <button class="btn btn-ghost" data-action="sy-add-chapter" data-sk="${sk}" style="padding:4px 10px;font-size:9.5px">+ chapter</button>
      </div>
      ${rows}
    </div>`
  }).join('')
  return section('Syllabus editor', '📚', `
    <div style="font-size:11px;color:var(--dim);margin-bottom:10px;line-height:1.6">Amber dots mark items <strong style="color:var(--warn)">needing confirmation</strong> (inferred, not printed verbatim). Edits live in <span style="font-family:var(--font-mono)">studyos.v2.syllabusOverrides</span> and merge over the shipped file, so the data file stays pristine.</div>
    ${body}`)
}

// ── 6. Data ─────────────────────────────────────────────────────────────────
function sectionData() {
  return section('Data', '💾', `
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn btn-ghost" data-action="data-export" style="padding:8px 14px;font-size:11px">⬇ Export backup (.json)</button>
      <label class="btn btn-ghost" style="padding:8px 14px;font-size:11px;cursor:pointer">⬆ Import backup<input type="file" accept=".json,application/json" style="display:none" data-action="data-import"></label>
      <button class="btn btn-ghost" data-action="data-clear-videos" style="padding:8px 14px;font-size:11px">Clear video cache</button>
      <button class="btn btn-danger" data-action="data-reset" style="padding:8px 14px;font-size:11px">Reset everything</button>
    </div>
    <div style="margin-top:12px;font-size:11px;color:var(--dim);line-height:1.6">Your data lives in this browser's localStorage under <span style="font-family:var(--font-mono)">studyos.v2.*</span>. Export regularly — clearing browser data will erase it. Old v1 keys are kept untouched as a backup.</div>`)
}

// ── actions ─────────────────────────────────────────────────────────────────
function savedToast() { toast('✓', 'Saved', { ttl: 900 }) }

export function setToggle(_, ds) {
  const [section, key] = ds.key.split('.')
  if (section === 'appearance') store.settings.appearance[key] = ds.checked
  else if (section === 'pomodoro') store.settings.pomodoro[key] = ds.checked
  save('settings')
  savedToast()
  renderContent()
}
export function setPomoNum(_, ds) {
  const v = Math.max(1, parseInt(ds.value, 10) || 1)
  store.settings.pomodoro[ds.key] = v
  save('settings')
}
export function setPomoVolume(_, ds) {
  store.settings.pomodoro.chimeVolume = parseFloat(ds.value) || 0.6
  save('settings')
}
export function pomoNotifyPerm() {
  if ('Notification' in window) Notification.requestPermission().then(p => toast('🔔', p === 'granted' ? 'Notifications enabled' : 'Notifications blocked'))
}
export function pomoResetDefaults() {
  Object.assign(store.settings.pomodoro, { focusMin: 30, shortMin: 5, longMin: 15, cycles: 4 })
  save('settings')
  savedToast()
  renderContent()
}

export function setAiProvider(_, ds) { store.settings.ai.provider = ds.val; save('settings'); savedToast(); renderContent() }
export function setAiModel(_, ds) { store.settings.ai.model = ds.value; save('settings') }
export function setAiMode(_, ds) { store.settings.ai.mode = ds.val; save('settings'); savedToast(); renderContent() }
export function setAiProxyUrl(_, ds) { store.settings.ai.proxyUrl = ds.value; save('settings') }
export function setAiKey(_, ds) { store.settings.ai.geminiKey = ds.value.trim(); save('settings'); savedToast() }
export function setAiORKey(_, ds) { store.settings.ai.openrouterKey = ds.value.trim(); save('settings'); savedToast() }
export function setAiMaxTopics(_, ds) { store.settings.ai.maxTopics = Math.max(8, Math.min(40, parseInt(ds.value, 10) || 40)); save('settings') }
export function setAiThinking(_, ds) { store.settings.ai.thinkingBudget = Math.max(0, parseInt(ds.value, 10) || 0); save('settings') }

export async function testGeminiKey() {
  const key = store.settings.ai.geminiKey.trim()
  if (!key) { toast('⚠', 'No Gemini key set'); return }
  const t0 = Date.now()
  try {
    const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(key)}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: 'Reply with OK' }] }], generationConfig: { maxOutputTokens: 5 } }),
    })
    const ms = Date.now() - t0
    toast(resp.ok ? '✅' : '⚠', resp.ok ? `Gemini key works (${ms} ms)` : `Key rejected (${resp.status})`)
  } catch { toast('⚠', 'Network error testing the key') }
}
export async function testOpenRouterKey() {
  const key = store.settings.ai.openrouterKey.trim()
  if (!key) { toast('⚠', 'No OpenRouter key set'); return }
  const t0 = Date.now()
  try {
    const resp = await fetch('https://openrouter.ai/api/v1/models', { headers: { Authorization: `Bearer ${key}` } })
    const ms = Date.now() - t0
    toast(resp.ok ? '✅' : '⚠', resp.ok ? `OpenRouter key works (${ms} ms)` : `Key rejected (${resp.status})`)
  } catch { toast('⚠', 'Network error testing the key') }
}

export function setThemePref(_, ds) { store.settings.theme = ds.val; save('settings'); applyTheme(); savedToast() }
export function setGlassIntensity(_, ds) { store.settings.appearance.glassIntensity = ds.val; save('settings'); applyAppearance(); savedToast(); renderContent() }
export function setFluidPalette(_, ds) { store.settings.appearance.palette = ds.val; save('settings'); applyAppearance(); savedToast() }
export function setFluidRes(_, ds) { store.settings.appearance.resolution = ds.val; save('settings'); applyAppearance(); savedToast() }
export function setReducedMotion(_, ds) {
  store.settings.appearance.reducedMotion = ds.val === 'auto' ? null : ds.val === 'reduced'
  save('settings'); applyAppearance(); savedToast()
}

export function setSectionC(_, ds) { store.settings.exams.sectionC = ds.val === 'on'; save('settings'); savedToast(); renderContentPreserveScroll() }
export function setExamDate(_, ds) {
  const e = store.settings.exams.examDates || (store.settings.exams.examDates = {})
  e[ds.exam] = e[ds.exam] || {}
  e[ds.exam][ds.field] = ds.value || null
  save('settings'); savedToast()
}
export function setExamStatus(_, ds) {
  store.settings.exams.status[ds.exam] = ds.value
  if (ds.value === 'completed') { const ep = store.examProgress[ds.exam]; if (ep && !ep.completedAt) ep.completedAt = new Date().toISOString() }
  save('settings'); savedToast(); renderContentPreserveScroll()
}

// syllabus editor
export function syRename(_, ds) {
  const over = store.syllabusOverrides.chapters || (store.syllabusOverrides.chapters = {})
  const subjOver = over[ds.sk] || (over[ds.sk] = {})
  subjOver.renamed = subjOver.renamed || {}
  subjOver.renamed[ds.chid] = ds.value.trim() || undefined
  save('syllabusOverrides'); applyOverrides(store.syllabusOverrides.chapters)
  savedToast(); renderContentPreserveScroll()
}
export function syTaught(_, ds) {
  const found = chapterById().get(ds.chid)
  if (!found) return
  const { subjectKey: sk, chapter: ch } = found
  const currentlyTaught = ch.topics.some(t => store.mastery[topicKeyFor(sk, ch.id, t.id)]?.school)
  for (const t of ch.topics) {
    const rec = store.mastery[topicKeyFor(sk, ch.id, t.id)] || (store.mastery[topicKeyFor(sk, ch.id, t.id)] = { status: 'not_started', school: false, confidence: 0, revisions: 0, minutes: 0, flagged: false, sources: [] })
    rec.school = !currentlyTaught
  }
  save('mastery'); savedToast(); renderContentPreserveScroll()
}
export function syAddChapter(_, ds) {
  const name = window.prompt('New chapter name:', '')
  if (!name) return
  const over = store.syllabusOverrides.chapters || (store.syllabusOverrides.chapters = {})
  const subjOver = over[ds.sk] || (over[ds.sk] = {})
  subjOver.added = subjOver.added || []
  const id = `${ds.sk}.custom_${Date.now().toString(36)}`
  subjOver.added.push({ id, name, topics: [{ id: 'custom_topic_1', title: 'Custom topic 1' }], term: 1, needsConfirmation: true })
  applyOverrides(store.syllabusOverrides.chapters)
  savedToast(); renderContentPreserveScroll()
}
export function syDelChapter(_, ds) {
  confirmDialog({
    title: 'Remove chapter?',
    message: `Hides "${ds.chid}" and its topics from every scope (shipped data is untouched).`,
    danger: true,
    onConfirm() {
      const over = store.syllabusOverrides.chapters || (store.syllabusOverrides.chapters = {})
      const subjOver = over[ds.sk] || (over[ds.sk] = {})
      subjOver.removed = subjOver.removed || []
      subjOver.removed.push(ds.chid)
      applyOverrides(store.syllabusOverrides.chapters)
      savedToast(); renderContentPreserveScroll()
    },
  })
}

// data
export function exportData() {
  const data = exportAll()
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = `studyos-backup-${todayKey()}.json`
  a.click()
  URL.revokeObjectURL(a.href)
  toast('⬇', 'Backup downloaded')
}
export function importData(_, ds) {
  const input = document.getElementById('data-import-input') || document.querySelector('[data-action="data-import"]')
  const file = input?.files?.[0]
  if (!file) return
  const reader = new FileReader()
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result)
      // dry-run diff preview
      const cur = exportAll()
      let addTicks = 0, changeDates = 0, changeTopics = 0
      const incoming = data.mastery || {}
      for (const k of Object.keys(incoming)) if (!cur.mastery?.[k]) addTicks++
      if (data.settings?.exams?.examDates) changeDates = Object.keys(data.settings.exams.examDates).length
      if (data.syllabusOverrides?.chapters) changeTopics = Object.keys(data.syllabusOverrides.chapters).length
      confirmDialog({
        title: 'Import backup?',
        message: `This will add <strong style="color:var(--white)">${addTicks} ticks</strong> and change <strong style="color:var(--white)">${changeDates} exam dates</strong> and <strong style="color:var(--white)">${changeTopics} syllabus edits</strong>. Current API keys are kept.`,
        confirmLabel: 'Import', danger: true,
        onConfirm() {
          const res = importAll(data)
          location.reload()
          toast('✅', `Imported ${res.written.length} sections`)
        },
      })
    } catch (err) { toast('⚠', `Import failed: ${esc(err.message)}`) }
    input.value = ''
  }
  reader.readAsText(file)
}
export function clearVideoCache() {
  const n = Object.keys(store.videos).length
  confirmDialog({
    title: 'Clear video cache?',
    message: `Removes ${n} cached video analyses. You'll re-analyse links (costs quota).`,
    danger: true,
    onConfirm() { store.videos = {}; save('videos'); savedToast(); renderContent() },
  })
}
export function resetAllData() {
  confirmDialog({
    title: 'Reset everything?',
    message: 'This permanently deletes <strong style="color:var(--white)">all</strong> progress, tasks, notes, videos, plans and settings. Consider exporting a backup first.',
    confirmLabel: 'Delete everything', danger: true,
    onConfirm() {
      resetAll()
      localStorage.removeItem('studyos_v2_state')
      location.reload()
    },
  })
}

// ── theme + appearance (also used from header) ──────────────────────────────
export function applyTheme() {
  const pref = store.settings.theme
  const dark = pref === 'dark' || (pref === 'system' && (!window.matchMedia ? true : window.matchMedia('(prefers-color-scheme: dark)').matches))
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light')
  const meta = document.querySelector('meta[name=theme-color]')
  if (meta) meta.content = dark ? '#050508' : '#F1F1F6'
  return dark
}
export function cycleTheme() {
  const order = ['light', 'dark', 'system']
  const idx = order.indexOf(store.settings.theme)
  store.settings.theme = order[(idx + 1) % order.length]
  save('settings')
  applyTheme()
  const eff = store.settings.theme === 'system' ? (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') : store.settings.theme
  toast('🌓', `Theme: ${store.settings.theme === 'system' ? 'System (' + eff + ')' : eff}`)
}
export function applyAppearance() {
  import('../../lib/glass.js').then(m => m.applyAppearance?.())
  import('../../lib/liquidEther.js').then(m => m.applyAppearance?.())
}

// ── the ⚙ entry point ───────────────────────────────────────────────────────
export function openSettings() {
  setTab('settings')
  renderContent()
  window.scrollTo({ top: 0 })
}

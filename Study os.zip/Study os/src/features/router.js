/**
 * features/router.js — render dispatch + 1 s / 30 s live loops + header/session
 * bar. Targeted DOM updates replace the v1 blanket re-renders where possible.
 */
import { store, addSecondsToSubject, currentStreak } from '../state/store.js'
import { todayKey, daysUntil, fmtClock, fmtSecs, toMins } from '../lib/time.js'
import { getCurrentSession, getNextSession, getProgress, getRemaining, isStudySession } from '../features/schedule.js'
import { renderDashboard, updateDashboardLive } from './dashboard.js'
import { renderSchedule } from './schedule.js'
import { renderChecklist } from './checklist.js'
import { renderAnalytics } from './analytics.js'
import { renderEvents } from './events.js'
import { renderTasks } from './tasks.js'
import { renderExamTimetable } from './examTimetable.js'
import { renderAIChat, attachChatEvents } from './aiChat.js'
import { renderExamPrep } from './examPrep.js'
import { renderFocusLab, focusLabTick } from './focusLab.js'
import { renderSettings } from './settings/settings.js'
import { updateFocusOverlay } from './focusOverlay.js'

const renderers = {
  dashboard: renderDashboard,
  examPrep: renderExamPrep,
  schedule: renderSchedule,
  checklist: renderChecklist,
  focusLab: renderFocusLab,
  stats: renderAnalytics,
  events: renderEvents,
  tasks: renderTasks,
  examTimetable: renderExamTimetable,
  aichat: renderAIChat,
  settings: renderSettings,
}

export function renderContent() {
  const el = document.getElementById('content')
  if (!el) return
  const fn = renderers[store.ui.tab]
  try {
    const html = fn ? fn() : `<div class="card"><div class="empty-state">Unknown tab.</div></div>`
    el.innerHTML = html
    if (store.ui.tab === 'aichat') attachChatEvents()
    if (store.ui.tab === 'focusLab') focusLabTick()
    if (store.ui.tab === 'dashboard') updateDashboardLive()
  } catch (e) {
    el.innerHTML = errorCard(e)
    console.error('render error', e)
  }
}

export function renderContentPreserveScroll() {
  const c = document.getElementById('content')
  const y = window.scrollY
  renderContent()
  window.scrollTo({ top: y })
}

function errorCard(e) {
  const msg = esc(String(e?.message || e))
  const stack = esc(String(e?.stack || ''))
  return `<div class="card" style="max-width:560px;margin:40px auto">
    <div style="font-size:10px;letter-spacing:3px;color:var(--dim);text-transform:uppercase;margin-bottom:10px">Something went wrong</div>
    <div style="font-size:15px;color:var(--white);margin-bottom:12px">This tab failed to render.</div>
    <pre style="background:var(--card2);border:1px solid var(--border);border-radius:8px;padding:12px;font-size:11.5px;color:var(--red);overflow:auto;font-family:var(--font-mono)">${msg}\n${stack}</pre>
    <div style="display:flex;gap:10px;margin-top:16px">
      <button class="btn" data-action="copy-diagnostics" style="background:rgba(96,181,255,.14);border:1px solid rgba(96,181,255,.35);color:#60B5FF">Copy diagnostics</button>
      <button class="btn btn-ghost" data-action="reload-app">Reload app</button>
    </div>
  </div>`
}
function esc(s) { return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;') }

// ── live loop ────────────────────────────────────────────────────────────────
let now = new Date()
export function getNow() { return now }

export function tickLoop() {
  now = new Date()
  updateHeader()
  updateSessionBar()
  updateFocusOverlay()
  if (store.ui.tab === 'dashboard') updateDashboardLive()
  if (store.ui.tab === 'focusLab') focusLabTick()
}

export function slowLoop() {
  const ae = document.activeElement
  if (ae && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA' || ae.isContentEditable)) return
  if (isModalOrPaletteOpen()) return
  if (['dashboard', 'schedule', 'stats', 'examTimetable', 'examPrep'].includes(store.ui.tab)) renderContent()
}

function isModalOrPaletteOpen() {
  return !!document.querySelector('.modal-scrim') || !!document.getElementById('cmdk-scrim')
}

function updateHeader() {
  const clockEl = document.getElementById('clock')
  if (clockEl) clockEl.innerHTML = fmtClock(now)
  const dateEl = document.getElementById('date-label')
  if (dateEl) dateEl.textContent = now.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
  const streakEl = document.getElementById('streak-label')
  if (streakEl) streakEl.textContent = `${currentStreak()} day streak`
  const fc = document.getElementById('footer-countdown')
  if (fc) fc.textContent = `${Math.max(daysUntil('2027-02-13'), 0)} days to ISC Exams`
  const sess = getCurrentSession(now)
  const fb = document.getElementById('focus-btn')
  if (fb) {
    if (sess && sess.type !== 'break') {
      fb.style.display = 'inline-flex'
      fb.style.background = 'rgba(96,181,255,.12)'
      fb.style.border = '1px solid rgba(96,181,255,.4)'
      fb.style.color = '#60B5FF'
    } else fb.style.display = 'none'
  }
}

function updateSessionBar() {
  const sess = getCurrentSession(now)
  const bar = document.getElementById('session-bar')
  if (!sess) { if (bar) bar.style.display = 'none'; return }
  const col = sess.subject ? SUBJ_COLOR(sess.subject) : '#64748B'
  if (bar) {
    bar.style.display = 'flex'
    bar.style.background = `linear-gradient(90deg,${col}12,transparent)`
    bar.style.borderBottom = `1px solid ${col}20`
  }
  const dot = document.getElementById('sess-dot'); if (dot) dot.style.background = col
  const lab = document.getElementById('sess-bar-label')
  if (lab) { lab.style.color = col; lab.textContent = `${sess.label} in progress` }
  const pb = document.getElementById('sess-bar-prog')
  if (pb) {
    const prog = getProgress(sess, now)
    pb.style.width = `${Math.round(prog * 100)}%`
    pb.style.background = col
    pb.style.boxShadow = `0 0 6px ${col}`
  }
  const t = document.getElementById('sess-bar-time')
  if (t) {
    const rem = getRemaining(sess, now)
    t.textContent = `${String(rem.m).padStart(2, '0')}:${String(rem.s).padStart(2, '0')} left`
  }
}

const SUBJ_COLOR = { maths: '#F5C842', physics: '#60B5FF', chemistry: '#4ADE80', revision: '#C084FC' }

export function autoTrackTime() {
  const sess = getCurrentSession(now)
  if (sess && sess.subject && document.visibilityState === 'visible') {
    addSecondsToSubject(sess.subject, 1)
  }
}

// ── boot-time rollover: move older completed entries into days history ──────
export function bootRollover() {
  const tk = todayKey()
  for (const dk of Object.keys(store.data.completed)) {
    if (dk !== tk && Array.isArray(store.data.completed[dk])) {
      const day = store.data.days[dk] || (store.data.days[dk] = { completed: [], seconds: {} })
      day.completed = [...new Set([...(day.completed || []), ...store.data.completed[dk]])]
    }
  }
  store.data.completed = store.data.completed[tk] ? { [tk]: store.data.completed[tk] } : {}
}

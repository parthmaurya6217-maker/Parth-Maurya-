/**
 * state/storage.js — namespaced localStorage with try/catch, JSON validation,
 * quota handling and schema versioning. Never throws to the caller.
 */
import { $ } from '../lib/dom.js'

const PREFIX = 'studyos.v2.'
const SCHEMA_VERSION = 1

export const KEYS = {
  state: 'state',           // tasks, notes, chat, completed, days, streak…
  mastery: 'mastery',
  examProgress: 'examProgress',
  settings: 'settings',
  pomodoro: 'pomodoro',
  videos: 'videos',
  sessions: 'sessions',
  history: 'history',
  syllabusOverrides: 'syllabusOverrides',
  plan: 'plan',
  migrationReport: 'migrationReport',
}

export function keyName(k) { return PREFIX + k }
export function schemaVersion() { return SCHEMA_VERSION }

export function get(k, def) {
  try {
    const raw = localStorage.getItem(keyName(k))
    if (raw == null) return def
    const v = JSON.parse(raw)
    return v ?? def
  } catch { return def }
}

export function set(k, val) {
  try {
    localStorage.setItem(keyName(k), JSON.stringify(val))
  } catch (e) {
    // Quota / blocked storage: prune bulky slices then warn once.
    prune()
    try { localStorage.setItem(keyName(k), JSON.stringify(val)) } catch {}
    quotaWarn()
  }
}

export function remove(k) {
  try { localStorage.removeItem(keyName(k)) } catch {}
}

export function has(k) {
  try { return localStorage.getItem(keyName(k)) != null } catch { return false }
}

/** Legacy keys read during migration (kept untouched afterwards as a backup). */
export const LEGACY_KEYS = [
  'studyos_v2_state', 'studyos_completed', 'studyos_tasks', 'studyos_notes',
  'studyos_checklist_my', 'studyos_checklist_school', 'studyos_streak',
]

function prune() {
  for (const k of ['history', 'videos', 'sessions', 'state']) {
    try {
      const raw = localStorage.getItem(keyName(k))
      if (!raw) continue
      const v = JSON.parse(raw)
      if (Array.isArray(v)) {
        const cut = v.slice(0, Math.ceil(v.length / 2))
        localStorage.setItem(keyName(k), JSON.stringify(cut))
      } else if (v && typeof v === 'object') {
        const keys = Object.keys(v)
        for (let i = 0; i < Math.ceil(keys.length / 3); i++) delete v[keys[i]]
        localStorage.setItem(keyName(k), JSON.stringify(v))
      }
    } catch {}
  }
}

let warned = false
function quotaWarn() {
  if (warned) return
  warned = true
  const t = $('body')
  if (!t) return
  const el = document.createElement('div')
  el.style.cssText = 'position:fixed;bottom:64px;left:50%;transform:translateX(-50%);z-index:1300;background:#FF6B6B;color:#fff;padding:10px 18px;border-radius:10px;font-size:12.5px;box-shadow:0 10px 30px rgba(0,0,0,.4)'
  el.textContent = 'Storage nearly full — history and video cache were pruned. Export a backup in Settings.'
  document.body.appendChild(el)
  setTimeout(() => el.remove(), 6000)
}

/** Whole-app export: every v2 slice in one object. */
export function exportAll() {
  const out = { app: 'StudyOS V2', schemaVersion: SCHEMA_VERSION, exportedAt: new Date().toISOString() }
  for (const k of Object.values(KEYS)) out[k] = get(k, undefined)
  // never export secrets
  if (out.settings?.ai) { out.settings = { ...out.settings, ai: { ...out.settings.ai, geminiKey: undefined, openrouterKey: undefined } } }
  return out
}

/** Import a backup: only write slices present in the file, validating each. */
export function importAll(data) {
  const ok = data && typeof data === 'object' && data.app === 'StudyOS V2'
  if (!ok) throw new Error('Not a valid StudyOS V2 backup file')
  const counts = { written: [] }
  for (const k of Object.values(KEYS)) {
    if (k === 'settings') {
      const cur = get('settings', {})
      const incoming = data.settings || {}
      // preserve current API keys even when importing a backup
      const merged = { ...incoming, ai: { ...(incoming.ai || {}), geminiKey: cur.ai?.geminiKey, openrouterKey: cur.ai?.openrouterKey } }
      if (Object.keys(merged).length) { set('settings', merged); counts.written.push('settings') }
    } else if (data[k] !== undefined) {
      set(k, data[k])
      counts.written.push(k)
    }
  }
  return counts
}

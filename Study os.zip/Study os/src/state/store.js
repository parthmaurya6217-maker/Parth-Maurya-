/**
 * state/store.js — the single in-memory state object, backed by the
 * studyos.v2.* localStorage slices. Provides pub/sub and debounced saving.
 */
import { Emitter } from '../lib/events.js'
import { get as load, set as saveSlice, has } from './storage.js'
import { todayKey } from '../lib/time.js'

const emitter = new Emitter()

// ── defaults ────────────────────────────────────────────────────────────────
function defaultData() {
  return {
    completed: {},                            // { "YYYY-MM-DD": [sessionIds] }
    subjectTime: { maths: 0, physics: 0, chemistry: 0, revision: 0 },
    days: {},                                 // { "YYYY-MM-DD": { completed:[], seconds:{} } }
    tasks: [], notes: {}, chat: [],
    streak: { lastDay: null, streak: 0, bestStreak: 0 },
  }
}

function defaultSettings() {
  return {
    theme: 'system',
    onboarded: false,
    ai: {
      provider: 'gemini',                     // gemini | transcript | manual
      model: 'gemini-2.5-flash',
      geminiKey: '', openrouterKey: '',
      mode: 'direct',                          // direct | proxy
      proxyUrl: '',
      maxTopics: 40,
      thinkingBudget: 0,
      chatModel: 'meta-llama/llama-4-scout-17b-16e-instruct',
      videoProvider: 'gemini',
    },
    appearance: {
      glassIntensity: 'standard',             // subtle | standard | intense
      glassMotion: true,
      palette: 'aurora',                       // aurora | nebula | ink | off
      resolution: 'balanced',                  // performance | balanced | quality
      calmDuringFocus: true,
      reducedMotion: null,                     // null=auto | true | false
    },
    pomodoro: {
      focusMin: 30, shortMin: 5, longMin: 15, cycles: 4,
      autoStartBreak: true, autoStartFocus: true, autoPauseVideo: true,
      calmFluid: true, blockTabNags: false, strictMode: false,
      chimeVolume: 0.6, chimeMute: false, wakeLock: false,
    },
    exams: {
      sectionC: false,
      paperDates: {},                          // { examId: { subjectKey: date } }
      examDates: {},                           // { examId: { start, end } }
      names: {},                               // { examId: name }
      status: {},                              // { examId: status }
    },
  }
}

function defaultPomodoro() {
  return { phase: 'idle', startedAt: null, endsAt: null, cyclesDone: 0, isRunning: false, pausedRemainingMs: null }
}

function loadSlice(key, def) {
  const v = load(key, undefined)
  return v === undefined ? def() : v
}

// ── state object ────────────────────────────────────────────────────────────
export const store = {
  ui: {                                    // ephemeral, never persisted
    tab: 'dashboard',
    selectedExam: 'half_yearly',
    focusMode: false,
    quoteIdx: Math.floor(Math.random() * 5),
    taskInput: '', noteInput: '',
    openChapters: {},
    activeChecklist: 'my',
    checklistSearch: '',
    eventFilter: 'all',
    jumpTarget: null,
    glassLite: false,
    fps: 60,
    lastTab: null,
  },
  data: loadSlice('state', defaultData),
  mastery: loadSlice('mastery', () => ({})),
  examProgress: loadSlice('examProgress', () => ({})),
  settings: loadSlice('settings', defaultSettings),
  pomodoro: loadSlice('pomodoro', defaultPomodoro),
  videos: loadSlice('videos', () => ({})),
  sessions: loadSlice('sessions', () => []),
  history: loadSlice('history', () => []),
  syllabusOverrides: loadSlice('syllabusOverrides', () => ({ chapters: {}, scope: {} })),
  plan: loadSlice('plan', () => []),
  migrationReport: loadSlice('migrationReport', () => null),
}

// ── pub/sub ─────────────────────────────────────────────────────────────────
export const on = emitter.on.bind(emitter)
export const off = emitter.off.bind(emitter)
export function emit(name, payload) { emitter.emit(name, payload) }

// ── persistence (debounced, 250 ms) ─────────────────────────────────────────
const saveTimers = {}
export function save(slice) {
  if (!slice) { for (const k of Object.keys(saveTimers)) persistSlice(k); return }
  persistSlice(slice)
}
function persistSlice(slice) {
  clearTimeout(saveTimers[slice])
  saveTimers[slice] = setTimeout(() => {
    try {
      if (slice === 'state') saveSlice('state', store.data)
      else if (slice === 'mastery') saveSlice('mastery', store.mastery)
      else if (slice === 'examProgress') saveSlice('examProgress', store.examProgress)
      else if (slice === 'settings') saveSlice('settings', store.settings)
      else if (slice === 'pomodoro') saveSlice('pomodoro', store.pomodoro)
      else if (slice === 'videos') saveSlice('videos', store.videos)
      else if (slice === 'sessions') saveSlice('sessions', store.sessions)
      else if (slice === 'history') saveSlice('history', store.history)
      else if (slice === 'syllabusOverrides') saveSlice('syllabusOverrides', store.syllabusOverrides)
      else if (slice === 'plan') saveSlice('plan', store.plan)
      else if (slice === 'migrationReport') saveSlice('migrationReport', store.migrationReport)
    } finally {
      emitter.emit('saved', slice)
    }
  }, 250)
}
export function saveNow(slice) {
  clearTimeout(saveTimers[slice])
  persistSlice(slice)
}

// ── streak engine (v1 semantics: a day is active on ≥1 done session OR ≥15 min) ──
export function computeStreakOnActivity() {
  const st = store.data.streak
  const tk = todayKey()
  if (st.lastDay === tk) return
  const y = new Date(); y.setDate(y.getDate() - 1)
  const yk = todayKey(y)
  const yActive = st.lastDay === yk || isActiveDay(yk)
  st.streak = yActive ? st.streak + 1 : 1
  if (st.streak > (st.bestStreak || 0)) st.bestStreak = st.streak
  st.lastDay = tk
  save('state')
}
export function isActiveDay(tk) {
  const day = store.data.days[tk]
  return !!day && ((day.completed?.length > 0) || Object.values(day.seconds || {}).reduce((a, b) => a + b, 0) >= 900)
}
export function currentStreak() {
  let n = 0; const d = new Date()
  if (!isActiveDay(todayKey(d))) {
    d.setDate(d.getDate() - 1)
    if (!isActiveDay(todayKey(d))) return 0
  }
  while (isActiveDay(todayKey(d))) { n++; d.setDate(d.getDate() - 1) }
  return n
}

// ── time tracking (v1 semantics) ─────────────────────────────────────────────
export function addSecondsToSubject(subj, secs) {
  if (!(subj in store.data.subjectTime)) return
  store.data.subjectTime[subj] += secs
  const tk = todayKey()
  const day = store.data.days[tk] || (store.data.days[tk] = { completed: [], seconds: {} })
  day.seconds[subj] = (day.seconds[subj] || 0) + secs
  const total = Object.values(store.data.subjectTime).reduce((a, b) => a + b, 0)
  if (total % 60 === 0) { save('state'); computeStreakOnActivity() }
}

// ── day / session helpers ────────────────────────────────────────────────────
export function ensureDay(tk) {
  return store.data.days[tk] || (store.data.days[tk] = { completed: [], seconds: {} })
}
export function toggleSession(id) {
  const tk = todayKey()
  const arr = store.data.completed[tk] || (store.data.completed[tk] = [])
  const i = arr.indexOf(id)
  if (i >= 0) arr.splice(i, 1)
  else { arr.push(id); computeStreakOnActivity() }
  const d = ensureDay(tk); d.completed = [...arr]
  save('state')
}
export function sessionDoneToday(id) {
  return (store.data.completed[todayKey()] || []).includes(id)
}

// ── task helpers ─────────────────────────────────────────────────────────────
export function addTask(text) {
  store.data.tasks.unshift({ id: Date.now(), text: text.slice(0, 300), done: false, createdAt: new Date().toISOString(), doneAt: null })
  save('state')
}
export function toggleTask(idx) {
  const t = store.data.tasks[idx]; if (!t) return
  t.done = !t.done; t.doneAt = t.done ? new Date().toISOString() : null
  if (t.done) computeStreakOnActivity()
  save('state')
}
export function deleteTask(idx) {
  const t = store.data.tasks[idx]; if (!t) return
  store.data.tasks.splice(idx, 1)
  save('state')
  return t
}

// ── navigation ───────────────────────────────────────────────────────────────
export function setTab(tab) {
  store.ui.lastTab = store.ui.tab
  store.ui.tab = tab
  emit('tab', tab)
}

/** Reset everything to factory defaults (Settings > Data > reset). */
export function resetAll() {
  store.data = defaultData()
  store.mastery = {}
  store.examProgress = {}
  store.settings = defaultSettings()
  store.pomodoro = defaultPomodoro()
  store.videos = {}
  store.sessions = []
  store.history = []
  store.syllabusOverrides = { chapters: {}, scope: {} }
  store.plan = []
  store.migrationReport = null
  saveAll()
}
export function saveAll() {
  for (const k of ['state', 'mastery', 'examProgress', 'settings', 'pomodoro', 'videos', 'sessions', 'history', 'syllabusOverrides', 'plan', 'migrationReport']) save(k)
}

export function hasAnyLegacyData() {
  return has('state') || has('mastery') || has('examProgress')
}

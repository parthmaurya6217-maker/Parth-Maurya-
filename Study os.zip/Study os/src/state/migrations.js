/**
 * state/migrations.js — one-time v1 -> v2 migration, guarded by a flag.
 *  - Reads the live v1 store (studyos_v2_state) plus the older per-key legacy
 *    stores, converts index-based checklist ticks into id-based mastery keys,
 *    pre-ticks the completed UT-1 / UT-2 scopes, and leaves every old key
 *    untouched as a backup. Surfaced once as a dismissible toast.
 */
import { get, LEGACY_KEYS, keyName } from './storage.js'
import { LEGACY_SYLLABUS, normalizeName } from '../data/legacySyllabus.js'
import { slugify } from '../data/resolveTopics.js'
import { SYLLABUS_XII, EXAM_SCOPE } from '../../syllabus-exams.data.js'
import { chapterById, syllabus, topicKey } from '../data/syllabus.js'
import { store } from './store.js'

function topicToChapter(subjectKey, legacyChapterName, topicTitle) {
  const chapters = SYLLABUS_XII[subjectKey]
  if (!chapters) return null
  const normFrom = normalizeName(legacyChapterName)
  const tn = normalizeName(topicTitle)
  for (const ch of chapters) {
    if (ch.topicsFrom === 'legacy' && ch.legacyName && normalizeName(ch.legacyName) === normFrom) return ch.id
  }
  const splits = chapters.filter(c => c.legacySplit && normalizeName(c.legacySplit.from) === normFrom)
  if (splits.length) {
    for (const c of splits) {
      if ((c.legacySplit.match || []).some(m => tn.includes(normalizeName(m)))) return c.id
    }
    const rest = splits.find(c => c.legacySplit.rest)
    if (rest) return rest.id
    for (const c of splits) if (c.fallbackTopics) return c.id
  }
  return null
}

function legacyTopicId(subjectKey, ci, ti) {
  const leg = LEGACY_SYLLABUS[subjectKey]
  if (!leg || !leg.chapters[ci]) return null
  const ch = leg.chapters[ci]
  const title = ch.topics[ti]
  if (title == null) return null
  const v2ch = topicToChapter(subjectKey, ch.name, title)
  if (!v2ch) return null
  return topicKey(subjectKey, v2ch, slugify(title))
}

function parseTicks(obj) {
  const out = []
  if (!obj || typeof obj !== 'object') return out
  for (const [k, v] of Object.entries(obj)) {
    if (!v) continue
    const parts = k.split(':')
    let subject, ci, ti
    if (parts.length === 3) { [subject, ci, ti] = parts }
    else if (parts.length === 4 && (parts[0] === 'my' || parts[0] === 'school')) { [, subject, ci, ti] = parts }
    else continue
    ci = parseInt(ci, 10); ti = parseInt(ti, 10)
    if (isNaN(ci) || isNaN(ti)) continue
    const key = legacyTopicId(subject, ci, ti)
    if (key) out.push(key)
  }
  return out
}

function preTickScope(examId, sectionC = false) {
  const scope = EXAM_SCOPE[examId] || {}
  const checked = {}
  for (const [sk, ids] of Object.entries(scope)) {
    for (const chId of ids) {
      const found = chapterById().get(chId)
      if (!found) continue
      const ch = found.chapter
      if (ch.optional && !sectionC) continue
      for (const t of ch.topics) checked[topicKey(sk, chId, t.id)] = true
    }
  }
  return checked
}

export function runMigration() {
  // Guard: already migrated, or fresh install with nothing to import.
  if (store.migrationReport) return null
  let importedMy = 0, importedSchool = 0

  // The live v1 app actually persisted under 'studyos_v2_state'.
  let v1 = {}
  try {
    const raw = localStorage.getItem('studyos_v2_state')
    v1 = raw ? JSON.parse(raw) : {}
  } catch {}

  // Prefer the checklist contents inside the live v1 store, else the old keys.
  const oldMy = readKey('studyos_checklist_my') || {}
  const oldSchool = readKey('studyos_checklist_school') || {}
  const myTicks = parseTicks(Object.keys(v1.checklistMy || {}).length ? v1.checklistMy : oldMy)
  const schoolTicks = parseTicks(Object.keys(v1.checklistSchool || {}).length ? v1.checklistSchool : oldSchool)
  importedMy = myTicks.length
  importedSchool = schoolTicks.length

  // Build mastery from imported ticks.
  for (const key of myTicks) {
    store.mastery[key] = Object.assign(store.mastery[key] || {}, { status: 'revised', lastRevisedAt: new Date().toISOString() })
  }
  for (const key of schoolTicks) {
    const rec = store.mastery[key] || (store.mastery[key] = {})
    rec.school = true
    if (!rec.status || rec.status === 'not_started') rec.status = 'not_started'
  }

  // Carry over data slice from the live v1 store.
  if (v1 && typeof v1 === 'object') {
    store.data.completed = sanitizeCompleted(v1.completed || {})
    store.data.days = v1.days || {}
    store.data.tasks = (v1.tasks || []).slice(0, 500).map(t => ({
      id: t.id, text: String(t.text || '').slice(0, 300), done: !!t.done, createdAt: t.createdAt || null, doneAt: t.doneAt || null,
    })).filter(t => t.text)
    store.data.notes = v1.notes || {}
    store.data.chat = (v1.chat || []).slice(-40)
    const st = v1.settings || {}
    store.data.streak = { lastDay: st.lastStreakDay || null, streak: st.streak || 0, bestStreak: st.bestStreak || 0 }
    store.settings.theme = st.theme || 'system'
    if (st.aiKey) store.settings.ai.openrouterKey = st.aiKey
    if (st.aiModel) store.settings.ai.chatModel = st.aiModel
    store.settings.onboarded = !!st.onboarded
  } else {
    // older v1 (pre studyos_v2_state): read the per-key stores
    store.data.completed = readDayKeyCompleted()
    store.data.tasks = (readKey('studyos_tasks') || []).slice(0, 500).map((t, i) => ({
      id: t?.id ?? Date.now() + i, text: String(t?.text || '').slice(0, 300), done: !!t?.done, createdAt: t?.createdAt || null, doneAt: t?.doneAt || null,
    })).filter(t => t.text)
    store.data.notes = readKey('studyos_notes') || {}
    const streak = readKey('studyos_streak') || {}
    store.data.streak = { lastDay: streak.lastStreakDay || null, streak: streak.streak || 0, bestStreak: streak.bestStreak || 0 }
  }

  // Pre-tick UT-1 and UT-2 as completed.
  store.examProgress['ut1'] = { checked: preTickScope('ut1'), autoFromMastery: false, scopeOverride: null, targetDate: '2026-05-15', mocks: [], reflection: '', completedAt: '2026-05-15T23:59:59Z' }
  store.examProgress['ut2'] = { checked: preTickScope('ut2'), autoFromMastery: false, scopeOverride: null, targetDate: '2026-08-14', mocks: [], reflection: '', completedAt: '2026-08-14T23:59:59Z' }

  const report = {
    importedMy, importedSchool,
    ut1Topics: Object.keys(store.examProgress.ut1.checked).length,
    ut2Topics: Object.keys(store.examProgress.ut2.checked).length,
    migratedAt: new Date().toISOString(),
    ran: true,
  }
  store.migrationReport = report
  saveAll()
  return report
}

function sanitizeCompleted(obj) {
  const out = {}
  if (!obj || typeof obj !== 'object') return out
  for (const [k, v] of Object.entries(obj)) {
    if (Array.isArray(v)) out[k] = v.filter(n => Number.isInteger(n) && n >= 0 && n <= 6)
  }
  return out
}
function readDayKeyCompleted() {
  const raw = localStorage.getItem('studyos_completed')
  if (!raw) return {}
  try {
    const arr = JSON.parse(raw)
    if (Array.isArray(arr)) {
      const tk = new Date().toISOString().slice(0, 10)
      return { [tk]: arr.filter(n => Number.isInteger(n) && n >= 0 && n <= 6) }
    }
  } catch {}
  return {}
}
function readKey(k) {
  try { return JSON.parse(localStorage.getItem(k)) } catch { return null }
}
function saveAll() {
  const map = { state: store.data, mastery: store.mastery, examProgress: store.examProgress, settings: store.settings, migrationReport: store.migrationReport }
  for (const [k, v] of Object.entries(map)) {
    try { localStorage.setItem(keyName(k), JSON.stringify(v)) } catch {}
  }
}

/** True when any legacy storage exists (used by boot to decide whether to migrate). */
export function hasLegacy() {
  return LEGACY_KEYS.some(k => { try { return localStorage.getItem(k) != null } catch { return false } })
}

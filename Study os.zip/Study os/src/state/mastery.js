/**
 * state/mastery.js — the global topic-mastery model and per-exam preparation.
 *   mastery[key]      (A) what Parth knows — never exam-specific.
 *   examProgress[id]  (B) what has been prepared for THAT exam.
 * key = `${subjectKey}|${chapterId}|${topicId}` (stable id-based slugs).
 */
import { store, save } from './store.js'
import { syllabus, chapterById, topicKey } from '../data/syllabus.js'
import { EXAMS, EXAM_ORDER, resolveScope } from '../data/exams.js'
import { todayKey, daysUntil } from '../lib/time.js'

const STATUS_LEVEL = { not_started: 0, learning: 1, revised: 2, mastered: 3 }

export function defaultMasteryRecord() {
  return {
    status: 'not_started', school: false, confidence: 0,
    revisions: 0, lastRevisedAt: null, nextReviewAt: null,
    minutes: 0, flagged: false, note: '', sources: [],
  }
}

export function mastery(key) {
  if (!store.mastery[key]) store.mastery[key] = defaultMasteryRecord()
  return store.mastery[key]
}
export function masteryFor(subjectKey, chapterId, topicId) {
  return mastery(topicKey(subjectKey, chapterId, topicId))
}
export function setMastery(key, patch, persist = true) {
  const rec = mastery(key)
  Object.assign(rec, patch)
  if (persist) save('mastery')
  return rec
}

/** The effective exam tick for a topic: manual check OR auto-from-mastery. */
export function isExamChecked(examId, key) {
  const ep = store.examProgress[examId]
  if (!ep) return false
  if (ep.checked && ep.checked[key]) return true
  if (ep.autoFromMastery !== false) {
    const m = store.mastery[key]
    if (m && STATUS_LEVEL[m.status] >= 2) return true   // revised or mastered
  }
  return false
}
export function isExamCheckedLevel(examId, key, level) {
  const m = store.mastery[key]
  return m && STATUS_LEVEL[m.status] >= STATUS_LEVEL[level]
}

export function examState(examId, create = true) {
  if (!store.examProgress[examId] && create) {
    store.examProgress[examId] = {
      checked: {}, autoFromMastery: true, scopeOverride: null,
      targetDate: null, mocks: [], reflection: '', completedAt: null,
    }
  }
  return store.examProgress[examId]
}

export function toggleExamTick(examId, key) {
  const ep = examState(examId)
  const already = isExamChecked(examId, key)
  // turning a manual tick off just removes the manual tick
  if (already && ep.checked[key]) { delete ep.checked[key]; save('examProgress'); return false }
  if (!already && !ep.checked[key]) {
    // first tick also bumps global mastery to at least 'revised'
    const m = mastery(key)
    if (STATUS_LEVEL[m.status] < 2) { m.status = 'revised'; m.lastRevisedAt = m.lastRevisedAt || new Date().toISOString(); save('mastery') }
    ep.checked[key] = true
    save('examProgress')
    return true
  }
  save('examProgress')
  return !already
}

export function setTopicMastery(key, status, patch = {}) {
  const rec = mastery(key)
  rec.status = status
  Object.assign(rec, patch)
  if (status === 'revised' || status === 'mastered') {
    rec.lastRevisedAt = rec.lastRevisedAt || new Date().toISOString()
  }
  save('mastery')
  return rec
}

export function bumpRevision(key) {
  const rec = mastery(key)
  rec.revisions += 1
  rec.lastRevisedAt = new Date().toISOString()
  rec.nextReviewAt = spacedReviewDate(rec.revisions)
  save('mastery')
  return rec
}

/** Spaced repetition: 1, 3, 7, 16, 35 days by revisions count. */
export function spacedReviewDate(revisions, fromIso) {
  const gaps = [1, 3, 7, 16, 35]
  const days = gaps[Math.min(revisions - 1, gaps.length - 1)] || 35
  const from = fromIso ? new Date(fromIso) : new Date()
  from.setDate(from.getDate() + days)
  return todayKey(from)
}

/** Clamp so the last review lands at least 2 days before the exam. */
export function clampReviewDate(nextReviewAt, examDate) {
  if (!examDate) return nextReviewAt
  const d = daysUntil(examDate)
  if (d <= 2) return null
  const max = todayKey(new Date(Date.now() + (d - 2) * 86400000))
  return nextReviewAt && nextReviewAt <= max ? nextReviewAt : max
}

// ── taught-in-school chapter detection ──────────────────────────────────────
export function taughtChapterIds() {
  const set = new Set()
  for (const key of Object.keys(store.mastery)) {
    const rec = store.mastery[key]
    if (rec && rec.school) {
      const [subjectKey, chapterId] = key.split('|')
      set.add(chapterId)
    }
  }
  return set
}

// ── scope-driven aggregation ────────────────────────────────────────────────
function scopeTopics(examId, opts) {
  const scope = resolveScope(examId, {
    sectionC: store.settings.exams.sectionC,
    override: store.examProgress[examId]?.scopeOverride,
    taughtOnly: !!opts?.taughtOnly,
    taughtChapterIds: taughtChapterIds(),
  })
  const items = []
  for (const sk of Object.keys(scope.subjects)) {
    for (const chId of scope.subjects[sk].chapters) {
      const found = chapterById().get(chId)
      if (!found) continue
      for (const t of found.chapter.topics) {
        items.push({ subjectKey: sk, chapter: found.chapter, topic: t, key: topicKey(sk, chId, t.id) })
      }
    }
  }
  return { items, scope }
}

export function examMetrics(examId, opts) {
  const { items, scope } = scopeTopics(examId, opts)
  const total = items.length
  let checked = 0, flagCount = 0, revisions = 0, confidence = 0, minutes = 0
  const bySubject = {}
  for (const it of items) {
    const m = store.mastery[it.key] || defaultMasteryRecord()
    const isChk = isExamChecked(examId, it.key)
    if (isChk) checked++
    if (m.flagged) flagCount++
    revisions += m.revisions
    confidence += m.confidence
    minutes += m.minutes || 0
    const bs = bySubject[it.subjectKey] || (bySubject[it.subjectKey] = { total: 0, checked: 0, chapters: 0, chapterDone: 0 })
    bs.total++; if (isChk) bs.checked++
  }
  for (const sk of Object.keys(scope.subjects)) {
    const chs = scope.subjects[sk].chapters
    const bs = bySubject[sk] || (bySubject[sk] = { total: 0, checked: 0, chapters: 0, chapterDone: 0 })
    bs.chapters = chs.length
    bs.chapterDone = chs.filter(chId => {
      const found = chapterById().get(chId)
      if (!found) return false
      return found.chapter.topics.every(t => isExamChecked(examId, topicKey(sk, chId, t.id)))
    }).length
  }
  const coverage = total ? checked / total : 0
  const avgRevisions = total ? revisions / total : 0
  const revisionDepth = Math.min(avgRevisions / 2, 1)
  const avgConfidence = total ? confidence / total : 0
  const readiness = Math.round(55 * coverage + 25 * revisionDepth + 20 * (avgConfidence / 5))
  return {
    total, checked, flagCount, bySubject, readiness, coverage, revisionDepth, avgConfidence, minutes,
    avgRevisions, scope,
  }
}

export function readinessBand(r) {
  if (r < 40) return { label: 'At risk', color: '#FF6B6B' }
  if (r < 70) return { label: 'Needs work', color: '#F5C842' }
  if (r < 90) return { label: 'On track', color: '#60B5FF' }
  return { label: 'Exam ready', color: '#4ADE80' }
}

export function paceInfo(examId, metrics) {
  const exam = EXAMS.find(e => e.id === examId)
  if (!exam || !exam.end) return null
  const dLeft = Math.max(daysUntil(exam.end), 0)
  const remaining = metrics.total - metrics.checked
  const needPerDay = dLeft > 0 ? remaining / dLeft : remaining
  // actual 7-day average topics/day from history
  const hist = store.history
  const last7 = hist.filter(h => h.t && h.tk && daysUntil(h.tk) >= -7)
  const ticks7 = last7.reduce((a, h) => a + (h.ticks || 0), 0)
  const doingPerDay = last7.length ? ticks7 / last7.length : 0
  return { needPerDay, doingPerDay, daysLeft: dLeft, remaining, onTrack: doingPerDay >= needPerDay }
}

/** Risk list: unticked / flagged / zero-revision / overdue topics in scope. */
export function riskList(examId, limit = 8) {
  const { items } = scopeTopics(examId)
  const out = []
  const today = todayKey()
  for (const it of items) {
    const m = store.mastery[it.key]
    if (!m) continue
    const unticked = !isExamChecked(examId, it.key)
    const overdue = m.nextReviewAt && m.nextReviewAt <= today
    if (unticked || m.flagged || (m.revisions === 0 && unticked) || overdue) {
      out.push({ ...it, mastery: m, reason: m.flagged ? 'flagged' : unticked ? 'not covered' : (overdue ? 'revision due' : 'needs work') })
    }
  }
  out.sort((a, b) => (b.mastery.flagged ? 1 : 0) - (a.mastery.flagged ? 1 : 0))
  return out.slice(0, limit)
}

/** Revision queue: every topic with nextReviewAt <= today, grouped by subject. */
export function revisionQueue() {
  const today = todayKey()
  const out = { list: [], bySubject: {} }
  for (const key of Object.keys(store.mastery)) {
    const rec = store.mastery[key]
    if (!rec.nextReviewAt || rec.nextReviewAt > today) continue
    const [subjectKey, chapterId, topicId] = key.split('|')
    const found = chapterById().get(chapterId)
    if (!found) continue
    const entry = { key, subjectKey, chapter: found.chapter, topicId, title: found.chapter.topics.find(t => t.id === topicId)?.title || topicId, rec }
    out.list.push(entry)
    ;(out.bySubject[subjectKey] ||= []).push(entry)
  }
  out.list.sort((a, b) => a.rec.nextReviewAt.localeCompare(b.rec.nextReviewAt))
  return out
}

/** Daily history sampling hook (called at midnight / on state change). */
export function sampleHistory(extra = {}) {
  const tk = todayKey()
  const metrics = {}
  for (const id of EXAM_ORDER) {
    const m = examMetrics(id)
    metrics[id] = { readiness: m.readiness, checked: m.checked, total: m.total }
  }
  let ticks = 0
  for (const key of Object.keys(store.mastery)) {
    if (STATUS_LEVEL[store.mastery[key].status] >= 2) ticks++
  }
  store.history = store.history.filter(h => h.tk !== tk)
  store.history.push({ tk, ticks, mastery: ticks, exam: metrics, ...extra })
  if (store.history.length > 400) store.history = store.history.slice(-400)
  save('history')
}

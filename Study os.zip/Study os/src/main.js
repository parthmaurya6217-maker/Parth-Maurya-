/**
 * main.js — StudyOS v2 boot. Wires the store, migration, router, nav, glass,
 * fluid, pomodoro and every action. Runs once as a module script.
 */
import './styles/tokens.css'
import './styles/base.css'
import './styles/layout.css'
import './styles/examPrep.css'
import './styles/focusLab.css'
import './styles/settings.css'

import { store, on, save, saveAll, currentStreak, addSecondsToSubject, toggleSession as storeToggleSession } from './state/store.js'
import { runMigration, hasLegacy } from './state/migrations.js'
import { initActions, register } from './lib/actions.js'
import { initGlass, applyAppearance as glassAppearance } from './lib/glass.js'
import { initLiquidEther, applyAppearance as fluidAppearance, pauseFluid, resumeFluid } from './lib/liquidEther.js'
import { buildNav, switchTab, activateTab, openCmdK, closeCmdK, closeCmdKIfOpen, isCmdKOpen, TABS } from './features/nav.js'
import { renderContent, renderContentPreserveScroll } from './features/router.js'
import { tickLoop, slowLoop, autoTrackTime, bootRollover, getNow } from './features/router.js'
import { openFocus, closeFocus, toggleFocus, focusDone } from './features/focusOverlay.js'
import * as pomo from './lib/pomodoro.js'
import * as focusLab from './features/focusLab.js'
import { modalCount, isModalOpen, toast, phaseCard } from './lib/ui.js'
import { todayKey } from './lib/time.js'
import { applyTheme, cycleTheme, openSettings, applyAppearance as settingsAppearance } from './features/settings/settings.js'
import * as examPrep from './features/examPrep.js'
import * as schedule from './features/schedule.js'
import * as checklist from './features/checklist.js'
import * as tasks from './features/tasks.js'
import * as events from './features/events.js'
import * as examTimetable from './features/examTimetable.js'
import * as aiChat from './features/aiChat.js'
import * as analytics from './features/analytics.js'
import * as settings from './features/settings/settings.js'

// ── register every action ───────────────────────────────────────────────────
register('nav-tab', (_, ds) => switchTab(ds.tabid))
register('open-cmdk', () => openCmdK())
register('cycle-theme', () => cycleTheme())
register('open-settings', () => openSettings())
register('modal-close', () => closeModal())
register('reload-app', () => location.reload())
register('copy-diagnostics', () => {
  const pre = document.querySelector('#content pre')
  if (pre) navigator.clipboard.writeText(pre.textContent).then(() => toast('📋', 'Diagnostics copied'))
})

// session / focus
register('toggle-session', (_, ds) => {
  storeToggleSession(+ds.id)
  renderContent()
})
register('open-focus-mode', () => openFocus())
register('toggle-focus', () => toggleFocus())
register('focus-done', () => focusDone())
register('focus-exit', () => closeFocus())

// dashboard plan
register('toggle-plan-item', (_, ds) => {
  const it = store.plan.find(p => p.key === ds.key)
  if (it) { it.done = !it.done; save('plan') }
  renderContent()
})

// checklist
register('switch-checklist', (_, ds) => { store.ui.activeChecklist = ds.type; renderContent() })
register('toggle-checklist', (_, ds) => { checklist.toggleChecklistTopic(ds.type, ds.key); renderContentPreserveScroll() })
register('toggle-chapter', (_, ds) => { checklist.toggleChapterOpen(ds.sk, ds.chid); renderContentPreserveScroll() })
register('toggle-chapter-all', (_, ds) => { checklist.toggleChapterAll(ds.sk, ds.chid); renderContentPreserveScroll() })
register('toggle-subject', (_, ds) => { checklist.toggleSubjectOpen(ds.sk); renderContentPreserveScroll() })
register('checklist-search', el => {
  store.ui.checklistSearch = el.value
  const pos = el.selectionStart
  renderContent()
  const inp = document.getElementById('cl-search')
  if (inp) { inp.focus(); try { inp.setSelectionRange(pos, pos) } catch {} }
})
register('checklist-clear', () => { store.ui.checklistSearch = ''; renderContent() })

// tasks
register('task-input', el => { store.ui.taskInput = el.value })
register('add-task', () => tasks.addTaskAction())
register('toggle-task', (_, ds) => tasks.toggleTaskAction(null, ds))
register('delete-task', (_, ds) => tasks.deleteTaskAction(null, ds))
register('clear-done-tasks', () => tasks.clearDoneTasksAction())

// events
register('event-filter', (_, ds) => { store.ui.eventFilter = ds.filter; renderContent() })

// exam timetable
register('set-paper-date', (el, ds) => { examTimetable.setPaperDateAction(el, ds); renderContent() })

// ai chat
register('chat-suggest', (_, ds) => aiChat.sendSuggestion(ds.text))
register('chat-send', () => aiChat.sendChatMessage(false))
register('chat-retry', () => aiChat.sendChatMessage(true))
register('chat-copy', (_, ds) => aiChat.copyMsg(+ds.i))
register('chat-remove-attach', (_, ds) => aiChat.removeChatAttachment(+ds.i))
register('chat-export', () => aiChat.exportChat())
register('chat-quiz', () => aiChat.quizOnWeakTopics())
register('chat-clear', () => aiChat.clearChatConfirm())

// exam prep
register('exam-select', (_, ds) => examPrep.selectExam(null, ds))
register('exam-toggle-subject', (_, ds) => examPrep.toggleExamSubject(null, ds))
register('exam-toggle-chapter', (_, ds) => examPrep.toggleExamChapter(null, ds))
register('exam-toggle-out', (_, ds) => examPrep.toggleOutOfScope(null, ds))
register('exam-tick', (_, ds) => examPrep.examTick(null, ds))
register('exam-chapter-all', (_, ds) => examPrep.examChapterAll(null, ds))
register('exam-confidence', (_, ds) => examPrep.examConfidence(null, ds))
register('exam-revise', (_, ds) => examPrep.examRevise(null, ds))
register('exam-flag', (_, ds) => examPrep.examFlag(null, ds))
register('exam-complete', (_, ds) => examPrep.examComplete(null, ds))
register('exam-unlock', (_, ds) => examPrep.examUnlock(null, ds))
register('exam-taught-toggle', (_, ds) => examPrep.examTaughtToggle(null, ds))
register('exam-edit-scope', (_, ds) => examPrep.examEditScope(null, ds))
register('scope-save', (_, ds) => examPrep.scopeSave(null, ds))
register('exam-plan', (_, ds) => examPrep.generatePlan(null, ds))
register('focus-lab-revision', () => { switchTab('focusLab'); focusLab.attachRevisionTopics() })

// focus lab
register('focus-url-input', el => { store.ui.focusLabUrl = el.value })
register('focus-load', () => focusLab.loadVideoAction())
register('resume', (_, ds) => focusLab.resumeAction(null, ds))
register('analyse', (_, ds) => focusLab.analyseAction(null, ds))
register('cancel-analysis', () => focusLab.cancelAnalysis())
register('seek-topic', (_, ds) => focusLab.seekToTopic(null, ds))
register('toggle-topic-expand', (_, ds) => focusLab.toggleTopicExpand(null, ds))
register('topic-check', (_, ds) => focusLab.topicCheck(null, ds))
register('topic-note', (_, ds) => focusLab.setTopicNote(null, ds))
register('add-topic-now', () => focusLab.addTopicAtCurrent())
register('export-notes', (_, ds) => focusLab.exportNotes(null, ds))
register('attach-exam', (_, ds) => focusLab.attachToExam(null, ds))
register('pomo-start', () => focusLab.pomoStart())
register('pomo-skip', () => focusLab.pomoSkip())
register('pomo-add5', () => focusLab.pomoAdd5())
register('pomo-reset', () => focusLab.pomoReset())

// settings
register('set-toggle', (el, ds) => settings.setToggle(el, { ...ds, checked: el.checked }))
register('pomo-num', el => settings.setPomoNum(el, { key: el.dataset.key, value: el.value }))
register('pomo-volume', el => settings.setPomoVolume(el, { value: el.value }))
register('pomo-notify-perm', () => settings.pomoNotifyPerm())
register('pomo-reset-defaults', () => settings.pomoResetDefaults())
register('ai-provider', (_, ds) => settings.setAiProvider(null, ds))
register('ai-model', el => settings.setAiModel(el, { value: el.value }))
register('ai-mode', (_, ds) => settings.setAiMode(null, ds))
register('ai-proxy-url', el => settings.setAiProxyUrl(el, { value: el.value }))
register('ai-gemini-key', el => settings.setAiKey(el, { value: el.value }))
register('ai-or-key', el => settings.setAiORKey(el, { value: el.value }))
register('ai-max-topics', el => settings.setAiMaxTopics(el, { value: el.value }))
register('ai-thinking', el => settings.setAiThinking(el, { value: el.value }))
register('ai-test-key', () => settings.testGeminiKey())
register('ai-test-or', () => settings.testOpenRouterKey())
register('theme-pref', (_, ds) => settings.setThemePref(null, ds))
register('glass-intensity', (_, ds) => settings.setGlassIntensity(null, ds))
register('fluid-palette', (_, ds) => settings.setFluidPalette(null, ds))
register('fluid-res', (_, ds) => settings.setFluidRes(null, ds))
register('reduced-motion', (_, ds) => settings.setReducedMotion(null, ds))
register('section-c', (_, ds) => settings.setSectionC(null, ds))
register('exam-date', el => settings.setExamDate(el, { exam: el.dataset.exam, field: el.dataset.field, value: el.value }))
register('exam-status', el => settings.setExamStatus(el, { exam: el.dataset.exam, value: el.value }))
register('sy-rename', el => settings.syRename(el, { sk: el.dataset.sk, chid: el.dataset.chid, value: el.value }))
register('sy-taught', (_, ds) => settings.syTaught(null, ds))
register('sy-add-chapter', (_, ds) => settings.syAddChapter(null, ds))
register('sy-del-chapter', (_, ds) => settings.syDelChapter(null, ds))
register('data-export', () => settings.exportData())
register('data-import', el => settings.importData(el, {}))
register('data-clear-videos', () => settings.clearVideoCache())
register('data-reset', () => settings.resetAllData())

// ── global error handlers ────────────────────────────────────────────────────
window.addEventListener('error', e => {
  console.error('global error:', e.error || e.message)
  renderContent()
})
window.addEventListener('unhandledrejection', e => {
  console.error('unhandled rejection:', e.reason)
  if (e.reason?.message === 'CANCELLED') e.preventDefault()
})

// ── boot ─────────────────────────────────────────────────────────────────────
function boot() {
  // 1. migration (one-time, before anything renders)
  if (hasLegacy()) {
    const report = runMigration()
    if (report && report.ran) {
      const total = (report.importedMy || 0) + (report.importedSchool || 0)
      toast('📦', `Imported ${total} ticks from your old checklist. UT-1 and UT-2 are marked complete.`, { ttl: 8000 })
    }
  }
  bootRollover()

  // 2. appearance + chrome
  const dark = applyTheme()
  settingsAppearance()
  glassAppearance()
  fluidAppearance()

  // 3. nav + content
  buildNav()
  activateTab(store.ui.tab)
  renderContent()

  // 4. interaction layers
  initActions()
  initGlass()

  // 5. fluid background
  const ether = initLiquidEther()
  if (ether) {
    // feed the fluid from the shared pointer stream (pointer-events:none canvas)
    document.addEventListener('pointermove', e => { ether.setPointer(e.clientX, e.clientY) }, { passive: true })
  }

  // 6. pomodoro recovery (roll forward if a phase finished while away)
  const completions = pomo.rollForward()
  if (completions.length && pomo.currentPhase() !== 'idle') {
    focusLab.afterPhaseChange()
    toast('⏱', completions[0].skippedNext ? `${pomo.phaseLabel(completions[0].phase)} finished while you were away — break skipped` : `${pomo.phaseLabel(completions[0].phase)} finished — ${pomo.phaseLabel(pomo.currentPhase())} started`, { ttl: 6000 })
  }
  // surface phase changes live
  on('pomodoro:phase', phase => {
    focusLab.onPomodoroPhase(phase)
    const p = pomo.currentPhase()
    phaseCard(pomo.phaseLabel(p), p === 'focus' ? `Focus ${pomo.focusBlockIndex()} of ${pomo.blocksPerCycle()}` : 'Breathe — you earned it.', p === 'focus' ? '#8B5CF6' : (p === 'short' ? '#4ADE80' : '#60B5FF'))
    if (store.ui.tab === 'focusLab') renderContent()
  })

  // 7. wake lock during focus
  let wakeLock = null
  const setWake = async () => {
    const want = store.settings.pomodoro.wakeLock && pomo.isRunning() && pomo.currentPhase() === 'focus'
    if (want && !wakeLock && 'wakeLock' in navigator) {
      try { wakeLock = await navigator.wakeLock.request('screen') } catch {}
    } else if (!want && wakeLock) {
      try { wakeLock.release() } catch {}
      wakeLock = null
    }
  }
  setInterval(setWake, 5000)

  // 8. calm fluid during focus
  on('pomodoro:phase', () => {
    const calm = store.settings.appearance.calmDuringFocus && pomo.currentPhase() === 'focus' && pomo.isRunning()
    calm ? pauseFluid() : resumeFluid()
  })

  // 9. tab switching: keep the video player mounted only while Focus Lab is open
  on('tab', tab => {
    if (tab === 'focusLab') focusLab.initFocusLab()
    else focusLab.teardownFocusLab()
    activateTab(tab)
  })

  // 10. appearance changes applied live
  on('saved', slice => {
    if (slice === 'settings') {
      applyTheme()
      settingsAppearance()
      glassAppearance()
      fluidAppearance()
    }
  })

  // 11. theme system-change listener
  try {
    matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
      if (store.settings.theme === 'system') applyTheme()
    })
  } catch {}

  // 12. intervals
  setInterval(() => {
    // midnight rollover
    const tk = todayKey()
    const lastKey = getNow().toISOString().slice(0, 10)
    void lastKey
    tickLoop()
  }, 1000)
  setInterval(() => { autoTrackTime() }, 1000)
  setInterval(() => slowLoop(), 30000)
}

// keyboard shortcuts
document.addEventListener('keydown', e => {
  const tag = (e.target.tagName || '').toLowerCase()
  const typing = tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); isCmdKOpen() ? closeCmdK() : openCmdK(); return }
  if (typing || e.ctrlKey || e.metaKey || e.altKey) return
  if (modalCount() || isCmdKOpen()) return
  if (e.key >= '1' && e.key <= '9') {
    const t = TABS[+e.key - 1]
    if (t) { switchTab(t.tab) }
    return
  }
  switch (e.key.toLowerCase()) {
    case 'f': toggleFocus(); break
    case 't': cycleTheme(); break
    case 's': openSettings(); break
    case '?': case '/': if (e.key === '/') { e.preventDefault(); openSettings() } break
  }
})

// Focus Lab keyboard map (only while that tab is open)
document.addEventListener('keydown', e => {
  if (store.ui.tab !== 'focusLab') return
  const tag = (e.target.tagName || '').toLowerCase()
  const typing = tag === 'input' || tag === 'textarea' || tag === 'select'
  if (typing || e.ctrlKey || e.metaKey || e.altKey) return
  if (modalCount() || isCmdKOpen()) return
  const player = focusLab.getPlayer()
  switch (e.key.toLowerCase()) {
    case ' ': e.preventDefault(); if (player.player) { player.player.getPlayerState?.() === 1 ? player.player.pauseVideo() : player.player.playVideo() } break
    case 'j': e.preventDefault(); if (player.player) player.player.seekTo((player.player.getCurrentTime() || 0) + 10, true); break
    case 'l': e.preventDefault(); if (player.player) player.player.seekTo(Math.max(0, (player.player.getCurrentTime() || 0) - 10), true); break
    case 'k': e.preventDefault(); if (player.player) player.player.pauseVideo(); break
    case 'n': e.preventDefault(); seekTopicRel(-1); break
    case 'p': e.preventDefault(); seekTopicRel(1); break
    case 't': e.preventDefault(); focusLab.addTopicAtCurrent(); break
    case 'm': e.preventDefault(); player.player && player.player.mute(); break
    case 'f': e.preventDefault(); player.player && player.player.getIframe?.().requestFullscreen?.(); break
  }
  if (!typing && /^[1-9]$/.test(e.key)) {
    const v = focusLab.currentVideo()
    if (v && v.topics && v.topics.length >= +e.key) {
      const t = v.topics[+e.key - 1]
      if (player.player) { player.player.seekTo(t.startSec, true); player.player.playVideo() }
    }
  }
})

function seekTopicRel(dir) {
  const v = focusLab.currentVideo()
  const player = focusLab.getPlayer()
  if (!v || !v.topics?.length || !player.player) return
  const t = player.player.getCurrentTime?.() || 0
  let idx = v.topics.findIndex(x => t >= x.startSec && t < (x.endSec || Infinity))
  if (idx < 0) idx = v.topics.reduce((a, x, i) => (x.startSec <= t ? i : a), 0)
  idx = Math.min(Math.max(idx + dir, 0), v.topics.length - 1)
  player.player.seekTo(v.topics[idx].startSec, true)
  player.player.playVideo()
}

boot()
